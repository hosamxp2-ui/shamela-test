// إعدادات المصدر والحدود. غيّر المصدر من هنا فقط.
export const SOURCE = {
  id: "shamela-nas",
  manifestUrl: "https://files.murabbie.org/fsdownload/FnGtHqpG9/manifest.json"
};

export const LIMITS = {
  pageSize: 100,                 // عدد الكتب في كل دفعة عرض
  inspectMaxBytes: 5 * 1024 * 1024 // أكبر كتاب يُفحص في هذه المرحلة (حجم مضغوط)
};
