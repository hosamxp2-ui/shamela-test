// إعدادات المصدر والحدود. غيّر المصدر من هنا فقط.
export const SOURCE = {
  id: "shamela-nas",
  manifestUrl: "https://files.murabbie.org/fsdownload/FnGtHqpG9/manifest.json"
};

// رابط صفحة الكتاب في موقع الشاملة (من حقل site.book في الـ Manifest)
export const SITE_BOOK_URL = "https://shamela.ws/book/{id}";

export const LIMITS = {
  pageSize: 100,                 // عدد الكتب في كل دفعة عرض
  inspectMaxBytes: 12 * 1024 * 1024, // أكبر كتاب يُفحص بأداة الفحص (حجم مضغوط)
  dbPrefixBytes: 6 * 1024 * 1024, // مقدار ما يُجلب من بداية services/tashkeel للفحص
  readerMaxRawBytes: 100 * 1024 * 1024, // أكبر كتاب يُفتح في القارئ تلقائيًا (حجم بعد الفك)
  readerHardMaxRawBytes: 220 * 1024 * 1024 // أكبر كتاب يُفتح بعد موافقة المستخدم (الذاكرة تتضاعف أثناء الفتح)
};
