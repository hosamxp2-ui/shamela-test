// محرك بحث الفهرس (العناوين والمؤلفون والأقسام). دوال نقية بلا اعتماد على الواجهة.
// الصيغة: كلمات (كلها لازمة) | "عبارة كاملة" | -كلمة أو -"عبارة" للاستبعاد.
// الوضع: جزئي (الافتراضي) أو مطابقة دقيقة لكلمات كاملة.
import { normalizeArabic } from "../modules/arabic.js";

const NON_WORD = /[^\p{L}\p{N}]+/gu;
const HAS_WORD = /[\p{L}\p{N}]/u;
const clean = (s) => s.replace(NON_WORD, " ").trim();

export function parseQuery(q) {
  const terms = [];
  const re = /(-?)"([^"]*)"|(-?)(\S+)/g;
  let m;
  const src = String(q == null ? "" : q);
  while ((m = re.exec(src))) {
    const quoted = m[2] !== undefined;
    const neg = (quoted ? m[1] : m[3]) === "-";
    const text = normalizeArabic(quoted ? m[2] : m[4]);
    if (!text || !HAS_WORD.test(text)) continue;
    terms.push({ text, words: clean(text), phrase: quoted, neg });
  }
  return { terms, positives: terms.filter((t) => !t.neg), negatives: terms.filter((t) => t.neg) };
}

export function buildSearchIndex(books, catNormById) {
  return books.map((b) => {
    const title = b.norm || normalizeArabic(b.name);
    const author = b.authorNorm || "";
    const category = catNormById.get(b.cat) || "";
    return {
      title, author, category,
      tw: " " + clean(title) + " ", aw: " " + clean(author) + " ", cw: " " + clean(category) + " "
    };
  });
}

// موضع الكلمة في الحقل: whole > start > wordstart > sub > null
function position(field, wordsField, term, exact) {
  if (!field) return null;
  if (exact) {
    const w = " " + term.words + " ";
    if (wordsField === w) return "whole";
    if (wordsField.startsWith(w)) return "start";
    if (wordsField.includes(w)) return "wordstart";
    return null;
  }
  if (field === term.text) return "whole";
  if (field.startsWith(term.text)) return "start";
  if ((" " + field).includes(" " + term.text)) return "wordstart";
  if (field.includes(term.text)) return "sub";
  return null;
}

const WEIGHTS = {
  title: { whole: 100, start: 80, wordstart: 60, sub: 40 },
  author: { whole: 50, start: 40, wordstart: 30, sub: 20 },
  category: { whole: 15, start: 12, wordstart: 10, sub: 5 }
};

function fieldsOf(entry, which) {
  const all = [["title", entry.title, entry.tw], ["author", entry.author, entry.aw], ["category", entry.category, entry.cw]];
  return which === "all" || !which ? all : all.filter((f) => f[0] === which);
}

// يعيد [{ i: فهرس الكتاب في المصفوفة، score }] للمطابقات فقط (بالترتيب الأصلي).
export function runSearch(index, parsed, { fields = "all", exact = false } = {}) {
  const out = [];
  for (let i = 0; i < index.length; i++) {
    const fs = fieldsOf(index[i], fields);
    let ok = true;
    let score = 0;
    for (const term of parsed.negatives) {
      if (fs.some(([, f, w]) => position(f, w, term, exact) !== null)) { ok = false; break; }
    }
    if (!ok) continue;
    for (const term of parsed.positives) {
      let best = 0;
      for (const [name, f, w] of fs) {
        const p = position(f, w, term, exact);
        if (p !== null && WEIGHTS[name][p] > best) best = WEIGHTS[name][p];
      }
      if (best === 0) { ok = false; break; }
      score += best;
    }
    if (ok) out.push({ i, score });
  }
  return out;
}
