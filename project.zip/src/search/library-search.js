// البحث في نصوص عدة كتب منزّلة: كتاب بعد كتاب، مع تقدّم وإلغاء وحدود، وفرز النتائج.
import { parseQuery } from "./query.js";
import { searchDb } from "./text-search.js";
import { openDatabase as defaultOpen } from "../services/sqlite.js";
import { LIMITS } from "../config.js";

// يحدد الكتب المنزّلة ضمن النطاق: all | cat | author | book
export function scopeIds({ scope = "all", cat = null, author = null, book = null }, { catalog, downloadedIds }) {
  const have = new Set(downloadedIds);
  if (scope === "book") return book != null && have.has(book) ? [book] : [];
  let ids = [...have];
  if (scope === "cat") ids = ids.filter((id) => { const b = catalog.getBook(id); return b && b.cat === cat; });
  if (scope === "author") { const owned = new Set(catalog.searchBooks({ author }).map((b) => b.id)); ids = ids.filter((id) => owned.has(id)); }
  return ids.sort((a, b) => a - b);
}

const tick = () => new Promise((r) => setTimeout(r, 0));

export async function searchLibrary({ ids, q, exact = false, dl, catalog, open = defaultOpen, perBook = 30, limitTotal = 400, token = { cancelled: false }, onProgress = () => {}, onResults = () => {} }) {
  const parsed = parseQuery(q);
  const out = { results: [], skipped: [], cancelled: false, truncated: false, searched: 0 };
  if (!parsed.positives.length) return out;
  for (let i = 0; i < ids.length; i++) {
    if (token.cancelled) { out.cancelled = true; break; }
    const id = ids[i];
    onProgress({ done: i, total: ids.length, id });
    const entry = catalog.fileInfo(id);
    if (entry && entry.size > LIMITS.readerMaxRawBytes) { out.skipped.push({ id, reason: "big" }); continue; }
    let db;
    try {
      db = await open(await dl.getBookBytes(id));
      const hits = await searchDb(db, parsed, { exact, perBook, bookId: id, yieldFn: tick });
      out.searched++;
      if (hits.length) { out.results.push(...hits); onResults(out.results.slice()); }
    } catch (_) {
      out.skipped.push({ id, reason: "error" });
    } finally {
      if (db) db.close();
    }
    if (out.results.length >= limitTotal) { out.results.length = limitTotal; out.truncated = true; break; }
    await tick();
  }
  onProgress({ done: out.cancelled ? out.searched : ids.length, total: ids.length, id: null });
  return out;
}

// relevance: الأفضل أولًا عند "asc" | title | author | category | appearance (بحسب ظهورها داخل الكتب)
export function sortResults(results, sort, dir, catalog) {
  const collator = new Intl.Collator("ar");
  const name = (r) => { const b = catalog.getBook(r.bookId); return b ? b.name : ""; };
  const author = (r) => { const b = catalog.getBook(r.bookId); return b ? catalog.authorName(b.author) : ""; };
  const catOrder = (r) => { const b = catalog.getBook(r.bookId); const c = b ? catalog.getCategory(b.cat) : null; return c ? c.ord : 0; };
  const byBookPage = (a, b) => collator.compare(name(a), name(b)) || a.bookId - b.bookId || a.pageIndex - b.pageIndex;
  const cmp = {
    relevance: (a, b) => b.score - a.score || byBookPage(a, b),
    title: byBookPage,
    author: (a, b) => collator.compare(author(a), author(b)) || byBookPage(a, b),
    category: (a, b) => catOrder(a) - catOrder(b) || byBookPage(a, b),
    appearance: byBookPage
  }[sort] || byBookPage;
  const sign = dir === "desc" ? -1 : 1;
  return results.slice().sort((a, b) => sign * cmp(a, b));
}
