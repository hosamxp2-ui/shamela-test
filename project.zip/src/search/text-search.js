// البحث في نصوص الكتب المنزّلة (محلي): تنظيف HTML، مطابقة بالكلمات والعبارات والاستبعاد،
// مقتطف من النص الأصلي (بتشكيله) مع تمييز الكلمات. لا يعتمد على FTS5 لأن sql.js لا يدعمها.
import { normalizeArabic } from "../modules/arabic.js";
import { parseQuery } from "./query.js";
const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

const DIAC = /[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED]/;
const NORM = { "أ": "ا", "إ": "ا", "آ": "ا", "ٱ": "ا", "ى": "ي", "ئ": "ي", "ؤ": "و", "ة": "ه" };
const MARKS_RE = "[\\u0610-\\u061A\\u064B-\\u065F\\u0670\\u06D6-\\u06ED\\u0640]*";

export function stripTags(html) {
  return String(html == null ? "" : html)
    .replace(/<(script|style)[^>]*>[\s\S]*?<\/\1\s*>/gi, " ")
    .replace(/<[^>]*>/g, " ")
    .replace(/&nbsp;/g, " ").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&amp;/g, "&");
}

// نفس ناتج normalizeArabic مع جدول يربط كل حرف في الناتج بموضعه في النص الأصلي
export function normalizeWithMap(text) {
  const s = String(text == null ? "" : text);
  const out = [], map = [];
  let prevSpace = true;
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    if (ch === "\u0640" || DIAC.test(ch)) continue;
    if (/\s/.test(ch)) { if (!prevSpace) { out.push(" "); map.push(i); prevSpace = true; } continue; }
    out.push(NORM[ch] || ch);
    map.push(i);
    prevSpace = false;
  }
  if (out.length && out[out.length - 1] === " ") { out.pop(); map.pop(); }
  return { norm: out.join(""), map };
}

const escRe = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

function termRegex(term, exact) {
  const body = escRe(term.text).replace(/ /g, "\\s+");
  return new RegExp(exact ? `(?<![\\p{L}\\p{N}])${body}(?![\\p{L}\\p{N}])` : body, "gu");
}

// يبني دالة مطابقة لنص صفحة: تعيد null أو { score, start, len, norm, map }
export function compileMatcher(parsed, { exact = false } = {}) {
  const pos = parsed.positives.map((t) => ({ t, re: termRegex(t, exact) }));
  const neg = parsed.negatives.map((t) => ({ t, re: termRegex(t, exact) }));
  if (!pos.length) return () => null;
  return function match(text) {
    const { norm, map } = normalizeWithMap(text);
    if (!norm) return null;
    for (const n of neg) { n.re.lastIndex = 0; if (n.re.test(norm)) return null; }
    let score = 0, start = Infinity, len = 0;
    for (const p of pos) {
      p.re.lastIndex = 0;
      let count = 0, first = -1, firstLen = 0, m;
      while ((m = p.re.exec(norm)) && count < 50) {
        if (m[0].length === 0) { p.re.lastIndex++; continue; }
        if (first < 0) { first = m.index; firstLen = m[0].length; }
        count++;
      }
      if (!count) return null;
      score += 1 + Math.log2(1 + count) + (p.t.phrase ? 0.5 : 0);
      if (first < start) { start = first; len = firstLen; }
    }
    return { score, start, len, norm, map };
  };
}

// مقتطف نصي من الأصل حول أول مطابقة (يحفظ التشكيل)
export function makeSnippet(original, hit, { before = 70, after = 110 } = {}) {
  const s = String(original);
  const a = hit.map[hit.start];
  const lastIdx = Math.min(hit.start + hit.len - 1, hit.map.length - 1);
  const b = hit.map[lastIdx] + 1;
  let from = Math.max(0, a - before), to = Math.min(s.length, b + after);
  if (from > 0) { const sp = s.indexOf(" ", from); if (sp >= 0 && sp < a) from = sp + 1; }
  if (to < s.length) { const sp = s.lastIndexOf(" ", to); if (sp > b) to = sp; }
  return (from > 0 ? "… " : "") + s.slice(from, to).replace(/\s+/g, " ").trim() + (to < s.length ? " …" : "");
}

// تعبير نمطي يطابق الكلمة بكل صيغ الهمزات والتاء المربوطة والياء والتشكيل
export function buildHighlightRegex(terms) {
  const cls = { "ا": "[اأإآٱ]", "ي": "[يىئ]", "و": "[وؤ]", "ه": "[هة]" };
  const parts = [];
  for (const term of terms) {
    const norm = normalizeArabic(term);
    if (!norm) continue;
    let p = "";
    for (const ch of Array.from(norm)) {
      if (ch === " ") { p += "\\s+"; continue; }
      p += (cls[ch] || escRe(ch)) + MARKS_RE;
    }
    parts.push(p);
  }
  return parts.length ? new RegExp(parts.join("|"), "g") : null;
}

// يميّز الكلمات في HTML سليم الأوسمة (يعدّل أجزاء النص فقط)
export function highlightHtml(html, terms) {
  const re = buildHighlightRegex(terms);
  if (!re) return html;
  return String(html).split(/(<[^>]*>)/).map((seg) => (seg.startsWith("<") ? seg : seg.replace(re, (m) => (m.trim() ? `<mark class="hl">${m}</mark>` : m)))).join("");
}

// مقتطف جاهز للعرض (نص مهرَّب + تمييز)
export function snippetHtml(original, hit, parsed) {
  return highlightHtml(esc(makeSnippet(original, hit)), parsed.positives.map((t) => t.text));
}

export function highlightTermsOf(q) {
  return parseQuery(q).positives.map((t) => t.text);
}

// يمرّ على صفحات قاعدة كتاب على دفعات ويجمع المطابقات. db: كائن له all(sql)
export async function searchDb(db, parsed, { exact = false, perBook = 50, batch = 300, bookId = null, yieldFn = null } = {}) {
  const match = compileMatcher(parsed, { exact });
  const hits = [];
  let last = -Infinity, index = 0;
  for (;;) {
    const rows = db.all("SELECT id, part, page, body, foot FROM page WHERE id > " + Number(last === -Infinity ? -1e15 : last) + " ORDER BY id LIMIT " + Number(batch));
    if (!rows.length) break;
    for (const r of rows) {
      last = r.id;
      const text = stripTags(r.body) + (r.foot ? "\n" + r.foot : "");
      const m = match(text);
      if (m && hits.length < perBook) {
        hits.push({ bookId, pageId: r.id, pageIndex: index, part: r.part, page: r.page, score: m.score, snippet: snippetHtml(text, m, parsed) });
      }
      index++;
    }
    if (hits.length >= perBook) break;
    if (yieldFn) await yieldFn();
  }
  return hits;
}
