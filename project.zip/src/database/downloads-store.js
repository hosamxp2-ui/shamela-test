// تخزين التنزيلات في IndexedDB: سجل لكل كتاب + قطع بايتات مضغوطة (كما هي على الخادم).
import { openDb } from "./idb.js";

function run(storeNames, mode, work) {
  return openDb().then((db) => new Promise((resolve, reject) => {
    const tx = db.transaction(storeNames, mode);
    const out = work(tx);
    tx.oncomplete = () => resolve(out && "result" in out ? out.result : undefined);
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error);
  }));
}

export const idbStore = {
  putChunk: (id, n, bytes) => run("chunks", "readwrite", (tx) => { tx.objectStore("chunks").put(bytes, id + ":" + n); }),
  getChunk: (id, n) => run("chunks", "readonly", (tx) => tx.objectStore("chunks").get(id + ":" + n)),
  deleteChunks: (id) => run("chunks", "readwrite", (tx) => {
    tx.objectStore("chunks").delete(IDBKeyRange.bound(id + ":", id + ":\uffff"));
  }),
  getRecord: (id) => run("downloads", "readonly", (tx) => tx.objectStore("downloads").get(id)),
  putRecord: (rec) => run("downloads", "readwrite", (tx) => { tx.objectStore("downloads").put(rec); }),
  deleteRecord: (id) => run("downloads", "readwrite", (tx) => { tx.objectStore("downloads").delete(id); }),
  allRecords: () => run("downloads", "readonly", (tx) => tx.objectStore("downloads").getAll()),

  async storageInfo() {
    try {
      const e = await navigator.storage.estimate();
      return { usage: e.usage || 0, quota: e.quota || 0 };
    } catch (_) { return null; }
  },
  async requestPersistence() {
    try { return await navigator.storage.persist(); } catch (_) { return false; }
  }
};
