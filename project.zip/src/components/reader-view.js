// قوالب HTML للقارئ (دوال نقية).
import { t } from "../strings.js";
import { esc } from "../reader/content.js";
import { FONTS, RANGES } from "../modules/settings.js";

export function readerShellHtml({ title }) {
  return `<div class="reader" id="reader">
    <header class="r-bar" id="r-top">
      <button class="r-btn" data-r="back">${esc(t("reader.back"))}</button>
      <span class="r-title">${esc(title)}</span>
      <button class="r-btn" data-r="settings">${esc(t("reader.settings"))}</button>
    </header>
    <div class="r-scroll" id="r-scroll"><article class="r-page" id="r-page"><p class="r-msg">${esc(t("reader.loading"))}</p></article></div>
    <div class="r-dim" id="r-dim"></div>
    ${floatHtml()}
    <footer class="r-bar" id="r-bottom">
      <button class="r-btn" data-r="prev">${esc(t("reader.prev"))}</button>
      <input type="range" id="r-slider" min="0" max="0" value="0" aria-label="${esc(t("reader.page", { p: "" }))}">
      <button class="r-btn" data-r="next">${esc(t("reader.next"))}</button>
      <span class="r-pos" id="r-pos"></span>
    </footer>
    <div class="r-sheet" id="r-sheet" hidden></div>
  </div>`;
}

export function partLabel(part) {
  const p = String(part == null ? "" : part).trim();
  if (!p) return "";
  return /^\d+$/.test(p) ? t("reader.partLabel", { p }) : p;
}

export function pageHtml(page, rendered) {
  const meta = [partLabel(page.part), page.page != null ? t("reader.page", { p: page.page }) : ""].filter(Boolean).join(" • ");
  const notes = rendered.notesHtml ? `<section class="r-notes"><h3>${esc(t("reader.notesTitle"))}</h3>${rendered.notesHtml}</section>` : "";
  return `<div class="r-meta">${esc(meta)}</div><div class="r-text">${rendered.bodyHtml}</div>${notes}`;
}

export function tocHtml(toc) {
  if (!toc.length) return `<p class="r-msg">${esc(t("reader.noToc"))}</p>`;
  return `<div class="toc">${toc.map((x) =>
    `<button class="toc-item" style="padding-inline-start:${12 + Math.min(x.depth, 6) * 16}px" data-toc="${x.id}" data-page="${x.page}">${esc(x.text)}</button>`).join("")}</div>`;
}

export function sheetHtml(title, inner) {
  return `<div class="box" role="dialog"><div class="box-head"><h3>${esc(title)}</h3><button class="r-btn" data-r="close-sheet">${esc(t("reader.close"))}</button></div>${inner}</div>`;
}

export function footnoteHtml(n, text) {
  return `<p class="fn-text">${esc(text)}</p><button class="r-btn" data-r="to-text" data-fn="${esc(n)}">${esc(t("reader.toText"))}</button>`;
}

const range = (name, label, value, [min, max], step) =>
  `<label class="set"><span>${esc(label)}</span><input type="range" data-set="${name}" min="${min}" max="${max}" step="${step}" value="${value}"><output>${value}</output></label>`;

export function settingsHtml(s, availableFonts, { compact = false } = {}) {
  const fonts = Object.keys(FONTS).filter((k) => availableFonts[k])
    .map((k) => `<option value="${k}"${k === s.font ? " selected" : ""}>${esc(t("reader.set.fonts." + k))}</option>`).join("");
  const seg = (name, items, cur) => `<div class="seg">${items.map(([v, label]) =>
    `<button class="r-btn${String(v) === String(cur) ? " on" : ""}" data-seg="${name}" data-value="${v}">${esc(label)}</button>`).join("")}</div>`;
  const custom = s.theme === "custom"
    ? `<div class="colors">${["bg", "fg", "accent"].map((k) =>
      `<label class="set"><span>${esc(t("reader.set." + k))}</span><input type="color" data-set="${k}" value="${s.custom[k]}"></label>`).join("")}</div>` : "";
  return `
    <label class="set"><span>${esc(t("reader.set.font"))}</span><select data-set="font">${fonts}</select></label>
    <div class="set"><span>${esc(t("reader.set.weight"))}</span>${seg("weight", [[400, t("reader.set.normal")], [700, t("reader.set.bold")]], s.weight)}</div>
    ${range("size", t("reader.set.size"), s.size, RANGES.size, 1)}
    ${range("line", t("reader.set.line"), s.line, RANGES.line, 0.1)}
    ${range("para", t("reader.set.para"), s.para, RANGES.para, 0.1)}
    ${range("width", t("reader.set.width"), s.width, RANGES.width, 1)}
    ${range("margin", t("reader.set.margin"), s.margin, RANGES.margin, 1)}
    <div class="set"><span>${esc(t("reader.set.theme"))}</span>${seg("theme", [["app", t("reader.set.app")], ["light", t("reader.set.light")], ["dark", t("reader.set.dark")], ["oled", t("reader.set.oled")], ["sepia", t("reader.set.sepia")], ["custom", t("reader.set.custom")]], s.theme)}</div>
    ${custom}
    <label class="set check"><input type="checkbox" data-set="showNotes"${s.showNotes ? " checked" : ""}><span>${esc(t("reader.set.showNotes"))}</span></label>
    ${compact ? "" : `<div class="set"><span>${esc(t("reader.set.orientation"))}</span>${seg("orientation", [["auto", t("reader.set.auto")], ["portrait", t("reader.set.portrait")], ["landscape", t("reader.set.landscape")]], s.orientation)}</div>
    <p class="r-msg" id="r-note"></p>
    <div class="row2"><button class="r-btn" data-r="fullscreen">${esc(t("reader.fullscreen"))}</button><button class="r-btn" data-r="reset">${esc(t("reader.set.reset"))}</button></div>`}`;
}

// ---------- شريط الأدوات العائم والنوافذ (الدفعة 2) ----------
export function floatHtml({ bookmarked = false, collapsed = false, hadith = false } = {}) {
  const b = (act, label, extra = "") => `<button class="r-btn tb" data-r="${act}"${extra}>${label}</button>`;
  return `<div class="r-float${collapsed ? " collapsed" : ""}" id="r-float">
    <button class="r-btn tg" data-r="float-toggle" aria-label="${esc(collapsed ? t("reader.tb.expand") : t("reader.tb.collapse"))}">${collapsed ? "⋯" : "▾"}</button>
    <div class="r-qa">${b("toc", "☰ " + esc(t("reader.tb.toc")))}${b("notes", "✎ " + esc(t("reader.tb.notes")))}${b("info", "ⓘ " + esc(t("reader.tb.info")))}${b("search", "⌕ " + esc(t("reader.tb.search")))}${hadith ? b("hadith", "❝ " + esc(t("reader.tb.hadith"))) : ""}</div>
    <div class="r-qc">${b("size-down", "A−", ` aria-label="${esc(t("reader.tb.sizeDown"))}"`)}${b("size-up", "A+", ` aria-label="${esc(t("reader.tb.sizeUp"))}"`)}${b("fonts", esc(t("reader.tb.fonts")), ` aria-label="${esc(t("reader.tb.fonts"))}"`)}${b("bright", "☀", ` aria-label="${esc(t("reader.tb.bright"))}"`)}${b("night", "☾", ` aria-label="${esc(t("reader.tb.night"))}"`)}${b("bookmark", bookmarked ? "★" : "☆", ` aria-label="${esc(t("reader.tb.bookmark"))}"${bookmarked ? ' data-on="1"' : ""}`)}</div>
  </div>`;
}

export function marksHtml(marks) {
  if (!marks || (!marks.bookmark && !marks.notes)) return "";
  return `<span class="r-marks">${marks.bookmark ? "★" : ""}${marks.notes ? " ✎" + marks.notes : ""}</span>`;
}

export function pageHtmlWithMarks(page, rendered, marks) {
  const meta = [partLabel(page.part), page.page != null ? t("reader.page", { p: page.page }) : ""].filter(Boolean).join(" • ");
  const notes = rendered.notesHtml ? `<section class="r-notes"><h3>${esc(t("reader.notesTitle"))}</h3>${rendered.notesHtml}</section>` : "";
  return `<div class="r-meta">${esc(meta)} ${marksHtml(marks)}</div><div class="r-text">${rendered.bodyHtml}</div>${notes}`;
}

export function tocSheetInner() {
  return `<input id="toc-filter" type="search" class="r-input" placeholder="${esc(t("reader.toc2.filter"))}" autocomplete="off">
    <div class="row2"><button class="r-btn" data-toc-all="expand">${esc(t("reader.toc2.expandAll"))}</button><button class="r-btn" data-toc-all="collapse">${esc(t("reader.toc2.collapseAll"))}</button></div>
    <div id="toc-list"></div>`;
}

export function tocListHtml(rows, currentId) {
  if (!rows.length) return `<p class="r-msg">${esc(t("reader.toc2.none"))}</p>`;
  return `<div class="toc">${rows.map((r) =>
    `<div class="toc-row${r.id === currentId ? " cur" : ""}" id="toc-row-${r.id}" style="padding-inline-start:${Math.min(r.depth, 8) * 16}px">` +
    (r.hasChildren ? `<button class="toc-tg" data-tog="${r.id}" aria-label="${esc(r.expanded ? t("reader.tb.collapse") : t("reader.tb.expand"))}">${r.expanded ? "▾" : "▸"}</button>` : `<span class="toc-sp"></span>`) +
    `<button class="toc-item" data-toc="${r.id}" data-page="${r.page}">${esc(r.text)}</button></div>`).join("")}</div>`;
}

export function notesSheetInner(items, hasSelection) {
  const rows = items.length ? items.map((n) => `
    <div class="note-row" data-id="${esc(n.id)}">
      <div class="note-h"><span>${n.kind === "bookmark" ? "★" : "✎"} ${esc(n.label || t("reader.notes.page", { n: n.pageIndex + 1 }))}</span>
        <span class="note-btns"><button class="r-btn mini" data-n="go" data-id="${esc(n.id)}" data-index="${n.pageIndex}">${esc(t("reader.notes.go"))}</button>${n.kind === "note" ? `<button class="r-btn mini" data-n="edit" data-id="${esc(n.id)}">${esc(t("reader.notes.edit"))}</button>` : ""}<button class="r-btn mini" data-n="del" data-id="${esc(n.id)}">${esc(t("reader.notes.del"))}</button></span></div>
      ${n.quote ? `<blockquote>${esc(n.quote)}</blockquote>` : ""}${n.text ? `<p>${esc(n.text)}</p>` : ""}
    </div>`).join("") : `<p class="r-msg">${esc(t("reader.notes.empty"))}</p>`;
  return `<button class="r-btn on wide" data-n="add">${esc(t("reader.notes.add"))}</button>
    <p class="r-msg small">${esc(t("reader.notes.hint"))}</p>${rows}`;
}

export function noteEditorHtml({ quote = "", text = "", editing = false } = {}) {
  return `${quote ? `<p class="r-label">${esc(t("reader.notes.quote"))}</p><blockquote>${esc(quote)}</blockquote>` : ""}
    <textarea id="note-text" class="r-input" rows="5" maxlength="2000" placeholder="${esc(t("reader.notes.placeholder"))}">${esc(text)}</textarea>
    <p class="r-msg bad" id="note-err" hidden>${esc(t("reader.notes.needText"))}</p>
    <div class="row2"><button class="r-btn on" data-n="save"${editing ? ' data-editing="1"' : ""}>${esc(t("reader.notes.save"))}</button><button class="r-btn" data-n="cancel">${esc(t("reader.notes.cancel"))}</button></div>`;
}

export function infoHtml(info) {
  const row = (k, v) => (v ? `<dt>${esc(t(k))}</dt><dd>${v}</dd>` : "");
  const authors = (info.authors || []).map((a) => esc(a.name) + (a.death ? ` <span class="s">(${esc(t("reader.info.died", { y: a.death }))})</span>` : "")).join("، ");
  return `<dl class="info">
      ${row("reader.info.author", authors)}${row("reader.info.category", esc(info.category || ""))}
      ${row("reader.info.pages", info.pages != null ? esc(String(info.pages)) : "")}${row("reader.info.titles", info.titles != null ? esc(String(info.titles)) : "")}
      ${row("reader.info.size", esc(info.size || ""))}${row("reader.info.rawSize", esc(info.rawSize || ""))}${row("reader.info.added", esc(info.added || ""))}
    </dl>
    <p class="r-msg small">${esc(t("reader.info.missing"))}</p>
    ${info.url ? `<a class="r-btn wide" href="${esc(info.url)}" target="_blank" rel="noopener">${esc(t("reader.info.site"))}</a>` : ""}`;
}

export function fontSheetInner(settings, available) {
  const items = Object.keys(FONTS).filter((k) => available[k]).map((k) =>
    `<button class="font-item${k === settings.font ? " on" : ""}" data-font="${k}" style="font-family:${FONTS[k].family}">${esc(t("reader.set.fonts." + k))} <span class="sample">بسم الله الرحمن الرحيم</span></button>`).join("");
  return `<div class="fonts">${items}</div>`;
}

export function brightnessInner(dim) {
  const pct = Math.round((1 - dim) * 100);
  return `<label class="set"><span>${esc(t("reader.brightTitle"))}</span><input type="range" data-bright min="30" max="100" step="1" value="${pct}"><output>${pct}%</output></label>
    <p class="r-msg small">${esc(t("reader.brightHint"))}</p>`;
}

// نافذة الحديث: view من buildHadithView، وfx = { bookName(id), downloaded(id) } لإبقاء القالب نقيًا
export function hadithSheetInner(items, fx) {
  const step = (x, i) => `<li>${x.name ? esc(x.name) + (x.death ? ` <span class="s">(${esc(t("reader.hadith.died", { y: x.death }))})</span>` : "") : esc(t("reader.hadith.unknownRawi", { id: x.id }))}</li>`;
  const one = (it) => {
    const chains = !it.hasLinks ? `<p class="r-msg small">${esc(t("reader.hadith.needImport"))}</p>`
      : it.totalChains === 0 ? `<p class="r-msg small">${esc(t("reader.hadith.noChains"))}</p>`
      : `<h4>${esc(t("reader.hadith.isnad"))}</h4>` + it.chains.map((c) => `<ol class="isnad">${c.steps.map(step).join("")}</ol>`).join("")
        + (it.moreChains ? `<p class="r-msg small">${esc(t("reader.hadith.more", { n: it.moreChains }))}</p>` : "");
    const others = !it.hasLinks ? "" : `<h4>${esc(t("reader.hadith.others"))}</h4>` + (it.groups.length ? it.groups.map((g) => {
      const dl = fx.downloaded(g.book);
      const links = g.pages.slice(0, 12).map((p) => dl
        ? `<a class="r-btn mini" href="#/read/${g.book}?pid=${p}">${esc(t("reader.hadith.spot", { p }))}</a>`
        : `<span class="s">${esc(t("reader.hadith.spot", { p }))}</span>`).join(" ");
      return `<div class="hd-book"><div class="hd-name">${esc(fx.bookName(g.book))}${dl ? "" : ` <span class="s">(${esc(t("reader.hadith.notDl"))})</span>`}</div>${links}${dl ? "" : ` <a class="r-btn mini" href="#/book/${g.book}">${esc(t("reader.hadith.open"))}</a>`}</div>`;
    }).join("") : `<p class="r-msg small">${esc(t("reader.hadith.noOthers"))}</p>`)
      + (it.groups.length ? `<p class="r-msg small">${esc(t("reader.hadith.spotHint"))}</p>` : "");
    return `<section class="hd-item"><h3>${esc(t("reader.hadith.key", { k: it.key }))}</h3>${chains}${others}</section>`;
  };
  return items.map(one).join("");
}
