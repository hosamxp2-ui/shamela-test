// قوالب HTML للقارئ (دوال نقية).
import { t } from "../strings.js";
import { esc } from "../reader/content.js";
import { FONTS, RANGES } from "../modules/settings.js";

// أيقونات خطية (تأخذ لون النص)
const svg = (d, extra = "") => `<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"${extra}>${d}</svg>`;
export const ICONS = {
  back: svg('<path d="M4 12h15M13 6l6 6-6 6"/>'),
  search: svg('<circle cx="11" cy="11" r="6.5"/><path d="M16 16l5 5"/>'),
  toc: svg('<rect x="3.5" y="4" width="17" height="16" rx="2"/><path d="M3.5 9h17M3.5 14h17M9 4v16"/>'),
  more: svg('<circle cx="12" cy="5" r="1.4" fill="currentColor"/><circle cx="12" cy="12" r="1.4" fill="currentColor"/><circle cx="12" cy="19" r="1.4" fill="currentColor"/>'),
  prev: svg('<path d="M9 5l7 7-7 7"/>'),
  next: svg('<path d="M15 5l-7 7 7 7"/>'),
  bm: (on) => svg('<path d="M6.5 3.5h11v17L12 16.5l-5.5 4z"/>').replace('fill="none"', on ? 'fill="currentColor"' : 'fill="none"')
};

export function bookmarkBtnHtml(on = false) {
  return `<button class="r-ic" id="r-bm" data-r="bookmark" aria-label="${esc(t("reader.tb.bookmark"))}"${on ? ' data-on="1"' : ""}>${ICONS.bm(on)}</button>`;
}

// «ج1 · ص165» فوق «163/16700»: الأرقام تُعزل اتجاهيًا
export function posHtml(label, i, n) {
  return `<span class="pl">${esc(label || "")}</span><bdi class="pn" dir="ltr">${Number(i)}/${Number(n)}</bdi>`;
}

export function readerShellHtml({ title }) {
  const ic = (act, icon, label) => `<button class="r-ic" data-r="${act}" aria-label="${esc(label)}">${icon}</button>`;
  return `<div class="reader" id="reader">
    <header class="r-bar r-pill" id="r-top">
      ${ic("back", ICONS.back, t("reader.back"))}
      <div class="r-ttl"><b class="r-title">${esc(title)}</b><small class="r-sub" id="r-sub"></small></div>
      ${ic("search", ICONS.search, t("reader.tb.search"))}
      <button class="r-ic" data-r="settings" aria-label="${esc(t("reader.settings"))}"><span class="tt">Tt</span></button>
      ${bookmarkBtnHtml(false)}
      ${ic("toc", ICONS.toc, t("reader.tb.toc"))}
      ${ic("more", ICONS.more, t("reader.tb.more"))}
    </header>
    <div class="r-scroll" id="r-scroll"><article class="r-page" id="r-page"><p class="r-msg">${esc(t("reader.loading"))}</p></article></div>
    <div class="r-dim" id="r-dim"></div>
    ${floatHtml()}
    ${selBarHtml()}
    <footer class="r-bar r-pillb" id="r-bottom">
      <input type="range" id="r-slider" min="0" max="0" value="0" aria-label="${esc(t("reader.page", { p: "" }))}">
      <div class="r-nav">
        ${ic("prev", ICONS.prev, t("reader.prev"))}
        <span class="r-pos" id="r-pos"></span>
        ${ic("next", ICONS.next, t("reader.next"))}
      </div>
    </footer>
    <div class="r-sheet" id="r-sheet" hidden></div>
  </div>`;
}

export function partLabel(part) {
  const p = String(part == null ? "" : part).trim();
  if (!p) return "";
  return /^\d+$/.test(p) ? t("reader.partLabel", { p }) : p;
}

export function pageHtml(page, rendered) {
  const meta = [partLabel(page.part), page.page != null ? t("reader.page", { p: page.page }) : ""].filter(Boolean).join(" • ");
  const notes = rendered.notesHtml ? `<section class="r-notes"><h3>${esc(t("reader.notesTitle"))}</h3>${rendered.notesHtml}</section>` : "";
  return `<div class="r-meta">${esc(meta)}</div><div class="r-text">${rendered.bodyHtml}</div>${notes}`;
}

export function tocHtml(toc) {
  if (!toc.length) return `<p class="r-msg">${esc(t("reader.noToc"))}</p>`;
  return `<div class="toc">${toc.map((x) =>
    `<button class="toc-item" style="padding-inline-start:${12 + Math.min(x.depth, 6) * 16}px" data-toc="${x.id}" data-page="${x.page}">${esc(x.text)}</button>`).join("")}</div>`;
}

export function sheetHtml(title, inner) {
  return `<div class="box" role="dialog"><div class="box-head"><h3>${esc(title)}</h3><button class="r-btn" data-r="close-sheet">${esc(t("reader.close"))}</button></div>${inner}</div>`;
}

export function footnoteHtml(n, text) {
  return `<p class="fn-text">${esc(text)}</p><button class="r-btn" data-r="to-text" data-fn="${esc(n)}">${esc(t("reader.toText"))}</button>`;
}

const range = (name, label, value, [min, max], step) =>
  `<label class="set"><span>${esc(label)}</span><input type="range" data-set="${name}" min="${min}" max="${max}" step="${step}" value="${value}"><output>${value}</output></label>`;

export function settingsHtml(s, availableFonts, { compact = false } = {}) {
  const fonts = Object.keys(FONTS).filter((k) => availableFonts[k])
    .map((k) => `<option value="${k}"${k === s.font ? " selected" : ""}>${esc(t("reader.set.fonts." + k))}</option>`).join("");
  const seg = (name, items, cur) => `<div class="seg">${items.map(([v, label]) =>
    `<button class="r-btn${String(v) === String(cur) ? " on" : ""}" data-seg="${name}" data-value="${v}">${esc(label)}</button>`).join("")}</div>`;
  const custom = s.theme === "custom"
    ? `<div class="colors">${["bg", "fg", "accent"].map((k) =>
      `<label class="set"><span>${esc(t("reader.set." + k))}</span><input type="color" data-set="${k}" value="${s.custom[k]}"></label>`).join("")}</div>` : "";
  return `
    <label class="set"><span>${esc(t("reader.set.font"))}</span><select data-set="font">${fonts}</select></label>
    <div class="set"><span>${esc(t("reader.set.weight"))}</span>${seg("weight", [[400, t("reader.set.normal")], [700, t("reader.set.bold")]], s.weight)}</div>
    ${range("size", t("reader.set.size"), s.size, RANGES.size, 1)}
    ${range("line", t("reader.set.line"), s.line, RANGES.line, 0.1)}
    ${range("para", t("reader.set.para"), s.para, RANGES.para, 0.1)}
    ${range("width", t("reader.set.width"), s.width, RANGES.width, 1)}
    ${range("margin", t("reader.set.margin"), s.margin, RANGES.margin, 1)}
    <div class="set"><span>${esc(t("reader.set.theme"))}</span>${seg("theme", [["app", t("reader.set.app")], ["light", t("reader.set.light")], ["dark", t("reader.set.dark")], ["oled", t("reader.set.oled")], ["sepia", t("reader.set.sepia")], ["custom", t("reader.set.custom")]], s.theme)}</div>
    ${custom}
    <label class="set check"><input type="checkbox" data-set="showNotes"${s.showNotes ? " checked" : ""}><span>${esc(t("reader.set.showNotes"))}</span></label>
    ${compact ? "" : `<div class="set"><span>${esc(t("reader.set.orientation"))}</span>${seg("orientation", [["auto", t("reader.set.auto")], ["portrait", t("reader.set.portrait")], ["landscape", t("reader.set.landscape")]], s.orientation)}</div>
    <p class="r-msg" id="r-note"></p>
    <div class="row2"><button class="r-btn" data-r="fullscreen">${esc(t("reader.fullscreen"))}</button><button class="r-btn" data-r="reset">${esc(t("reader.set.reset"))}</button></div>`}`;
}

// ---------- شريط الأدوات العائم والنوافذ (الدفعة 2) ----------
// شريط يظهر قرب النص المحدد: تظليل مباشر أو ملاحظة (موضعه يحسبه المتحكم)
export function selBarHtml() {
  return `<div class="r-selbar" id="r-selbar" hidden><button class="r-chip" data-r="sel-hl"><span class="hlsw">▇</span> ${esc(t("reader.sel.hl"))}</button><button class="r-chip" data-r="sel-note">✎ ${esc(t("reader.sel.note"))}</button></div>`;
}

// أزرار سياقية تعلو الشريط السفلي (تظهر فقط عند وجود حديث للصفحة)
export function floatHtml({ hadith = false } = {}) {
  const chip = hadith ? `<button class="r-chip" data-r="hadith">❝ ${esc(t(hadith === "guess" ? "reader.tb.hadithGuess" : "reader.tb.hadith"))}</button>` : "";
  return `<div class="r-float" id="r-float">${chip}</div>`;
}

export function marksHtml(marks) {
  if (!marks || (!marks.bookmark && !marks.notes)) return "";
  return `<span class="r-marks">${marks.bookmark ? "★" : ""}${marks.notes ? " ✎" + marks.notes : ""}</span>`;
}

export function pageHtmlWithMarks(page, rendered, marks) {
  const meta = [partLabel(page.part), page.page != null ? t("reader.page", { p: page.page }) : ""].filter(Boolean).join(" • ");
  const notes = rendered.notesHtml ? `<section class="r-notes"><h3>${esc(t("reader.notesTitle"))}</h3>${rendered.notesHtml}</section>` : "";
  return `<div class="r-meta">${esc(meta)} ${marksHtml(marks)}</div><div class="r-text">${rendered.bodyHtml}</div>${notes}`;
}

export function tocSheetInner() {
  return `<input id="toc-filter" type="search" class="r-input" placeholder="${esc(t("reader.toc2.filter"))}" autocomplete="off">
    <div class="row2"><button class="r-btn" data-toc-all="expand">${esc(t("reader.toc2.expandAll"))}</button><button class="r-btn" data-toc-all="collapse">${esc(t("reader.toc2.collapseAll"))}</button></div>
    <div id="toc-list"></div>`;
}

export function tocListHtml(rows, currentId) {
  if (!rows.length) return `<p class="r-msg">${esc(t("reader.toc2.none"))}</p>`;
  return `<div class="toc">${rows.map((r) =>
    `<div class="toc-row${r.id === currentId ? " cur" : ""}" id="toc-row-${r.id}" style="padding-inline-start:${Math.min(r.depth, 8) * 16}px">` +
    (r.hasChildren ? `<button class="toc-tg" data-tog="${r.id}" aria-label="${esc(r.expanded ? t("reader.tb.collapse") : t("reader.tb.expand"))}">${r.expanded ? "▾" : "▸"}</button>` : `<span class="toc-sp"></span>`) +
    `<button class="toc-item" data-toc="${r.id}" data-page="${r.page}">${esc(r.text)}</button></div>`).join("")}</div>`;
}

function noteRowHtml(n) {
  const icon = n.kind === "bookmark" ? "★" : n.kind === "highlight" ? "▇" : "✎";
  return `
    <div class="note-row" data-id="${esc(n.id)}">
      <div class="note-h"><span>${icon} ${esc(n.label || t("reader.notes.page", { n: n.pageIndex + 1 }))}</span>
        <span class="note-btns"><button class="r-btn mini" data-n="go" data-id="${esc(n.id)}" data-index="${n.pageIndex}">${esc(t("reader.notes.go"))}</button>${n.kind === "note" ? `<button class="r-btn mini" data-n="edit" data-id="${esc(n.id)}">${esc(t("reader.notes.edit"))}</button>` : ""}<button class="r-btn mini" data-n="del" data-id="${esc(n.id)}">${esc(t("reader.notes.del"))}</button></span></div>
      ${n.quote ? `<blockquote>${esc(n.quote)}</blockquote>` : ""}${n.text ? `<p>${esc(n.text)}</p>` : ""}
    </div>`;
}

// محتوى تبويب من: marks (العلامات) | hl (التظليلات) | notes (الملاحظات)
export function listTabInner(tab, items) {
  const kind = tab === "marks" ? "bookmark" : tab === "hl" ? "highlight" : "note";
  const mine = items.filter((n) => n.kind === kind);
  const head = tab === "notes" ? `<button class="r-btn on wide" data-n="add">${esc(t("reader.notes.add"))}</button><p class="r-msg small">${esc(t("reader.notes.hint"))}</p>`
    : tab === "hl" ? `<button class="r-btn on wide" data-n="hl-add">${esc(t("reader.hl.add"))}</button><p class="r-msg small">${esc(t("reader.hl.hint"))}</p>` : "";
  const empty = tab === "marks" ? t("reader.marksEmpty") : tab === "hl" ? t("reader.hl.empty") : t("reader.notes.empty");
  return head + (mine.length ? mine.map(noteRowHtml).join("") : `<p class="r-msg">${esc(empty)}</p>`);
}

// الصندوق ذو التبويبات الأربعة (الفهرس | العلامات | التظليلات | الملاحظات)
export function tabsBoxHtml(active, body) {
  const tab = (k) => `<button class="${k === active ? "on" : ""}" data-tab="${k}">${esc(t("reader.tabs." + k))}</button>`;
  return `<div class="box tabbox" role="dialog"><div class="tabs-head"><div class="tabs-bar">${tab("toc")}${tab("marks")}${tab("hl")}${tab("notes")}</div><button class="r-ic xclose" data-r="close-sheet" aria-label="${esc(t("reader.close"))}">✕</button></div><div class="tabs-body">${body}</div></div>`;
}

// قائمة «المزيد» (⋮)
export function moreInner() {
  const row = (act, label) => `<button class="r-btn wide more-row" data-r="${act}">${esc(label)}</button>`;
  return `<div class="more">${row("info", "ⓘ " + t("reader.tb.info"))}
    <div class="row2"><button class="r-btn" data-r="size-down" aria-label="${esc(t("reader.tb.sizeDown"))}">A−</button><button class="r-btn" data-r="size-up" aria-label="${esc(t("reader.tb.sizeUp"))}">A+</button></div>
    <div class="row2"><button class="r-btn" data-r="bright">☀ ${esc(t("reader.tb.bright"))}</button><button class="r-btn" data-r="night">☾ ${esc(t("reader.tb.night"))}</button></div>
    ${row("hl-sel", "▇ " + t("reader.hl.add"))}${row("fonts", t("reader.tb.fonts"))}</div>`;
}

export function noteEditorHtml({ quote = "", text = "", editing = false } = {}) {
  return `${quote ? `<p class="r-label">${esc(t("reader.notes.quote"))}</p><blockquote>${esc(quote)}</blockquote>` : ""}
    <textarea id="note-text" class="r-input" rows="5" maxlength="2000" placeholder="${esc(t("reader.notes.placeholder"))}">${esc(text)}</textarea>
    <p class="r-msg bad" id="note-err" hidden>${esc(t("reader.notes.needText"))}</p>
    <div class="row2"><button class="r-btn on" data-n="save"${editing ? ' data-editing="1"' : ""}>${esc(t("reader.notes.save"))}</button><button class="r-btn" data-n="cancel">${esc(t("reader.notes.cancel"))}</button></div>`;
}

export function infoHtml(info) {
  const row = (k, v) => (v ? `<dt>${esc(t(k))}</dt><dd>${v}</dd>` : "");
  const authors = (info.authors || []).map((a) => esc(a.name) + (a.death ? ` <span class="s">(${esc(t("reader.info.died", { y: a.death }))})</span>` : "")).join("، ");
  return `<dl class="info">
      ${row("reader.info.author", authors)}${row("reader.info.category", esc(info.category || ""))}
      ${row("reader.info.pages", info.pages != null ? esc(String(info.pages)) : "")}${row("reader.info.titles", info.titles != null ? esc(String(info.titles)) : "")}
      ${row("reader.info.size", esc(info.size || ""))}${row("reader.info.rawSize", esc(info.rawSize || ""))}${row("reader.info.added", esc(info.added || ""))}
    </dl>
    <p class="r-msg small">${esc(t("reader.info.missing"))}</p>
    ${info.url ? `<a class="r-btn wide" href="${esc(info.url)}" target="_blank" rel="noopener">${esc(t("reader.info.site"))}</a>` : ""}`;
}

export function fontSheetInner(settings, available) {
  const items = Object.keys(FONTS).filter((k) => available[k]).map((k) =>
    `<button class="font-item${k === settings.font ? " on" : ""}" data-font="${k}" style="font-family:${FONTS[k].family}">${esc(t("reader.set.fonts." + k))} <span class="sample">بسم الله الرحمن الرحيم</span></button>`).join("");
  return `<div class="fonts">${items}</div>`;
}

export function brightnessInner(dim) {
  const pct = Math.round((1 - dim) * 100);
  return `<label class="set"><span>${esc(t("reader.brightTitle"))}</span><input type="range" data-bright min="30" max="100" step="1" value="${pct}"><output>${pct}%</output></label>
    <p class="r-msg small">${esc(t("reader.brightHint"))}</p>`;
}

// نافذة الحديث: view من buildHadithView، وfx = { bookName(id), downloaded(id) } لإبقاء القالب نقيًا
export function hadithSheetInner(items, fx) {
  const step = (x, i) => `<li>${x.name ? esc(x.name) + (x.death ? ` <span class="s">(${esc(t("reader.hadith.died", { y: x.death }))})</span>` : "") : esc(t("reader.hadith.unknownRawi", { id: x.id }))}</li>`;
  const one = (it) => {
    const chains = !it.hasLinks ? `<p class="r-msg small">${esc(t("reader.hadith.needImport"))}</p>`
      : it.totalChains === 0 ? `<p class="r-msg small">${esc(t("reader.hadith.noChains"))}</p>`
      : `<h4>${esc(t("reader.hadith.isnad"))}</h4>` + it.chains.map((c) => `<ol class="isnad">${c.steps.map(step).join("")}</ol>`).join("")
        + (it.moreChains ? `<p class="r-msg small">${esc(t("reader.hadith.more", { n: it.moreChains }))}</p>` : "");
    const others = !it.hasLinks ? "" : `<h4>${esc(t("reader.hadith.others"))}</h4>` + (it.groups.length ? it.groups.map((g) => {
      const dl = fx.downloaded(g.book);
      const links = g.pages.slice(0, 12).map((p) => dl
        ? `<a class="r-btn mini" href="#/read/${g.book}?pid=${p}">${esc(t("reader.hadith.spot", { p }))}</a>`
        : `<span class="s">${esc(t("reader.hadith.spot", { p }))}</span>`).join(" ");
      return `<div class="hd-book"><div class="hd-name">${esc(fx.bookName(g.book))}${dl ? "" : ` <span class="s">(${esc(t("reader.hadith.notDl"))})</span>`}</div>${links}${dl ? "" : ` <a class="r-btn mini" href="#/book/${g.book}">${esc(t("reader.hadith.open"))}</a>`}</div>`;
    }).join("") : `<p class="r-msg small">${esc(t("reader.hadith.noOthers"))}</p>`)
      + (it.groups.length ? `<p class="r-msg small">${esc(t("reader.hadith.spotHint"))}</p>` : "");
    return `<section class="hd-item"><h3>${esc(t("reader.hadith.key", { k: it.key }))}</h3>${chains}${others}</section>`;
  };
  return items.map(one).join("");
}

// نافذة الآية. info: { loc, text, conf, groups, note, hasLinks }. fx: { bookName, downloaded }
export function ayahSheetInner(info, fx) {
  const groups = !info.hasLinks ? `<p class="r-msg small">${esc(t("reader.ayah.needImport"))}</p>`
    : info.groups.length ? `<h4>${esc(t("reader.ayah.tafsirs"))}</h4>` + info.groups.map((g) => {
      const dl = fx.downloaded(g.book);
      const links = g.pages.slice(0, 6).map((p) => dl
        ? `<a class="r-btn mini" href="#/read/${g.book}?pid=${p}">${esc(t("reader.ayah.spot", { p }))}</a>`
        : `<span class="s">${esc(t("reader.ayah.spot", { p }))}</span>`).join(" ");
      return `<div class="hd-book"><div class="hd-name">${esc(fx.bookName(g.book))}${dl ? "" : ` <span class="s">(${esc(t("reader.ayah.notDl"))})</span>`}</div>${links}${dl ? "" : ` <a class="r-btn mini" href="#/book/${g.book}">${esc(t("reader.ayah.open"))}</a>`}</div>`;
    }).join("") + `<p class="r-msg small">${esc(t("reader.ayah.spotHint"))}</p>` : `<p class="r-msg small">${esc(t("reader.ayah.noTafsir"))}</p>`;
  const local = (info.local && info.local.length) ? `<h4>${esc(t("reader.ayah.localTitle"))}</h4><p class="r-msg small">${esc(t("reader.ayah.localNote"))}</p>` + info.local.map((g) => {
    const dl = fx.downloaded(g.book);
    const links = g.pages.slice(0, 6).map((p) => dl
      ? `<a class="r-btn mini" href="#/read/${g.book}?pid=${p}">${esc(t("reader.ayah.spot", { p }))}</a>`
      : `<span class="s">${esc(t("reader.ayah.spot", { p }))}</span>`).join(" ");
    return `<div class="hd-book"><div class="hd-name">${esc(fx.bookName(g.book))}${g.approx ? ` <span class="s">(${esc(t("reader.ayah.approx"))})</span>` : ""}${dl ? "" : ` <span class="s">(${esc(t("reader.ayah.notDl"))})</span>`}</div>${links}</div>`;
  }).join("") : "";
  if (!info.hasLinks && !info.loc) return `<p class="r-msg small">${esc(t("reader.ayah.needImport"))}</p>`;
  return `<section class="hd-item"><h3>${esc(info.loc)}</h3><p class="ayah-text">${esc(info.text)}</p>
    <p class="r-msg small">${esc(t("reader.ayah.conf." + info.conf))}</p>${info.note ? `<p class="r-msg small">${esc(info.note)}</p>` : ""}${groups}${local}</section>`;
}

export function ayahCandidatesInner(total, cands) {
  return `<p class="r-msg small">${esc(t("reader.ayah.many", { n: total }))}</p>` + cands.map((c) =>
    `<button class="r-btn wide" data-ayah="${c.id}">${esc(c.loc)}<br><span class="s">${esc(c.text)}</span></button>`).join("");
}

// مرشحو المطابقة النصية. items من buildMatchView
export function hadithMatchInner(items, fx) {
  return `<p class="r-msg small">${esc(t("reader.hadith.matchNote"))}</p>` + items.map((it) => {
    const groups = it.groups.length ? it.groups.map((g) => {
      const dl = fx.downloaded(g.book);
      const links = g.pages.slice(0, 6).map((p) => dl
        ? `<a class="r-btn mini" href="#/read/${g.book}?pid=${p}">${esc(t("reader.hadith.spot", { p }))}</a>`
        : `<span class="s">${esc(t("reader.hadith.spot", { p }))}</span>`).join(" ");
      return `<div class="hd-book"><div class="hd-name">${esc(fx.bookName(g.book))}${dl ? "" : ` <span class="s">(${esc(t("reader.hadith.notDl"))})</span>`}</div>${links}${dl ? "" : ` <a class="r-btn mini" href="#/book/${g.book}">${esc(t("reader.hadith.open"))}</a>`}</div>`;
    }).join("") : `<p class="r-msg small">${esc(t("reader.hadith.matchNone"))}</p>`;
    return `<section class="hd-item"><h3>${esc(t("reader.hadith.key", { k: it.key }))} <span class="s">— ${esc(t("reader.hadith.score", { p: it.pct }))}</span></h3>${groups}</section>`;
  }).join("");
}

// رسالة خطأ فتح الكتاب. big = الكتاب فوق الحد التلقائي لكن دون الحد الأقصى: نعرض تحذير الذاكرة وزر «فتحه رغم ذلك»
export function readerErrorHtml(msg, id, big = false) {
  return `<p class="r-msg bad">${esc(msg)}</p>` + (big
    ? `<p class="r-msg small">${esc(t("reader.tooBigWarn"))}</p><p><a class="r-btn" href="#/read/${Number(id)}?force=1">${esc(t("reader.tooBigForce"))}</a></p>` : "");
}
