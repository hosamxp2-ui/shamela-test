// قوالب HTML للقارئ (دوال نقية).
import { t } from "../strings.js";
import { esc } from "../reader/content.js";
import { FONTS, RANGES } from "../modules/settings.js";

export function readerShellHtml({ title }) {
  return `<div class="reader" id="reader">
    <header class="r-bar" id="r-top">
      <button class="r-btn" data-r="back">${esc(t("reader.back"))}</button>
      <span class="r-title">${esc(title)}</span>
      <button class="r-btn" data-r="toc">${esc(t("reader.toc"))}</button>
      <button class="r-btn" data-r="settings">${esc(t("reader.settings"))}</button>
    </header>
    <div class="r-scroll" id="r-scroll"><article class="r-page" id="r-page"><p class="r-msg">${esc(t("reader.loading"))}</p></article></div>
    <footer class="r-bar" id="r-bottom">
      <button class="r-btn" data-r="prev">${esc(t("reader.prev"))}</button>
      <input type="range" id="r-slider" min="0" max="0" value="0" aria-label="${esc(t("reader.page", { p: "" }))}">
      <button class="r-btn" data-r="next">${esc(t("reader.next"))}</button>
      <span class="r-pos" id="r-pos"></span>
    </footer>
    <div class="r-sheet" id="r-sheet" hidden></div>
  </div>`;
}

export function partLabel(part) {
  const p = String(part == null ? "" : part).trim();
  if (!p) return "";
  return /^\d+$/.test(p) ? t("reader.partLabel", { p }) : p;
}

export function pageHtml(page, rendered) {
  const meta = [partLabel(page.part), page.page != null ? t("reader.page", { p: page.page }) : ""].filter(Boolean).join(" • ");
  const notes = rendered.notesHtml ? `<section class="r-notes"><h3>${esc(t("reader.notesTitle"))}</h3>${rendered.notesHtml}</section>` : "";
  return `<div class="r-meta">${esc(meta)}</div><div class="r-text">${rendered.bodyHtml}</div>${notes}`;
}

export function tocHtml(toc) {
  if (!toc.length) return `<p class="r-msg">${esc(t("reader.noToc"))}</p>`;
  return `<div class="toc">${toc.map((x) =>
    `<button class="toc-item" style="padding-inline-start:${12 + Math.min(x.depth, 6) * 16}px" data-toc="${x.id}" data-page="${x.page}">${esc(x.text)}</button>`).join("")}</div>`;
}

export function sheetHtml(title, inner) {
  return `<div class="box" role="dialog"><div class="box-head"><h3>${esc(title)}</h3><button class="r-btn" data-r="close-sheet">${esc(t("reader.close"))}</button></div>${inner}</div>`;
}

export function footnoteHtml(n, text) {
  return `<p class="fn-text">${esc(text)}</p><button class="r-btn" data-r="to-text" data-fn="${esc(n)}">${esc(t("reader.toText"))}</button>`;
}

const range = (name, label, value, [min, max], step) =>
  `<label class="set"><span>${esc(label)}</span><input type="range" data-set="${name}" min="${min}" max="${max}" step="${step}" value="${value}"><output>${value}</output></label>`;

export function settingsHtml(s, availableFonts) {
  const fonts = Object.keys(FONTS).filter((k) => availableFonts[k])
    .map((k) => `<option value="${k}"${k === s.font ? " selected" : ""}>${esc(t("reader.set.fonts." + k))}</option>`).join("");
  const seg = (name, items, cur) => `<div class="seg">${items.map(([v, label]) =>
    `<button class="r-btn${String(v) === String(cur) ? " on" : ""}" data-seg="${name}" data-value="${v}">${esc(label)}</button>`).join("")}</div>`;
  const custom = s.theme === "custom"
    ? `<div class="colors">${["bg", "fg", "accent"].map((k) =>
      `<label class="set"><span>${esc(t("reader.set." + k))}</span><input type="color" data-set="${k}" value="${s.custom[k]}"></label>`).join("")}</div>` : "";
  return `
    <label class="set"><span>${esc(t("reader.set.font"))}</span><select data-set="font">${fonts}</select></label>
    <div class="set"><span>${esc(t("reader.set.weight"))}</span>${seg("weight", [[400, t("reader.set.normal")], [700, t("reader.set.bold")]], s.weight)}</div>
    ${range("size", t("reader.set.size"), s.size, RANGES.size, 1)}
    ${range("line", t("reader.set.line"), s.line, RANGES.line, 0.1)}
    ${range("para", t("reader.set.para"), s.para, RANGES.para, 0.1)}
    ${range("width", t("reader.set.width"), s.width, RANGES.width, 1)}
    ${range("margin", t("reader.set.margin"), s.margin, RANGES.margin, 1)}
    <div class="set"><span>${esc(t("reader.set.theme"))}</span>${seg("theme", [["light", t("reader.set.light")], ["dark", t("reader.set.dark")], ["sepia", t("reader.set.sepia")], ["custom", t("reader.set.custom")]], s.theme)}</div>
    ${custom}
    <label class="set check"><input type="checkbox" data-set="showNotes"${s.showNotes ? " checked" : ""}><span>${esc(t("reader.set.showNotes"))}</span></label>
    <div class="set"><span>${esc(t("reader.set.orientation"))}</span>${seg("orientation", [["auto", t("reader.set.auto")], ["portrait", t("reader.set.portrait")], ["landscape", t("reader.set.landscape")]], s.orientation)}</div>
    <p class="r-msg" id="r-note"></p>
    <div class="row2"><button class="r-btn" data-r="fullscreen">${esc(t("reader.fullscreen"))}</button><button class="r-btn" data-r="reset">${esc(t("reader.set.reset"))}</button></div>`;
}
