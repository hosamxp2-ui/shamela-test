// صفحة الإعدادات العامة (دالة نقية): المظهر، القراءة، التخزين، أدوات متقدمة.
import { t } from "../strings.js";
import { esc } from "../reader/content.js";
import { settingsHtml } from "./reader-view.js";
import { fmtBytes } from "./views.js";

const seg = (attr, name, items, cur) =>
  `<div class="seg">${items.map(([v, label]) =>
    `<button class="btn alt${String(v) === String(cur) ? " on" : ""}" ${attr}="${name}" data-value="${v}">${esc(label)}</button>`).join("")}</div>`;

export function settingsPageHtml({ app, reader, fonts, storage, totals, big, sampleStyle }) {
  const th = (k) => t("settings.themes." + k);
  const auto = seg("data-app", "auto", [["off", t("settings.autoModes.off")], ["system", t("settings.autoModes.system")], ["schedule", t("settings.autoModes.schedule")]], app.auto);
  const themeRows = app.auto === "off"
    ? `<div class="set"><span>${esc(t("settings.theme"))}</span>${seg("data-app", "theme", ["light", "dark", "oled", "sepia"].map((k) => [k, th(k)]), app.theme)}</div>`
    : `<div class="set"><span>${esc(t("settings.day"))}</span>${seg("data-app", "dayTheme", ["light", "sepia"].map((k) => [k, th(k)]), app.dayTheme)}</div>
       <div class="set"><span>${esc(t("settings.night"))}</span>${seg("data-app", "nightTheme", ["dark", "oled"].map((k) => [k, th(k)]), app.nightTheme)}</div>`;
  const schedule = app.auto === "schedule"
    ? `<div class="set"><span>${esc(t("settings.from"))}</span><input type="time" data-app-time="nightFrom" value="${esc(app.nightFrom)}"></div>
       <div class="set"><span>${esc(t("settings.to"))}</span><input type="time" data-app-time="nightTo" value="${esc(app.nightTo)}"></div>` : "";

  const usage = storage && storage.quota
    ? `<p class="note">${esc(t("settings.appUsage", { used: fmtBytes(storage.usage), quota: fmtBytes(storage.quota) }))}</p>` : "";
  const bigRows = big.length
    ? `<h3 class="sub">${esc(t("settings.biggest"))}</h3>` + big.map((b) =>
      `<div class="item row"><span class="t">${esc(b.name)}</span><span class="n">${fmtBytes(b.total)}</span><button class="btn alt mini" data-dl="remove" data-id="${b.id}">${esc(t("dl.btn.removeShort"))}</button></div>`).join("") : "";
  const removeAll = totals.done > 0 ? `<button class="btn alt" data-act="remove-all">${esc(t("settings.removeAll"))}</button>` : "";

  return `
  <section class="panel settings-ui"><h2>${esc(t("settings.appearance"))}</h2>
    <div class="set"><span>${esc(t("settings.auto"))}</span>${auto}</div>${themeRows}${schedule}</section>
  <section class="panel settings-ui"><h2>${esc(t("settings.reading"))}</h2>
    <div class="r-page r-sample" id="r-sample" style="${esc(sampleStyle)}"><p>${esc(t("settings.sample"))}</p></div>
    <div id="reading-controls">${settingsHtml(reader, fonts, { compact: true })}</div>
    <button class="btn alt" data-act="reset-reading">${esc(t("settings.resetReading"))}</button></section>
  <section class="panel settings-ui"><h2>${esc(t("settings.storage"))}</h2>
    <p>${esc(t("settings.booksSize", { n: totals.done, size: fmtBytes(totals.doneBytes) }))}</p>${usage}${bigRows}${removeAll}</section>
  <section class="panel"><a class="btn" href="#/stats">${esc(t("stats.link"))}</a><a class="btn" href="#/notes">${esc(t("settings.notesLink"))}</a></section>
  <section class="panel"><h2>${esc(t("settings.advanced"))}</h2><a class="btn alt" href="#/tools">${esc(t("settings.advancedLink"))}</a></section>`;
}
