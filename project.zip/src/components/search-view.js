// صفحة البحث في نصوص الكتب (دوال نقية).
import { t } from "../strings.js";
import { esc } from "../reader/content.js";
import { coverHtml } from "./cover.js";
import { coverOf } from "./views.js";
import { partLabel } from "./reader-view.js";

export function hitLabel(h) {
  return [partLabel(h.part), h.page != null ? t("search.page", { p: h.page }) : ""].filter(Boolean).join(" • ");
}

export function resultsHtml(results, catalog, q, exact) {
  if (!results.length) return "";
  return `<div class="list">${results.slice(0, 200).map((h) => {
    const b = catalog.getBook(h.bookId);
    if (!b) return "";
    const href = `#/read/${h.bookId}?page=${h.pageIndex}&hl=${encodeURIComponent(q)}&x=${exact ? 1 : 0}`;
    return `<a class="item hit" href="${href}">${coverHtml(coverOf(catalog, b), "sm")}<span class="bd"><span class="t">${esc(b.name)}</span><span class="s">${esc(hitLabel(h))}</span><span class="snip">${h.snippet}</span></span></a>`;
  }).join("")}</div>`;
}

export function statusHtml(st, resultsCount, booksCount) {
  if (st.running) {
    const p = st.progress || { done: 0, total: 0 };
    return esc(t("search.progress", { done: p.done, total: p.total })) + (resultsCount ? " • " + esc(t("search.summary", { n: resultsCount, m: booksCount })) : "");
  }
  if (!st.searched && !st.cancelled && !st.skipped.length && !st.results.length) return "";
  const parts = [];
  if (st.cancelled) parts.push(t("search.cancelled"));
  parts.push(resultsCount ? t("search.summary", { n: resultsCount, m: booksCount }) : t("search.noResults"));
  if (st.skipped.length) parts.push(t("search.skipped", { n: st.skipped.length }));
  if (st.truncated) parts.push(t("search.truncated", { n: resultsCount }));
  return parts.map(esc).join(" • ");
}

export function searchPageHtml({ st, catalog, categories, downloadedCount, sorted }) {
  const sel = (cur, keys, label) => keys.map((k) => `<option value="${k}"${String(k) === String(cur) ? " selected" : ""}>${esc(label(k))}</option>`).join("");
  const scopes = ["all", "cat"].concat(st.author != null ? ["author"] : [], st.book != null ? ["book"] : []);
  const scopeSel = sel(st.scope, scopes, (k) => t("search.scope." + k));
  const catSel = st.scope === "cat"
    ? `<select id="s-cat"><option value="">${esc(t("search.allCats"))}</option>${categories.map((c) => `<option value="${c.id}"${c.id === st.cat ? " selected" : ""}>${esc(c.name)}</option>`).join("")}</select>` : "";
  const chip = st.scope === "author" && st.author != null && catalog.getAuthor(st.author)
    ? `<span class="chip">${esc(catalog.getAuthor(st.author).name)}</span>`
    : st.scope === "book" && st.book != null && catalog.getBook(st.book) ? `<span class="chip">${esc(catalog.getBook(st.book).name)}</span>` : "";
  const sortSel = sel(st.sort, ["relevance", "title", "author", "category", "appearance"], (k) => t("search.sort." + k));
  const books = new Set(st.results.map((r) => r.bookId)).size;
  const action = st.running
    ? `<button class="btn alt" data-act="s-cancel">${esc(t("search.cancel"))}</button>`
    : `<button class="btn" data-act="s-run"${downloadedCount ? "" : " disabled"}>${esc(t("search.run"))}</button>`;
  return `<section class="panel"><h2>${esc(t("search.title"))}</h2><p class="note">${esc(t("search.note"))}</p>
    ${downloadedCount ? "" : `<p class="empty">${esc(t("search.noDownloads"))}</p>`}
    <div class="controls">
      <input id="sq" type="search" placeholder="${esc(t("search.placeholder"))}" autocomplete="off" value="${esc(st.q)}">
      <p class="note tiny">${esc(t("search.hint"))}</p>
      <div class="row2"><select id="s-scope">${scopeSel}</select>${catSel}</div>${chip}
      <div class="row2"><select id="s-sort">${sortSel}</select><button class="btn alt" id="s-dir">${esc(t("books." + st.dir))}</button></div>
      <label class="check"><input id="s-exact" type="checkbox"${st.exact ? " checked" : ""}> ${esc(t("search.exact"))}</label>
      ${action}
    </div></section>
    <p class="count" id="s-status">${statusHtml(st, st.results.length, books)}</p>
    <div id="s-results">${resultsHtml(sorted, catalog, st.q, st.exact)}</div>`;
}

// ---- نافذة البحث داخل كتاب في القارئ ----
export function searchSheetInner({ q = "", exact = false } = {}) {
  return `<input id="rs-q" type="search" class="r-input" placeholder="${esc(t("reader.rs.placeholder"))}" autocomplete="off" value="${esc(q)}">
    <label class="set check"><input id="rs-exact" type="checkbox"${exact ? " checked" : ""}><span>${esc(t("search.exact"))}</span></label>
    <div class="row2"><button class="r-btn on" data-r="rs-run">${esc(t("reader.rs.run"))}</button><button class="r-btn" data-r="rs-clear">${esc(t("reader.rs.clear"))}</button></div>
    <p class="r-msg small" id="rs-status"></p><div id="rs-list"></div>`;
}

export function searchHitsHtml(hits) {
  if (!hits.length) return `<p class="r-msg">${esc(t("reader.rs.none"))}</p>`;
  return hits.map((h) => `<button class="hit-row" data-hit="${h.pageIndex}"><span class="s">${esc(hitLabel(h))}</span><span class="snip">${h.snippet}</span></button>`).join("");
}

// صف «حديث رقم N» يظهر أول نتائج البحث الرقمي في كتب لها عمود number
export function numberHitHtml({ n, index, label }) {
  return `<button class="hit-row" data-hit="${Number(index)}"><span class="s">${esc(t("reader.rs.byNumber", { n }))}</span><span class="snip">${esc(label || "")}</span></button>`;
}
