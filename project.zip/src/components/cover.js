// أغلفة مولّدة (لا توجد أغلفة في بيانات المصدر): تدرّج لوني ثابت لكل كتاب حسب قسمه، وزخرفة، وعنوان.
import { esc } from "../reader/content.js";

// ألوان منسجمة: زمردي، فيروزي، أزرق، نيلي، وردي داكن، أحمر ترابي، كهرماني، زيتوني
const HUES = [158, 188, 214, 262, 330, 8, 32, 96];

export function coverColors(bookId, catId) {
  const base = HUES[Math.abs(Number(catId) || 0) % HUES.length];
  const shift = ((Math.abs(Number(bookId) || 0) * 37) % 25) - 12;
  const h1 = (base + shift + 360) % 360;
  const h2 = (h1 + 22) % 360;
  return { c1: `hsl(${h1} 42% 22%)`, c2: `hsl(${h2} 46% 34%)` };
}

export function initialOf(text) {
  const s = String(text == null ? "" : text).replace(/^[^\p{L}\p{N}]+/u, "");
  const noAl = /^ال./u.test(s) ? s.slice(2) : s;
  return (Array.from(noAl)[0] || Array.from(s)[0] || "•");
}

const short = (s, n) => { const a = Array.from(String(s == null ? "" : s).trim()); return a.length > n ? a.slice(0, n - 1).join("") + "…" : a.join(""); };

// size: sm (مصغّر في القوائم) | md | lg
export function coverHtml({ id, name, catId, catName = "", authorName = "" }, size = "md") {
  const { c1, c2 } = coverColors(id, catId);
  const style = `--c1:${c1};--c2:${c2}`;
  if (size === "sm") {
    return `<span class="cover cv-sm" style="${style}" aria-hidden="true"><span class="cv-init">${esc(initialOf(name))}</span></span>`;
  }
  return `<span class="cover cv-${size}" style="${style}" aria-hidden="true">
    <span class="cv-top">${esc(short(catName, 24))}</span>
    <span class="cv-title">${esc(short(name, 90))}</span>
    <span class="cv-author">${esc(short(authorName, 36))}</span></span>`;
}

export function avatarHtml(author, size = "md") {
  const { c1, c2 } = coverColors(author && author.id, 3);
  return `<span class="avatar av-${size}" style="--c1:${c1};--c2:${c2}" aria-hidden="true">${esc(initialOf(author && author.name))}</span>`;
}
