// صفحة إحصائيات القراءة (دوال نقية): بطاقات، مخطط أعمدة SVG، قوائم الكتب، وسجل النشاط.
import { t } from "../strings.js";
import { esc } from "../reader/content.js";
import { coverHtml } from "./cover.js";
import { coverOf } from "./views.js";

export function fmtDuration(sec) {
  const s = Math.max(0, Math.round(sec || 0));
  if (s < 60) return s === 0 ? t("stats.minutes", { m: 0 }) : t("stats.lessMinute");
  const m = Math.round(s / 60);
  if (m < 60) return t("stats.minutes", { m });
  return t("stats.hoursMinutes", { h: Math.floor(m / 60), m: m % 60 });
}

// مخطط أعمدة بسيط: الأقدم على اليمين (اتجاه عربي). metric: pages | minutes
export function barChartSvg(series, metric = "pages", { width = 320, height = 130 } = {}) {
  const val = (x) => (metric === "minutes" ? Math.round(x.seconds / 60) : x.pages);
  const values = series.map(val);
  const max = Math.max(1, ...values);
  const padB = 18, padT = 14, slot = width / series.length, bw = Math.max(4, slot * 0.62);
  const plotH = height - padB - padT;
  const bars = series.map((x, i) => {
    const v = values[i];
    const h = v === 0 ? 2 : Math.max(3, Math.round((v / max) * plotH));
    const cx = width - (i + 0.5) * slot;
    const y = padT + plotH - h;
    const label = x.date.getDate();
    return `<rect class="bar-rect${v === 0 ? " zero" : ""}" x="${(cx - bw / 2).toFixed(1)}" y="${y}" width="${bw.toFixed(1)}" height="${h}" rx="3"/>` +
      (v > 0 ? `<text x="${cx.toFixed(1)}" y="${y - 3}" text-anchor="middle">${v}</text>` : "") +
      `<text x="${cx.toFixed(1)}" y="${height - 4}" text-anchor="middle" class="axis">${label}</text>`;
  }).join("");
  return `<svg class="chart" viewBox="0 0 ${width} ${height}" role="img" aria-label="${esc(t("stats.chart"))}"><line class="grid-line" x1="0" x2="${width}" y1="${padT + plotH}" y2="${padT + plotH}"/>${bars}</svg>`;
}

const card = (label, value) => `<div class="stat"><b>${value}</b><span>${esc(label)}</span></div>`;

export function statsPageHtml({ catalog, summary, today, totals, series, metric, lists, log }) {
  const pagesN = (n) => esc(t("stats.pagesN", { n }));
  const hasAny = totals.pages > 0 || totals.seconds > 0;
  const cards = [
    card(t("stats.today"), `${pagesN(today.pages)} • ${esc(fmtDuration(today.seconds))}`),
    card(t("stats.week"), `${pagesN(summary.weekPages)} • ${esc(fmtDuration(summary.weekSeconds))}`),
    card(t("stats.totalPages"), pagesN(totals.pages)),
    card(t("stats.totalTime"), esc(fmtDuration(totals.seconds))),
    card(t("stats.avgDay"), `${esc(String(summary.avgDayPages))} • ${esc(fmtDuration(summary.avgDaySeconds))}`),
    card(t("stats.avgWeek"), `${esc(String(summary.avgWeekPages))} • ${esc(fmtDuration(summary.avgWeekSeconds))}`),
    card(t("stats.streak"), esc(String(summary.streak))),
    card(t("stats.best"), esc(String(summary.bestStreak))),
    card(t("stats.active"), esc(String(summary.activeDays30)))
  ].join("");
  const seg = ["pages", "minutes"].map((k) =>
    `<button class="btn alt mini${k === metric ? " on" : ""}" data-metric="${k}">${esc(t("stats.metric" + (k === "pages" ? "Pages" : "Minutes")))}</button>`).join("");
  const row = (e, withBar) => {
    const b = catalog.getBook(e.id);
    if (!b) return "";
    const bar = withBar ? `<span class="bar"><i style="width:${Math.min(100, Math.max(0, e.pct))}%"></i></span>` : "";
    return `<a class="item" href="#/book/${e.id}">${coverHtml(coverOf(catalog, b), "sm")}<span class="bd"><span class="t">${esc(b.name)}</span>${bar}</span></a>`;
  };
  const section = (title, items, withBar) => (items.length
    ? `<h3 class="sec">${esc(title)} <span class="n">${items.length}</span></h3><div class="list">${items.slice(0, 20).map((e) => row(e, withBar)).join("")}</div>` : "");
  const logRows = log.length
    ? `<h3 class="sec">${esc(t("stats.log"))}</h3><div class="list">${log.map((d) =>
      `<div class="item"><span class="bd"><span class="t">${esc(d.label)}</span><span class="s">${esc(t("stats.dayLine", { p: d.pages, t: fmtDuration(d.seconds), b: d.books }))}</span></span></div>`).join("")}</div>` : "";
  return `<section class="panel"><h2>${esc(t("stats.title"))}</h2>${hasAny ? "" : `<p class="empty">${esc(t("stats.empty"))}</p>`}
      <div class="cards">${cards}</div><p class="note tiny">${esc(t("stats.note"))}</p></section>
    <section class="panel"><div class="row2 sp"><h3 class="sec nm">${esc(t("stats.chart"))}</h3><div class="segs">${seg}</div></div>${barChartSvg(series, metric)}</section>
    ${section(t("stats.reading"), lists.reading, true)}${section(t("stats.finished"), lists.finished, false)}${section(t("stats.notStarted"), lists.notStarted, false)}${logRows}`;
}
