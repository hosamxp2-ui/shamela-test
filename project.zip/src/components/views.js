// دوال نقية تعيد نصوص HTML (يسهل اختبارها). الربط بالصفحة في main.js.
import { t } from "../strings.js";
import { formatAdded } from "../modules/catalog.js";
import { SITE_BOOK_URL, APP_VERSION } from "../config.js";
import { coverHtml, avatarHtml, coverColors, initialOf } from "./cover.js";

export const esc = (s) =>
  String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const mb = (n) => (n / 1048576).toFixed(1);
export function fmtBytes(n) {
  if (!n || n < 0) return "0 KB";
  if (n < 1048576) return Math.max(1, Math.round(n / 1024)) + " KB";
  if (n < 1073741824) return (n / 1048576).toFixed(1) + " MB";
  return (n / 1073741824).toFixed(2) + " GB";
}
const pct = (rec) => (rec.total ? Math.min(100, Math.floor((rec.done / rec.total) * 100)) : 0);

export function firstRunHtml() {
  return `<section class="panel">
    <h2>${esc(t("firstRun.title"))}</h2>
    <p>${esc(t("firstRun.body"))}</p>
    <button class="btn" data-act="first-sync">${esc(t("firstRun.button"))}</button>
    <pre class="log" id="progress" hidden></pre>
  </section>`;
}

export function categoriesHtml(catalog) {
  const tiles = catalog.categories().map((c) => {
    const { c1, c2 } = coverColors(c.id, c.id);
    return `<a class="tile" href="#/category/${c.id}"><span class="tile-ic" style="--c1:${c1};--c2:${c2}">${esc(initialOf(c.name))}</span><span class="tile-t">${esc(c.name)}</span><span class="tile-n">${c.count}</span></a>`;
  });
  return `<div class="grid">${tiles.join("")}</div>`;
}

export function authorsControlsHtml() {
  return `<div class="controls"><input id="q" type="search" placeholder="${esc(t("authors.search"))}" autocomplete="off"></div><div id="list"></div>`;
}

export function authorsListHtml(authors, limit) {
  if (!authors.length) return `<p class="empty">${esc(t("books.empty"))}</p>`;
  const shown = authors.slice(0, limit).map((a) =>
    `<a class="item" href="#/author/${a.id}">${avatarHtml(a, "md")}<span class="bd"><span class="t">${esc(a.name)}</span>${a.death ? `<span class="s">${esc(t("authors.died", { year: a.death }))}</span>` : ""}</span><span class="n">${a.count}</span></a>`);
  const more = authors.length > limit ? `<button class="btn alt" data-more>${esc(t("books.more"))}</button>` : "";
  return `<p class="count">${authors.length}</p><div class="list">${shown.join("")}</div>${more}`;
}

export function booksControlsHtml({ chips = [], q = "", sort = "name", dir = "asc", categories = [], cat = null, fields = "all", exact = false } = {}) {
  const sel = (cur, keys, label) => keys.map((k) => `<option value="${k}"${String(k) === String(cur) ? " selected" : ""}>${esc(label(k))}</option>`).join("");
  const sorts = sel(sort, ["relevance", "name", "author", "category", "added", "pages"], (k) => t("books.sort." + k));
  const flds = sel(fields, ["all", "title", "author", "category"], (k) => t("books.fields." + k));
  const cats = `<option value="">${esc(t("books.allCats"))}</option>` +
    categories.map((c) => `<option value="${c.id}"${c.id === cat ? " selected" : ""}>${esc(c.name)}</option>`).join("");
  const chipHtml = chips.map((c) => `<a class="chip" href="#/books">${esc(c)} ✕</a>`).join("");
  return `<div class="controls">
    <input id="q" type="search" placeholder="${esc(t("books.search"))}" autocomplete="off" value="${esc(q)}">
    <p class="note tiny">${esc(t("books.hint"))}</p>
    <div class="row2"><select id="fields">${flds}</select><select id="cat">${cats}</select></div>
    <div class="row2"><select id="sort">${sorts}</select><button class="btn alt" id="dir">${esc(t("books." + dir))}</button></div>
    <label class="check"><input id="exact" type="checkbox"${exact ? " checked" : ""}> ${esc(t("books.exact"))}</label>
    <div class="chips">${chipHtml}</div>
  </div><div id="dl-all"></div><div id="list"></div>`;
}

export const coverOf = (catalog, b) => {
  const c = catalog.getCategory(b.cat);
  return { id: b.id, name: b.name, catId: b.cat, catName: c ? c.name : "", authorName: catalog.authorName(b.author) };
};

export function bookItemHtml(catalog, b, extras = {}) {
  const f = catalog.fileInfo(b.id);
  const author = catalog.authorName(b.author);
  const parts = [author, f ? t("books.pagesN", { n: f.pages }) : ""].filter(Boolean).join(" • ");
  const badge = f ? "" : `<span class="badge">${esc(t("books.unavailable"))}</span>`;
  const done = extras.isDownloaded && extras.isDownloaded(b.id) ? `<span class="dl-ok" title="${esc(t("dl.done"))}">✓</span>` : "";
  const r = extras.rating ? extras.rating(b.id) : 0;
  const stars = r ? `<span class="mini-stars">${"★".repeat(r)}</span>` : "";
  return `<a class="item" href="#/book/${b.id}">${coverHtml(coverOf(catalog, b), "sm")}<span class="bd"><span class="t">${esc(b.name)}</span><span class="s">${esc(parts)} ${stars}</span>${badge}</span>${done}</a>`;
}

export function booksListHtml(catalog, books, limit, extras = {}) {
  const head = `<p class="count">${esc(t("books.count", { n: books.length }))}</p>`;
  if (!books.length) return head + `<p class="empty">${esc(t("books.empty"))}</p>`;
  const shown = books.slice(0, limit).map((b) => bookItemHtml(catalog, b, extras)).join("");
  const more = books.length > limit ? `<button class="btn alt" data-more>${esc(t("books.more"))}</button>` : "";
  return head + `<div class="list">${shown}</div>${more}`;
}

export function ratingHtml({ rating = 0, favorite = false } = {}) {
  const stars = [1, 2, 3, 4, 5].map((n) => `<button class="star${n <= rating ? " on" : ""}" data-rate="${n}" aria-label="${esc(t("bk.stars", { n }))}">★</button>`).join("");
  return `<div class="rate"><div class="stars" role="group" aria-label="${esc(t("bk.rate"))}">${stars}</div>
    <button class="fav${favorite ? " on" : ""}" data-fav aria-pressed="${favorite ? "true" : "false"}">${favorite ? "♥" : "♡"} ${esc(favorite ? t("bk.unfav") : t("bk.fav"))}</button></div>
    <p class="note tiny">${esc(t("bk.rate"))}: ${rating ? esc(t("bk.stars", { n: rating })) : "—"} — ${esc(t("bk.rateHint"))}</p>`;
}

export function bookDetailHtml(catalog, id, dlRec = null, extras = {}) {
  const b = catalog.getBook(id);
  if (!b) return `<p class="empty">${esc(t("err.notAvailable"))}</p>`;
  const f = catalog.fileInfo(id);
  const authorIds = catalog.bookAuthorIds(id);
  const authors = authorIds.map((a) => `<a href="#/author/${a}">${esc(catalog.authorName(a))}</a>`).join("، ");
  const cat = catalog.getCategory(b.cat);
  const row = (k, v) => (v ? `<dt>${esc(t(k))}</dt><dd>${v}</dd>` : "");
  const stats = f ? `<div class="stats"><span>${esc(t("books.pagesN", { n: f.pages }))}</span><span>${mb(f.length)} MB</span><span>${esc(t("book.titles"))}: ${f.titles}</span></div>` : "";
  return `<article class="detail">
    <section class="hero-card">
      ${coverHtml(coverOf(catalog, b), "lg")}
      <div class="hero-meta">
        <h2>${esc(b.name)}</h2>
        ${authors ? `<p class="by">${esc(t("bk.by"))} ${authors}</p>` : ""}
        ${cat ? `<a class="chip" href="#/category/${cat.id}">${esc(cat.name)}</a>` : ""}
        ${stats}
      </div>
    </section>
    <section class="panel"><div id="rate-area">${ratingHtml(extras)}</div></section>
    <section class="panel"><div id="dl-area">${bookDownloadHtml(dlRec, !!f)}</div>
      ${f ? `<a class="btn alt" href="#/tools?inspect=${id}">${esc(t("book.inspect"))}</a>` : `<p class="empty">${esc(t("books.unavailable"))}</p>`}
      <a class="btn alt" href="${esc(SITE_BOOK_URL.replace("{id}", String(id)))}" target="_blank" rel="noopener">${esc(t("reader.info.site"))}</a>
    </section>
    <section class="panel"><dl>
      ${row("book.author", authors)}
      ${row("book.category", cat ? `<a href="#/category/${cat.id}">${esc(cat.name)}</a>` : "")}
      ${row("book.pages", f ? String(f.pages) : "")}
      ${row("book.titles", f ? String(f.titles) : "")}
      ${row("book.size", f ? mb(f.length) + " MB" : "")}
      ${row("book.rawSize", f ? mb(f.size) + " MB" : "")}
      ${row("book.added", esc(formatAdded(b.added)))}
    </dl></section>
  </article>`;
}

export function toolsHtml(catalog, inspectId) {
  const m = catalog.meta || {};
  const tt = catalog.totals;
  return `<section class="panel">
    <h2>${esc(t("tools.catalog"))}</h2>
    <dl>
      <dt>${esc(t("tools.appVersion"))}</dt><dd>${esc(APP_VERSION)}</dd>
      <dt>${esc(t("tools.version"))}</dt><dd>${esc(m.dataVersion || "-")}</dd>
      <dt>${esc(t("tools.built"))}</dt><dd>${esc((m.builtAt || "").slice(0, 16).replace("T", " "))}</dd>
      <dt>${esc(t("tools.counts"))}</dt><dd>${tt.books} / ${tt.available} / ${tt.authors} / ${tt.categories}</dd>
    </dl>
    <button class="btn" data-act="refresh">${esc(t("tools.refresh"))}</button>
  </section>
  <section class="panel">
    <h2>${esc(t("tools.inspectTitle"))}</h2>
    <p class="note">${esc(t("tools.inspectHint"))}</p>
    <div class="row2"><input id="bid" type="number" inputmode="numeric" placeholder="${esc(t("tools.bookIdPlaceholder"))}" value="${inspectId || ""}">
    <button class="btn" data-act="inspect">${esc(t("tools.inspectButton"))}</button></div>
    <div class="row2"><button class="btn alt" data-quick="9452">9452</button><button class="btn alt" data-quick="10618">10618</button></div>
    <div class="row2"><button class="btn alt" data-quick="735">735</button><button class="btn alt" data-quick="711">711</button><button class="btn alt" data-quick="2348">2348</button></div>
    <div class="row2"><button class="btn alt" data-quick="42">42</button><button class="btn alt" data-quick="8473">8473</button></div>
    <p class="note tiny">${esc(t("tools.quickBooks"))}</p>
    <h3 class="sub">${esc(t("tools.szTitle"))}</h3><p class="note tiny">${esc(t("tools.szHint"))}</p>
    <button class="btn alt" data-act="size-stats">${esc(t("tools.szButton"))}</button>
    <h3 class="sub">${esc(t("tools.bkTitle"))}</h3><p class="note tiny">${esc(t("tools.bkHint"))}</p>
    <button class="btn" data-act="backup-make">${esc(t("tools.bkMake"))}</button>
    <textarea id="restore-in" placeholder="${esc(t("tools.bkPaste"))}" dir="ltr"></textarea>
    <button class="btn alt" data-act="backup-restore">${esc(t("tools.bkRestore"))}</button>
    <h3 class="sub">${esc(t("tools.dbTitle"))}</h3><p class="note tiny">${esc(t("tools.dbHint"))}</p>
    <button class="btn alt" data-act="inspect-db" data-db="services">${esc(t("tools.dbServices"))}</button>
    <button class="btn alt" data-act="inspect-db" data-db="tashkeel">${esc(t("tools.dbTashkeel"))}</button>
    <h3 class="sub">${esc(t("tools.scanTitle"))}</h3><p class="note tiny">${esc(t("tools.scanHint"))}</p>
    <button class="btn alt" data-act="scan-db" data-db="services" data-mb="70">${esc(t("tools.scanServices"))}</button>
    <button class="btn alt" data-act="scan-db" data-db="tashkeel" data-mb="44">${esc(t("tools.scanTashkeel"))}</button>
    <h3 class="sub">${esc(t("tools.linksTitle"))}</h3><p class="note tiny">${esc(t("tools.linksHint"))}</p>
    <button class="btn" data-act="links-import" data-mb="70">${esc(t("tools.linksButton"))}</button>
    <h3 class="sub">${esc(t("tools.tfTitle"))}</h3><p class="note tiny">${esc(t("tools.tfHint"))}</p>
    <input id="tf-extra" class="inp" type="text" placeholder="${esc(t("tools.tfExtra"))}" dir="rtl">
    <button class="btn" data-act="tafsir-local">${esc(t("tools.tfButton"))}</button>
    <h3 class="sub">${esc(t("tools.hidxTitle"))}</h3><p class="note tiny">${esc(t("tools.hidxHint"))}</p>
    <button class="btn" data-act="hadith-index">${esc(t("tools.hidxButton"))}</button>
    <button class="btn alt" data-act="scan-cancel">${esc(t("tools.scanCancel"))}</button>
    <textarea id="out" readonly></textarea>
    <button class="btn alt" data-act="copy">${esc(t("tools.copy"))}</button>
  </section>`;
}

const btn = (act, id, key, cls = "alt") => `<button class="btn ${cls}" data-dl="${act}" data-id="${id}">${esc(t("dl.btn." + key))}</button>`;

export function bookDownloadHtml(rec, available) {
  if (!available) return "";
  const id = rec ? rec.id : "";
  if (!rec) return `<button class="btn" data-dl="download">${esc(t("dl.btn.download"))}</button>`;
  const status = t("dl.status." + rec.status);
  const bar = rec.status === "done" ? "" : `<div class="bar"><i style="width:${pct(rec)}%"></i></div>`;
  const info = rec.status === "done"
    ? esc(t("dl.done")) + " • " + fmtBytes(rec.total)
    : `${esc(status)} • ${pct(rec)}% (${fmtBytes(rec.done)} / ${fmtBytes(rec.total)})`;
  const err = rec.status === "failed" && rec.error ? `<p class="note bad">${esc(rec.error)}</p>` : "";
  const buttons = {
    queued: btn("pause", id, "pause") + btn("cancel", id, "cancel"),
    downloading: btn("pause", id, "pause") + btn("cancel", id, "cancel"),
    paused: btn("resume", id, "resume", "") + btn("cancel", id, "cancel"),
    failed: btn("retry", id, "retry", "") + btn("cancel", id, "cancel"),
    done: btn("remove", id, "remove")
  }[rec.status] || "";
  const read = rec.status === "done" ? `<a class="btn" href="#/read/${id}">${esc(t("reader.read"))}</a><a class="btn alt" href="#/search?scope=book&book=${id}">${esc(t("search.inBook"))}</a>` : "";
  return `<p class="s">${info}</p>${bar}${err}${read}<div class="row2">${buttons}</div>`;
}

export function resultsDownloadButtonHtml(n) {
  return `<button class="btn" data-act="dl-results">${esc(t("dl.results", { n }))}</button>`;
}

export function downloadRowHtml(catalog, rec) {
  const b = catalog.getBook(rec.id);
  const name = b ? b.name : String(rec.id);
  const status = t("dl.status." + rec.status);
  const info = rec.status === "done"
    ? `${esc(status)} • ${fmtBytes(rec.total)}`
    : `${esc(status)} • ${pct(rec)}% (${fmtBytes(rec.done)} / ${fmtBytes(rec.total)})`;
  const bar = rec.status === "done" ? "" : `<div class="bar"><i style="width:${pct(rec)}%"></i></div>`;
  const err = rec.status === "failed" && rec.error ? `<div class="s bad">${esc(rec.error)}</div>` : "";
  const id = rec.id;
  const buttons = {
    queued: btn("pause", id, "pause") + btn("cancel", id, "cancel"),
    downloading: btn("pause", id, "pause") + btn("cancel", id, "cancel"),
    paused: btn("resume", id, "resume", "") + btn("cancel", id, "cancel"),
    failed: btn("retry", id, "retry", "") + btn("cancel", id, "cancel"),
    done: btn("remove", id, "remove")
  }[rec.status] || "";
  const read = rec.status === "done" ? `<a class="btn" href="#/read/${id}">${esc(t("dl.btn.read"))}</a>` : "";
  return `<div class="item"><a class="t" href="#/book/${id}">${esc(name)}</a><div class="s">${info}</div>${bar}${err}${read}<div class="row2">${buttons}</div></div>`;
}

export function downloadsHtml(catalog, list, totals, storage) {
  const sum = esc(t("dl.summary", { n: totals.done, size: fmtBytes(totals.doneBytes) }));
  const stor = storage && storage.quota
    ? `<p class="note">${esc(t("dl.storage", { used: fmtBytes(storage.usage), quota: fmtBytes(storage.quota) }))}</p>` : "";
  const hasActive = list.some((r) => ["queued", "downloading"].includes(r.status));
  const hasPaused = list.some((r) => ["paused", "failed"].includes(r.status));
  const bulk = [
    hasActive ? `<button class="btn alt" data-act="pause-all">${esc(t("dl.btn.pauseAll"))}</button>` : "",
    hasPaused ? `<button class="btn alt" data-act="resume-all">${esc(t("dl.btn.resumeAll"))}</button>` : "",
    totals.done > 0 ? `<button class="btn alt" data-act="remove-all">${esc(t("dl.btn.removeAll"))}</button>` : ""
  ].join("");
  const rows = list.length ? list.map((r) => downloadRowHtml(catalog, r)).join("") : `<p class="empty">${esc(t("dl.empty"))}</p>`;
  return `<section class="panel"><h2>${esc(t("dl.title"))}</h2><p>${sum}</p>${stor}${bulk}</section><div class="list">${rows}</div>`;
}

export function modalHtml({ title, body, ok, cancel }) {
  return `<div class="sheet" role="dialog"><h2>${esc(title)}</h2><p>${esc(body)}</p>
    <div class="row2"><button class="btn" data-modal="ok">${esc(ok)}</button>${cancel ? `<button class="btn alt" data-modal="no">${esc(cancel)}</button>` : ""}</div></div>`;
}

export function notesPageHtml(groups, isDownloaded) {
  if (!groups.length) return `<section class="panel"><h2>${esc(t("reader.np.title"))}</h2><p class="empty">${esc(t("reader.np.empty"))}</p></section>`;
  const items = (g) => g.items.map((n) => `
    <div class="item"><div class="s">${n.kind === "bookmark" ? "★" : "✎"} ${esc(n.label || t("reader.notes.page", { n: n.pageIndex + 1 }))}</div>
      ${n.quote ? `<blockquote class="q">${esc(n.quote)}</blockquote>` : ""}${n.text ? `<p>${esc(n.text)}</p>` : ""}
      <div class="row2">${isDownloaded(g.bookId) ? `<a class="btn alt" href="#/read/${g.bookId}?page=${n.pageIndex}">${esc(t("reader.np.open"))}</a>` : `<span class="s">${esc(t("reader.np.notDownloaded"))}</span>`}
      <button class="btn alt" data-nact="del" data-book="${g.bookId}" data-id="${esc(n.id)}">${esc(t("reader.np.del"))}</button></div></div>`).join("");
  return `<section class="panel"><h2>${esc(t("reader.np.title"))}</h2></section>` +
    groups.map((g) => `<h3 class="sub"><a href="#/book/${g.bookId}">${esc(g.name)}</a></h3><div class="list">${items(g)}</div>`).join("");
}

// ---------- الشاشة الرئيسية والرؤوس (التصميم الحديث) ----------
export function shelfHtml(title, items) {
  if (!items.length) return "";
  return `<section class="shelf"><h3 class="sec">${esc(title)}</h3><div class="shelf-row">${items.join("")}</div></section>`;
}

export function shelfItemHtml(catalog, b, progressPct = null) {
  const bar = progressPct != null ? `<span class="bar"><i style="width:${progressPct}%"></i></span>` : "";
  return `<a class="shelf-item" href="#/book/${b.id}">${coverHtml(coverOf(catalog, b), "md")}<span class="shelf-t">${esc(b.name)}</span>${bar}</a>`;
}

export function homeHtml({ catalog, hero, recent = [], favorites = [], statsLine = "" }) {
  const heroHtml = hero
    ? `<section class="continue"><div class="continue-cv">${coverHtml(coverOf(catalog, hero.book), "md")}</div>
        <div class="continue-bd"><span class="kicker">${esc(t("home.continue"))}</span><h2>${esc(hero.book.name)}</h2>
          <p class="s">${esc(t("home.progress", { i: hero.index + 1, n: hero.total }))}</p>
          <span class="bar"><i style="width:${Math.min(100, Math.round(((hero.index + 1) / hero.total) * 100))}%"></i></span>
          <a class="btn" href="#/read/${hero.book.id}?page=${hero.index}">${esc(t("reader.read"))}</a></div></section>`
    : `<section class="welcome"><h2>${esc(t("home.welcome"))}</h2><p>${esc(t("home.welcomeSub"))}</p></section>`;
  const search = `<a class="searchbar" href="#/books?focus=1"><svg viewBox="0 0 24 24" class="ic"><circle cx="11" cy="11" r="6.5"/><path d="M16 16l4.5 4.5"/></svg><span>${esc(t("home.search"))}</span></a>`;
  const textSearch = `<a class="searchbar" href="#/search"><svg viewBox="0 0 24 24" class="ic"><path d="M5 4h10l4 4v12H5z"/><path d="M9 12h6M9 16h6"/></svg><span>${esc(t("search.home"))}</span></a>`;
  const statCard = statsLine ? `<a class="statcard" href="#/stats"><span class="kicker">${esc(t("stats.link"))}</span><span class="t">${esc(statsLine)}</span></a>` : "";
  const recentItems = recent.map((r) => shelfItemHtml(catalog, r.book, Math.min(100, Math.round(((r.index + 1) / r.total) * 100))));
  const favItems = favorites.map((b) => shelfItemHtml(catalog, b));
  return heroHtml + search + textSearch + statCard + shelfHtml(t("home.recent"), recentItems) + shelfHtml(t("home.favorites"), favItems) +
    `<h3 class="sec">${esc(t("home.categories"))}</h3>` + categoriesHtml(catalog);
}

export function authorHeaderHtml(author, count) {
  return `<section class="page-head">${avatarHtml(author, "lg")}<div><h2>${esc(author.name)}</h2>
    <p class="s">${author.death ? esc(t("authors.died", { year: author.death })) + " • " : ""}${esc(t("bk.authorBooks", { n: count }))}</p>
    <a class="chip" href="#/search?scope=author&author=${author.id}">${esc(t("search.inAuthor"))}</a></div></section>`;
}

export function categoryHeaderHtml(cat, count) {
  const { c1, c2 } = coverColors(cat.id, cat.id);
  return `<section class="page-head"><span class="tile-ic lg" style="--c1:${c1};--c2:${c2}">${esc(initialOf(cat.name))}</span><div><h2>${esc(cat.name)}</h2>
    <p class="s">${esc(t("bk.catBooks", { n: count }))}</p>
    <a class="chip" href="#/search?scope=cat&cat=${cat.id}">${esc(t("search.inCat"))}</a></div></section>`;
}
