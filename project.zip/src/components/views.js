// دوال نقية تعيد نصوص HTML (يسهل اختبارها). الربط بالصفحة في main.js.
import { t } from "../strings.js";
import { formatAdded } from "../modules/catalog.js";

export const esc = (s) =>
  String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const mb = (n) => (n / 1048576).toFixed(1);
export function fmtBytes(n) {
  if (!n || n < 0) return "0 KB";
  if (n < 1048576) return Math.max(1, Math.round(n / 1024)) + " KB";
  if (n < 1073741824) return (n / 1048576).toFixed(1) + " MB";
  return (n / 1073741824).toFixed(2) + " GB";
}
const pct = (rec) => (rec.total ? Math.min(100, Math.floor((rec.done / rec.total) * 100)) : 0);

export function firstRunHtml() {
  return `<section class="panel">
    <h2>${esc(t("firstRun.title"))}</h2>
    <p>${esc(t("firstRun.body"))}</p>
    <button class="btn" data-act="first-sync">${esc(t("firstRun.button"))}</button>
    <pre class="log" id="progress" hidden></pre>
  </section>`;
}

export function categoriesHtml(catalog) {
  const items = catalog.categories().map((c) =>
    `<a class="item row" href="#/books?cat=${c.id}"><span class="t">${esc(c.name)}</span><span class="n">${c.count}</span></a>`);
  return `<div class="list">${items.join("")}</div>`;
}

export function authorsControlsHtml() {
  return `<div class="controls"><input id="q" type="search" placeholder="${esc(t("authors.search"))}" autocomplete="off"></div><div id="list"></div>`;
}

export function authorsListHtml(authors, limit) {
  if (!authors.length) return `<p class="empty">${esc(t("books.empty"))}</p>`;
  const shown = authors.slice(0, limit).map((a) =>
    `<a class="item row" href="#/books?author=${a.id}"><span class="t">${esc(a.name)}${a.death ? ` <span class="s">${esc(t("authors.died", { year: a.death }))}</span>` : ""}</span><span class="n">${a.count}</span></a>`);
  const more = authors.length > limit ? `<button class="btn alt" data-more>${esc(t("books.more"))}</button>` : "";
  return `<p class="count">${authors.length}</p><div class="list">${shown.join("")}</div>${more}`;
}

export function booksControlsHtml({ chips = [], sort = "name", dir = "asc", categories = [], cat = null, fields = "all", exact = false } = {}) {
  const sel = (cur, keys, label) => keys.map((k) => `<option value="${k}"${String(k) === String(cur) ? " selected" : ""}>${esc(label(k))}</option>`).join("");
  const sorts = sel(sort, ["relevance", "name", "author", "category", "added", "pages"], (k) => t("books.sort." + k));
  const flds = sel(fields, ["all", "title", "author", "category"], (k) => t("books.fields." + k));
  const cats = `<option value="">${esc(t("books.allCats"))}</option>` +
    categories.map((c) => `<option value="${c.id}"${c.id === cat ? " selected" : ""}>${esc(c.name)}</option>`).join("");
  const chipHtml = chips.map((c) => `<a class="chip" href="#/books">${esc(c)} ✕</a>`).join("");
  return `<div class="controls">
    <input id="q" type="search" placeholder="${esc(t("books.search"))}" autocomplete="off">
    <p class="note tiny">${esc(t("books.hint"))}</p>
    <div class="row2"><select id="fields">${flds}</select><select id="cat">${cats}</select></div>
    <div class="row2"><select id="sort">${sorts}</select><button class="btn alt" id="dir">${esc(t("books." + dir))}</button></div>
    <label class="check"><input id="exact" type="checkbox"${exact ? " checked" : ""}> ${esc(t("books.exact"))}</label>
    <div class="chips">${chipHtml}</div>
  </div><div id="dl-all"></div><div id="list"></div>`;
}

export function bookItemHtml(catalog, b) {
  const f = catalog.fileInfo(b.id);
  const author = catalog.authorName(b.author);
  const parts = [author, f ? t("books.pagesN", { n: f.pages }) : ""].filter(Boolean).join(" • ");
  const badge = f ? "" : ` <span class="badge">${esc(t("books.unavailable"))}</span>`;
  return `<a class="item" href="#/book/${b.id}"><div class="t">${esc(b.name)}</div><div class="s">${esc(parts)}${badge}</div></a>`;
}

export function booksListHtml(catalog, books, limit) {
  const head = `<p class="count">${esc(t("books.count", { n: books.length }))}</p>`;
  if (!books.length) return head + `<p class="empty">${esc(t("books.empty"))}</p>`;
  const shown = books.slice(0, limit).map((b) => bookItemHtml(catalog, b)).join("");
  const more = books.length > limit ? `<button class="btn alt" data-more>${esc(t("books.more"))}</button>` : "";
  return head + `<div class="list">${shown}</div>${more}`;
}

export function bookDetailHtml(catalog, id, dlRec = null) {
  const b = catalog.getBook(id);
  if (!b) return `<p class="empty">${esc(t("err.notAvailable"))}</p>`;
  const f = catalog.fileInfo(id);
  const authors = catalog.bookAuthorIds(id).map((a) => `<a href="#/books?author=${a}">${esc(catalog.authorName(a))}</a>`).join("، ");
  const cat = catalog.getCategory(b.cat);
  const row = (k, v) => (v ? `<dt>${esc(t(k))}</dt><dd>${v}</dd>` : "");
  return `<article class="panel">
    <h2>${esc(b.name)}</h2>
    <dl>
      ${row("book.author", authors)}
      ${row("book.category", cat ? `<a href="#/books?cat=${cat.id}">${esc(cat.name)}</a>` : "")}
      ${row("book.pages", f ? String(f.pages) : "")}
      ${row("book.titles", f ? String(f.titles) : "")}
      ${row("book.size", f ? mb(f.length) + " MB" : "")}
      ${row("book.rawSize", f ? mb(f.size) + " MB" : "")}
      ${row("book.added", esc(formatAdded(b.added)))}
    </dl>
    ${f ? `<a class="btn alt" href="#/tools?inspect=${id}">${esc(t("book.inspect"))}</a>` : `<p class="empty">${esc(t("books.unavailable"))}</p>`}
    <div id="dl-area">${bookDownloadHtml(dlRec, !!f)}</div>
  </article>`;
}

export function toolsHtml(catalog, inspectId) {
  const m = catalog.meta || {};
  const tt = catalog.totals;
  return `<section class="panel">
    <h2>${esc(t("tools.catalog"))}</h2>
    <dl>
      <dt>${esc(t("tools.version"))}</dt><dd>${esc(m.dataVersion || "-")}</dd>
      <dt>${esc(t("tools.built"))}</dt><dd>${esc((m.builtAt || "").slice(0, 16).replace("T", " "))}</dd>
      <dt>${esc(t("tools.counts"))}</dt><dd>${tt.books} / ${tt.available} / ${tt.authors} / ${tt.categories}</dd>
    </dl>
    <button class="btn" data-act="refresh">${esc(t("tools.refresh"))}</button>
  </section>
  <section class="panel">
    <h2>${esc(t("tools.inspectTitle"))}</h2>
    <p class="note">${esc(t("tools.inspectHint"))}</p>
    <div class="row2"><input id="bid" type="number" inputmode="numeric" placeholder="${esc(t("tools.bookIdPlaceholder"))}" value="${inspectId || ""}">
    <button class="btn" data-act="inspect">${esc(t("tools.inspectButton"))}</button></div>
    <div class="row2"><button class="btn alt" data-quick="9452">9452</button><button class="btn alt" data-quick="10618">10618</button></div>
    <textarea id="out" readonly></textarea>
    <button class="btn alt" data-act="copy">${esc(t("tools.copy"))}</button>
  </section>`;
}

const btn = (act, id, key, cls = "alt") => `<button class="btn ${cls}" data-dl="${act}" data-id="${id}">${esc(t("dl.btn." + key))}</button>`;

export function bookDownloadHtml(rec, available) {
  if (!available) return "";
  const id = rec ? rec.id : "";
  if (!rec) return `<button class="btn" data-dl="download">${esc(t("dl.btn.download"))}</button>`;
  const status = t("dl.status." + rec.status);
  const bar = rec.status === "done" ? "" : `<div class="bar"><i style="width:${pct(rec)}%"></i></div>`;
  const info = rec.status === "done"
    ? esc(t("dl.done")) + " • " + fmtBytes(rec.total)
    : `${esc(status)} • ${pct(rec)}% (${fmtBytes(rec.done)} / ${fmtBytes(rec.total)})`;
  const err = rec.status === "failed" && rec.error ? `<p class="note bad">${esc(rec.error)}</p>` : "";
  const buttons = {
    queued: btn("pause", id, "pause") + btn("cancel", id, "cancel"),
    downloading: btn("pause", id, "pause") + btn("cancel", id, "cancel"),
    paused: btn("resume", id, "resume", "") + btn("cancel", id, "cancel"),
    failed: btn("retry", id, "retry", "") + btn("cancel", id, "cancel"),
    done: btn("remove", id, "remove")
  }[rec.status] || "";
  const read = rec.status === "done" ? `<a class="btn" href="#/read/${id}">${esc(t("reader.read"))}</a>` : "";
  return `<p class="s">${info}</p>${bar}${err}${read}<div class="row2">${buttons}</div>`;
}

export function resultsDownloadButtonHtml(n) {
  return `<button class="btn" data-act="dl-results">${esc(t("dl.results", { n }))}</button>`;
}

export function downloadRowHtml(catalog, rec) {
  const b = catalog.getBook(rec.id);
  const name = b ? b.name : String(rec.id);
  const status = t("dl.status." + rec.status);
  const info = rec.status === "done"
    ? `${esc(status)} • ${fmtBytes(rec.total)}`
    : `${esc(status)} • ${pct(rec)}% (${fmtBytes(rec.done)} / ${fmtBytes(rec.total)})`;
  const bar = rec.status === "done" ? "" : `<div class="bar"><i style="width:${pct(rec)}%"></i></div>`;
  const err = rec.status === "failed" && rec.error ? `<div class="s bad">${esc(rec.error)}</div>` : "";
  const id = rec.id;
  const buttons = {
    queued: btn("pause", id, "pause") + btn("cancel", id, "cancel"),
    downloading: btn("pause", id, "pause") + btn("cancel", id, "cancel"),
    paused: btn("resume", id, "resume", "") + btn("cancel", id, "cancel"),
    failed: btn("retry", id, "retry", "") + btn("cancel", id, "cancel"),
    done: btn("remove", id, "remove")
  }[rec.status] || "";
  const read = rec.status === "done" ? `<a class="btn" href="#/read/${id}">${esc(t("dl.btn.read"))}</a>` : "";
  return `<div class="item"><a class="t" href="#/book/${id}">${esc(name)}</a><div class="s">${info}</div>${bar}${err}${read}<div class="row2">${buttons}</div></div>`;
}

export function downloadsHtml(catalog, list, totals, storage) {
  const sum = esc(t("dl.summary", { n: totals.done, size: fmtBytes(totals.doneBytes) }));
  const stor = storage && storage.quota
    ? `<p class="note">${esc(t("dl.storage", { used: fmtBytes(storage.usage), quota: fmtBytes(storage.quota) }))}</p>` : "";
  const hasActive = list.some((r) => ["queued", "downloading"].includes(r.status));
  const hasPaused = list.some((r) => ["paused", "failed"].includes(r.status));
  const bulk = [
    hasActive ? `<button class="btn alt" data-act="pause-all">${esc(t("dl.btn.pauseAll"))}</button>` : "",
    hasPaused ? `<button class="btn alt" data-act="resume-all">${esc(t("dl.btn.resumeAll"))}</button>` : "",
    totals.done > 0 ? `<button class="btn alt" data-act="remove-all">${esc(t("dl.btn.removeAll"))}</button>` : ""
  ].join("");
  const rows = list.length ? list.map((r) => downloadRowHtml(catalog, r)).join("") : `<p class="empty">${esc(t("dl.empty"))}</p>`;
  return `<section class="panel"><h2>${esc(t("dl.title"))}</h2><p>${sum}</p>${stor}${bulk}</section><div class="list">${rows}</div>`;
}

export function modalHtml({ title, body, ok, cancel }) {
  return `<div class="sheet" role="dialog"><h2>${esc(title)}</h2><p>${esc(body)}</p>
    <div class="row2"><button class="btn" data-modal="ok">${esc(ok)}</button>${cancel ? `<button class="btn alt" data-modal="no">${esc(cancel)}</button>` : ""}</div></div>`;
}
