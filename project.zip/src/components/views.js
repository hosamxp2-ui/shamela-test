// دوال نقية تعيد نصوص HTML (يسهل اختبارها). الربط بالصفحة في main.js.
import { t } from "../strings.js";
import { formatAdded } from "../modules/catalog.js";

export const esc = (s) =>
  String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const mb = (n) => (n / 1048576).toFixed(1);

export function firstRunHtml() {
  return `<section class="panel">
    <h2>${esc(t("firstRun.title"))}</h2>
    <p>${esc(t("firstRun.body"))}</p>
    <button class="btn" data-act="first-sync">${esc(t("firstRun.button"))}</button>
    <pre class="log" id="progress" hidden></pre>
  </section>`;
}

export function categoriesHtml(catalog) {
  const items = catalog.categories().map((c) =>
    `<a class="item row" href="#/books?cat=${c.id}"><span class="t">${esc(c.name)}</span><span class="n">${c.count}</span></a>`);
  return `<div class="list">${items.join("")}</div>`;
}

export function authorsControlsHtml() {
  return `<div class="controls"><input id="q" type="search" placeholder="${esc(t("authors.search"))}" autocomplete="off"></div><div id="list"></div>`;
}

export function authorsListHtml(authors, limit) {
  if (!authors.length) return `<p class="empty">${esc(t("books.empty"))}</p>`;
  const shown = authors.slice(0, limit).map((a) =>
    `<a class="item row" href="#/books?author=${a.id}"><span class="t">${esc(a.name)}${a.death ? ` <span class="s">${esc(t("authors.died", { year: a.death }))}</span>` : ""}</span><span class="n">${a.count}</span></a>`);
  const more = authors.length > limit ? `<button class="btn alt" data-more>${esc(t("books.more"))}</button>` : "";
  return `<p class="count">${authors.length}</p><div class="list">${shown.join("")}</div>${more}`;
}

export function booksControlsHtml({ chips = [], sort = "name", dir = "asc" } = {}) {
  const opts = ["name", "author", "added", "pages"].map((k) =>
    `<option value="${k}"${k === sort ? " selected" : ""}>${esc(t("books.sort." + k))}</option>`).join("");
  const chipHtml = chips.map((c) => `<a class="chip" href="#/books">${esc(c)} ✕</a>`).join("");
  return `<div class="controls">
    <input id="q" type="search" placeholder="${esc(t("books.search"))}" autocomplete="off">
    <div class="row2"><select id="sort">${opts}</select><button class="btn alt" id="dir">${esc(t("books." + dir))}</button></div>
    <div class="chips">${chipHtml}</div>
  </div><div id="list"></div>`;
}

export function bookItemHtml(catalog, b) {
  const f = catalog.fileInfo(b.id);
  const author = catalog.authorName(b.author);
  const parts = [author, f ? t("books.pagesN", { n: f.pages }) : ""].filter(Boolean).join(" • ");
  const badge = f ? "" : ` <span class="badge">${esc(t("books.unavailable"))}</span>`;
  return `<a class="item" href="#/book/${b.id}"><div class="t">${esc(b.name)}</div><div class="s">${esc(parts)}${badge}</div></a>`;
}

export function booksListHtml(catalog, books, limit) {
  const head = `<p class="count">${esc(t("books.count", { n: books.length }))}</p>`;
  if (!books.length) return head + `<p class="empty">${esc(t("books.empty"))}</p>`;
  const shown = books.slice(0, limit).map((b) => bookItemHtml(catalog, b)).join("");
  const more = books.length > limit ? `<button class="btn alt" data-more>${esc(t("books.more"))}</button>` : "";
  return head + `<div class="list">${shown}</div>${more}`;
}

export function bookDetailHtml(catalog, id) {
  const b = catalog.getBook(id);
  if (!b) return `<p class="empty">${esc(t("err.notAvailable"))}</p>`;
  const f = catalog.fileInfo(id);
  const authors = catalog.bookAuthorIds(id).map((a) => `<a href="#/books?author=${a}">${esc(catalog.authorName(a))}</a>`).join("، ");
  const cat = catalog.getCategory(b.cat);
  const row = (k, v) => (v ? `<dt>${esc(t(k))}</dt><dd>${v}</dd>` : "");
  return `<article class="panel">
    <h2>${esc(b.name)}</h2>
    <dl>
      ${row("book.author", authors)}
      ${row("book.category", cat ? `<a href="#/books?cat=${cat.id}">${esc(cat.name)}</a>` : "")}
      ${row("book.pages", f ? String(f.pages) : "")}
      ${row("book.titles", f ? String(f.titles) : "")}
      ${row("book.size", f ? mb(f.length) + " MB" : "")}
      ${row("book.rawSize", f ? mb(f.size) + " MB" : "")}
      ${row("book.added", esc(formatAdded(b.added)))}
    </dl>
    ${f ? `<a class="btn alt" href="#/tools?inspect=${id}">${esc(t("book.inspect"))}</a>` : `<p class="empty">${esc(t("books.unavailable"))}</p>`}
    <p class="note">${esc(t("book.downloadSoon"))}</p>
  </article>`;
}

export function toolsHtml(catalog, inspectId) {
  const m = catalog.meta || {};
  const tt = catalog.totals;
  return `<section class="panel">
    <h2>${esc(t("tools.catalog"))}</h2>
    <dl>
      <dt>${esc(t("tools.version"))}</dt><dd>${esc(m.dataVersion || "-")}</dd>
      <dt>${esc(t("tools.built"))}</dt><dd>${esc((m.builtAt || "").slice(0, 16).replace("T", " "))}</dd>
      <dt>${esc(t("tools.counts"))}</dt><dd>${tt.books} / ${tt.available} / ${tt.authors} / ${tt.categories}</dd>
    </dl>
    <button class="btn" data-act="refresh">${esc(t("tools.refresh"))}</button>
  </section>
  <section class="panel">
    <h2>${esc(t("tools.inspectTitle"))}</h2>
    <p class="note">${esc(t("tools.inspectHint"))}</p>
    <div class="row2"><input id="bid" type="number" inputmode="numeric" placeholder="${esc(t("tools.bookIdPlaceholder"))}" value="${inspectId || ""}">
    <button class="btn" data-act="inspect">${esc(t("tools.inspectButton"))}</button></div>
    <div class="row2"><button class="btn alt" data-quick="9452">9452</button><button class="btn alt" data-quick="10618">10618</button></div>
    <textarea id="out" readonly></textarea>
    <button class="btn alt" data-act="copy">${esc(t("tools.copy"))}</button>
  </section>`;
}
