// استيراد جداول الربط الصغيرة من services.db أثناء مسحها (دون تحميل القاعدة كلها في الذاكرة):
//   tafsir_link / hadith_link / tafsir_book / hadith_book / aya / sura / rawi (الاسم والوفاة)
// ويعدّ صفوف esnad لكل كتاب دون حفظها. يحفظ النتيجة في IndexedDB ويعيد تقريرًا نصيًا للصقه.
// ما لا يغطيه: صفوف rawi_page وroots لا تُقرأ. نص jarh/details الطويل يُقتطع إن تجاوز الصفحة.
import { createScanner, leafCells } from "../services/sqlite-scan.js";
import { scanDb } from "./services-scan.js";
import { kvSet } from "../database/idb.js";

export const LINKS_KEY = "services-links";
const WATCH = [735, 711, 42];
const isNum = (x) => typeof x === "number";
const cut = (s, n = 80) => { const v = String(s == null ? "" : s).replace(/\s+/g, " "); return v.length > n ? v.slice(0, n) + "…" : v; };

export function createCollector() {
  const pending = new Map(); // صفحات tafsir_link/hadith_link/tafsir_book/hadith_book (لا تُعرف إلا بعد قراءة الأشجار)
  const aya = []; const sura = [];
  const rawi = { ids: [], names: [], death: [], jarhSamples: [] };
  const esnad = { rows: 0, byBook: new Map(), samples: new Map() };

  function onLeaf(n, page, usable) {
    const first = leafCells(page, usable, 0, 1)[0];
    if (!first) return;
    const r = first.vals;
    if (r.length === 3 && r.every(isNum)) { pending.set(n, new Uint8Array(page)); return; }
    if (r.length === 1 && r[0] === null) { pending.set(n, new Uint8Array(page)); return; }
    if (r[0] === null && isNum(r[1]) && isNum(r[2]) && typeof r[3] === "string") { // aya(id, sura, aya, text, uthmani)
      for (const c of leafCells(page, usable)) { const v = c.vals; if (isNum(v[1]) && isNum(v[2]) && typeof v[3] === "string") aya[c.rowid] = v[3]; }
      return;
    }
    if (r[0] === null && typeof r[1] === "string" && r.length === 4 && isNum(r[2]) && isNum(r[3])) { // sura(id, name, ayat, first_aya)
      for (const c of leafCells(page, usable)) sura.push({ id: c.rowid, name: c.vals[1], ayat: c.vals[2], first: c.vals[3] });
      return;
    }
    if (r[0] === null && typeof r[1] === "string") { // rawi(id, name, full, death, jarh, details)
      for (const c of leafCells(page, usable)) {
        const v = c.vals;
        rawi.ids.push(c.rowid); rawi.names.push(typeof v[1] === "string" ? v[1] : ""); rawi.death.push(isNum(v[3]) ? v[3] : -1);
        if (rawi.jarhSamples.length < 2 && typeof v[4] === "string" && v[4] !== "[]" && v[4] !== "…") rawi.jarhSamples.push({ id: c.rowid, name: v[1], jarh: cut(v[4], 160) });
      }
      return;
    }
    if (r.length === 4 && isNum(r[0]) && isNum(r[1]) && isNum(r[2]) && (typeof r[3] === "string" || r[3] === null)) { // esnad: نعدّ فقط
      for (const c of leafCells(page, usable)) {
        const v = c.vals; esnad.rows++;
        esnad.byBook.set(v[0], (esnad.byBook.get(v[0]) || 0) + 1);
        if (WATCH.includes(v[0]) && (esnad.samples.get(v[0]) || []).length < 2) esnad.samples.set(v[0], [...(esnad.samples.get(v[0]) || []), { page: v[1], hadith: v[2], chain: cut(v[3], 60) }]);
      }
    }
  }

  // بعد انتهاء المسح: نحلّ الصفحات المعلّقة بحسب الجدول الذي تنتمي إليه
  function resolve(scanner, rep) {
    const tables = new Map(rep.objects.filter((o) => o.type === "table").map((o) => [o.name, o]));
    const used = new Set();
    const read = (name, fn) => {
      const o = tables.get(name); let rows = 0;
      if (!o || !o.root) return { rows, expected: 0 };
      for (const n of scanner.leaves(o.root)) {
        const pg = pending.get(n); if (!pg) continue;
        used.add(n);
        for (const c of leafCells(pg, scanner.usable)) { fn(c); rows++; }
      }
      return { rows, expected: o.rows };
    };
    const tl = [], hl = [], tb = [], hb = [];
    const checks = {
      tafsir_link: read("tafsir_link", (c) => { if (c.vals.length === 3) tl.push(c.vals[0], c.vals[1], c.vals[2]); }),
      hadith_link: read("hadith_link", (c) => { if (c.vals.length === 3) hl.push(c.vals[0], c.vals[1], c.vals[2]); }),
      tafsir_book: read("tafsir_book", (c) => tb.push(c.rowid)),
      hadith_book: read("hadith_book", (c) => hb.push(c.rowid))
    };
    const exp = (name, rows) => ({ rows, expected: (tables.get(name) || {}).rows || 0 });
    checks.aya = exp("aya", aya.filter((x) => x != null).length);
    checks.sura = exp("sura", sura.length);
    checks.rawi = exp("rawi", rawi.ids.length);
    checks.esnad = exp("esnad", esnad.rows);
    return {
      checks, orphans: pending.size - used.size,
      tafsirBooks: tb.sort((a, b) => a - b), hadithBooks: hb.sort((a, b) => a - b),
      tafsirLinks: Int32Array.from(tl), hadithLinks: Int32Array.from(hl),
      sura: sura.sort((a, b) => a.id - b.id), aya, rawi, esnad
    };
  }
  return { onLeaf, resolve };
}

const range = (arr) => { let lo = Infinity, hi = -Infinity; for (const v of arr) { if (v < lo) lo = v; if (v > hi) hi = v; } return arr.length ? lo + "–" + hi : "-"; };

// يجمع من مصفوفة ثلاثيات [أ، كتاب، صفحة] ما يخص كتابًا واحدًا
function forBook(triples, book) {
  const keys = [], pages = [];
  for (let i = 0; i < triples.length; i += 3) if (triples[i + 1] === book) { keys.push(triples[i]); pages.push(triples[i + 2]); }
  return { keys, pages };
}
const where = (triples, first) => { const o = []; for (let i = 0; i < triples.length; i += 3) if (triples[i] === first) o.push(triples[i + 1] + ":" + triples[i + 2]); return o; };

export function buildReport(d, { complete = true, bytes = 0, nameOf = null } = {}) {
  const nm = (b) => (nameOf ? nameOf(b) + " (" + b + ")" : String(b));
  const L = [];
  L.push("## تقرير استيراد الربط" + (complete ? "" : " (جزئي: أُوقف المسح)"));
  const c = d.checks;
  L.push("صفوف مفكوكة/معدودة: tafsir_link " + c.tafsir_link.rows + "/" + c.tafsir_link.expected + " | hadith_link " + c.hadith_link.rows + "/" + c.hadith_link.expected +
    " | aya " + c.aya.rows + "/" + c.aya.expected + " | sura " + c.sura.rows + "/" + c.sura.expected + " | rawi " + c.rawi.rows + "/" + c.rawi.expected + " | esnad " + c.esnad.rows + "/" + c.esnad.expected);
  L.push("صفحات معلّقة لم تُنسب لجدول: " + d.orphans + (bytes ? " | حجم المحفوظ ~" + (bytes / 1048576).toFixed(1) + " MB" : ""));
  if (nameOf) {
    L.push("كتب التفسير المرتبطة (" + d.tafsirBooks.length + "):"); for (const b of d.tafsirBooks) L.push("- " + nm(b));
    L.push("كتب الحديث المرتبطة (" + d.hadithBooks.length + "):"); for (const b of d.hadithBooks) L.push("- " + nm(b));
  } else {
    L.push("كتب التفسير (" + d.tafsirBooks.length + "): " + d.tafsirBooks.join(" "));
    L.push("كتب الحديث (" + d.hadithBooks.length + "): " + d.hadithBooks.join(" "));
  }
  L.push("كتب لها أسانيد في esnad: " + d.esnad.byBook.size);
  L.push("");
  L.push("## الكتب الثلاثة");
  for (const b of WATCH) {
    const t = forBook(d.tafsirLinks, b), h = forBook(d.hadithLinks, b);
    L.push(nm(b) + ": في tafsir_book=" + (d.tafsirBooks.includes(b) ? "نعم" : "لا") + " | في hadith_book=" + (d.hadithBooks.includes(b) ? "نعم" : "لا") +
      " | روابط تفسير " + t.pages.length + " (صفحات " + range(t.pages) + ") | روابط حديث " + h.pages.length + " (صفحات " + range(h.pages) + ", مفاتيح " + range(h.keys) + ") | أسانيد " + (d.esnad.byBook.get(b) || 0));
    if (h.pages.length) L.push("   عينة حديث (مفتاح:صفحة): " + h.keys.slice(0, 5).map((k, i) => k + ":" + h.pages[i]).join(" "));
    if (t.pages.length) L.push("   عينة تفسير (آية:صفحة): " + t.keys.slice(0, 5).map((k, i) => k + ":" + t.pages[i]).join(" "));
  }
  L.push("");
  L.push("## تحقق المعرّفات");
  const fat = []; for (let i = 0; i < d.tafsirLinks.length; i += 3) if (d.tafsirLinks[i + 1] === 42 && d.tafsirLinks[i] >= 1 && d.tafsirLinks[i] <= 7) fat.push(d.tafsirLinks[i] + ":" + d.tafsirLinks[i + 2]);
  L.push("الكتاب 42، آيات الفاتحة 1–7 (آية:صفحة): " + (fat.join(" ") || "لا روابط") + "  | المتوقع: عنوان الفاتحة عند page.id=30");
  for (const [k, pg] of [[2464, 8], [89, 11], [91, 12]]) {
    const w = where(d.hadithLinks, k);
    L.push("المفتاح " + k + " ← " + (w.slice(0, 12).join(" ") || "لا شيء") + (w.length > 12 ? " … (" + w.length + ")" : "") + " | 711:" + pg + " ضمنها؟ " + (w.includes("711:" + pg) ? "نعم" : "لا"));
  }
  L.push("الفاتحة في sura: " + cut(JSON.stringify(d.sura.slice(0, 3)), 200));
  L.push("");
  L.push("## الرواة");
  const chain = [2651, 3234, 1580, 2779, 6792, 3889, 6116];
  const idx = new Map(d.rawi.ids.map((id, i) => [id, i]));
  L.push("سلسلة الحديث 2464 في مسلم: " + chain.map((id) => idx.has(id) ? d.rawi.names[idx.get(id)] + (d.rawi.death[idx.get(id)] > 0 ? " (ت " + d.rawi.death[idx.get(id)] + ")" : "") : "؟" + id).join(" ← "));
  for (const s of d.rawi.jarhSamples) L.push("عينة جرح (" + s.name + "): " + s.jarh);
  for (const b of WATCH) for (const s of d.esnad.samples.get(b) || []) L.push("esnad " + b + " ص" + s.page + " ح" + s.hadith + ": " + s.chain);
  return L;
}

export async function importLinks({ source, fflate, token = { cancelled: false }, onProgress, store = kvSet, dataVersion = "", nameOf = null } = {}) {
  const col = createCollector();
  const scanner = createScanner({ onLeaf: col.onLeaf });
  const res = await scanDb("services", { source, fflate, token, onProgress, scanner });
  const d = col.resolve(scanner, res.rep);
  let bytes = 0;
  if (res.complete) {
    const payload = {
      version: 1, builtAt: new Date().toISOString(), dataVersion,
      tafsirBooks: d.tafsirBooks, hadithBooks: d.hadithBooks, tafsirLinks: d.tafsirLinks, hadithLinks: d.hadithLinks,
      sura: d.sura, ayaText: d.aya.map((x) => x == null ? "" : x),
      rawiIds: Int32Array.from(d.rawi.ids), rawiDeath: Int32Array.from(d.rawi.death), rawiNames: d.rawi.names
    };
    bytes = d.tafsirLinks.byteLength + d.hadithLinks.byteLength + payload.ayaText.reduce((a, x) => a + x.length * 2, 0) + d.rawi.names.reduce((a, x) => a + x.length * 2, 0) + d.rawi.ids.length * 8;
    await store(LINKS_KEY, payload);
  }
  return { lines: buildReport(d, { complete: res.complete, bytes, nameOf }), data: d, complete: res.complete };
}
