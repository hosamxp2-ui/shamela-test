// إدارة الفهرس: بناؤه من master.db وindex.json، ثم البحث والفرز والتصفية.
import { normalizeArabic } from "./arabic.js";
import { parseQuery, buildSearchIndex, runSearch } from "../search/query.js";

export const SQL = {
  categories: "SELECT category_id AS id, category_name AS name, category_order AS ord FROM category ORDER BY category_order",
  authors: "SELECT a.author_id AS id, a.author_name AS name, a.death_number AS death, n.name_norm AS norm " +
           "FROM author a LEFT JOIN author_norm n ON n.author_id = a.author_id",
  books: "SELECT b.book_id AS id, b.book_name AS name, b.book_category AS cat, b.main_author AS author, " +
         "n.name_norm AS norm, n.author_norm AS authorNorm, n.added_key AS added " +
         "FROM book b LEFT JOIN book_norm n ON n.book_id = b.book_id WHERE b.hidden = 0 OR b.hidden IS NULL",
  authorBooks: "SELECT author_id AS a, book_id AS b FROM author_book"
};

// db: كائن له all(sql) يعيد مصفوفة صفوف. index: محتوى index.json.
export function buildRaw(db, index, manifest) {
  const files = {};
  for (const e of index.books) {
    files[e.id] = { pack: e.pack, offset: e.offset, length: e.length, size: e.size, sha256: e.sha256, pages: e.pages, titles: e.titles };
  }
  const authorBooks = {};
  for (const r of db.all(SQL.authorBooks)) (authorBooks[r.a] || (authorBooks[r.a] = [])).push(r.b);
  return {
    categories: db.all(SQL.categories),
    authors: db.all(SQL.authors),
    books: db.all(SQL.books),
    authorBooks,
    files,
    meta: {
      dataVersion: manifest && manifest.data ? manifest.data.version : "",
      builtAt: new Date().toISOString()
    }
  };
}

export function createCatalog(raw) {
  const authorsById = new Map(raw.authors.map((a) => [a.id, a]));
  const catsById = new Map(raw.categories.map((c) => [c.id, c]));
  const booksById = new Map(raw.books.map((b) => [b.id, b]));

  const bookAuthors = new Map(); // book id -> author ids
  for (const [aid, bids] of Object.entries(raw.authorBooks)) {
    for (const bid of bids) {
      if (!bookAuthors.has(bid)) bookAuthors.set(bid, []);
      bookAuthors.get(bid).push(Number(aid));
    }
  }
  const catCounts = new Map();
  for (const b of raw.books) catCounts.set(b.cat, (catCounts.get(b.cat) || 0) + 1);
  const authorCounts = new Map(Object.entries(raw.authorBooks).map(([a, ids]) => [Number(a), ids.length]));

  const catNorm = new Map(raw.categories.map((c) => [c.id, normalizeArabic(c.name)]));
  const catOrder = new Map(raw.categories.map((c) => [c.id, c.ord]));
  let searchIndex = null; // يُبنى عند أول بحث فقط ليبقى الإقلاع سريعًا
  const getIndex = () => searchIndex || (searchIndex = buildSearchIndex(raw.books, catNorm));

  const authorName = (id) => { const a = authorsById.get(id); return a ? a.name : ""; };
  const collator = new Intl.Collator("ar");

  return {
    meta: raw.meta,
    totals: {
      books: raw.books.length,
      available: raw.books.filter((b) => raw.files[b.id]).length,
      authors: raw.authors.length,
      categories: raw.categories.length
    },
    getBook: (id) => booksById.get(id) || null,
    getAuthor: (id) => authorsById.get(id) || null,
    getCategory: (id) => catsById.get(id) || null,
    authorName,
    fileInfo: (id) => raw.files[id] || null,
    bookAuthorIds: (id) => {
      const ids = bookAuthors.get(id);
      if (ids && ids.length) return ids;
      const b = booksById.get(id);
      return b && b.author ? [b.author] : [];
    },

    categories() {
      return raw.categories.map((c) => ({ ...c, count: catCounts.get(c.id) || 0 }));
    },

    authors({ q = "" } = {}) {
      const words = normalizeArabic(q).split(" ").filter(Boolean);
      return raw.authors
        .filter((a) => (authorCounts.get(a.id) || 0) > 0)
        .filter((a) => { const n = a.norm || normalizeArabic(a.name); return words.every((w) => n.includes(w)); })
        .map((a) => ({ ...a, count: authorCounts.get(a.id) || 0 }))
        .sort((x, y) => collator.compare(x.name, y.name));
    },

    // q: كلمات | "عبارة" | -استبعاد ، fields: all|title|author|category ، exact: كلمات كاملة
    // cat: رقم القسم ، author: رقم المؤلف
    // sort: relevance | name | author | category | added | pages ، dir: asc | desc
    searchBooks({ q = "", cat = null, author = null, fields = "all", exact = false, sort = "name", dir = "asc" } = {}) {
      const parsed = parseQuery(q);
      const scores = new Map();
      let list = raw.books;
      if (parsed.terms.length) {
        const hits = runSearch(getIndex(), parsed, { fields, exact });
        list = hits.map((h) => { scores.set(raw.books[h.i].id, h.score); return raw.books[h.i]; });
      }
      let allowed = null;
      if (author != null) allowed = new Set(raw.authorBooks[author] || []);
      list = list.filter((b) => (cat == null || b.cat === cat) && (!allowed || allowed.has(b.id)));
      const sign = dir === "desc" ? -1 : 1;
      const pages = (b) => (raw.files[b.id] ? raw.files[b.id].pages : -1);
      const byName = (a, b) => collator.compare(a.name, b.name);
      const cmp = {
        relevance: (a, b) => (scores.get(b.id) || 0) - (scores.get(a.id) || 0) || byName(a, b),
        name: byName,
        author: (a, b) => collator.compare(authorName(a.author), authorName(b.author)) || byName(a, b),
        category: (a, b) => (catOrder.get(a.cat) || 0) - (catOrder.get(b.cat) || 0) || byName(a, b),
        added: (a, b) => (a.added || 0) - (b.added || 0) || byName(a, b),
        pages: (a, b) => pages(a) - pages(b) || byName(a, b)
      }[sort] || byName;
      return list.slice().sort((a, b) => sign * cmp(a, b));
    }
  };
}

export function formatAdded(key) {
  if (!key) return "";
  const s = String(key);
  return s.length === 8 ? `${s.slice(0, 4)}/${s.slice(4, 6)}/${s.slice(6, 8)} هـ` : s;
}
