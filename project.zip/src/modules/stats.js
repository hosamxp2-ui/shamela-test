// إحصائيات القراءة (محلية): صفحات اليوم ووقت القراءة، والصفحات المقروءة لكل كتاب بلا تكرار.
import { kvGet, kvSet } from "../database/idb.js";

const MAX_DAYS = 400;
export const dayKey = (d) => {
  const p = (n) => String(n).padStart(2, "0");
  return d.getFullYear() + "-" + p(d.getMonth() + 1) + "-" + p(d.getDate());
};

// نطاقات [بداية، نهاية] مرتبة ومدمجة للصفحات المقروءة
export function addToRanges(ranges, i) {
  const out = [];
  let placed = false;
  for (const [a, b] of ranges) {
    if (placed || b < i - 1) { out.push([a, b]); continue; }
    if (a > i + 1) { out.push([i, i], [a, b]); placed = true; continue; }
    out.push([Math.min(a, i), Math.max(b, i)]); placed = true;
  }
  if (!placed) out.push([i, i]);
  const merged = [];
  for (const r of out) {
    const last = merged[merged.length - 1];
    if (last && r[0] <= last[1] + 1) last[1] = Math.max(last[1], r[1]); else merged.push([r[0], r[1]]);
  }
  return merged;
}
export const countRanges = (ranges) => ranges.reduce((s, [a, b]) => s + (b - a + 1), 0);
export const hasInRanges = (ranges, i) => ranges.some(([a, b]) => i >= a && i <= b);

export function createStatsStore({ get = kvGet, set = kvSet, now = () => new Date() } = {}) {
  let days = {};            // { "2026-11-15": { s: ثوانٍ, p: صفحات جديدة, b: [معرّفات الكتب] } }
  let totals = { pages: 0, seconds: 0 };
  const ranges = new Map(); // bookId -> [[a,b],...]
  let pendingSeconds = 0;

  const today = () => dayKey(now());
  const bucket = (k) => (days[k] || (days[k] = { s: 0, p: 0, b: [] }));
  async function save() {
    const keys = Object.keys(days).sort();
    if (keys.length > MAX_DAYS) for (const k of keys.slice(0, keys.length - MAX_DAYS)) delete days[k];
    try { await set("stats:days", days); await set("stats:totals", totals); return true; } catch (_) { return false; }
  }

  const api = {
    async load() {
      try { const d = await get("stats:days"); days = d && typeof d === "object" && !Array.isArray(d) ? d : {}; } catch (_) { days = {}; }
      for (const k of Object.keys(days)) {
        const v = days[k];
        if (!v || !Number.isFinite(v.s) || !Number.isFinite(v.p)) delete days[k]; else v.b = Array.isArray(v.b) ? v.b.filter(Number.isInteger) : [];
      }
      try { const t = await get("stats:totals"); totals = t && Number.isFinite(t.pages) && Number.isFinite(t.seconds) ? { pages: t.pages, seconds: t.seconds } : { pages: 0, seconds: 0 }; }
      catch (_) { totals = { pages: 0, seconds: 0 }; }
    },
    async loadBook(bookId) {
      let r = [];
      try { const v = await get("readpages:" + bookId); if (Array.isArray(v)) r = v.filter((x) => Array.isArray(x) && Number.isInteger(x[0]) && Number.isInteger(x[1]) && x[0] <= x[1]); } catch (_) { /* فارغ */ }
      ranges.set(bookId, r);
      return r;
    },
    readPages: (bookId) => countRanges(ranges.get(bookId) || []),
    // تُحسب الصفحة مرة واحدة فقط (أول قراءة لها)
    async recordPage(bookId, pageIndex) {
      if (!ranges.has(bookId)) await api.loadBook(bookId);
      const r = ranges.get(bookId);
      if (hasInRanges(r, pageIndex)) return false;
      ranges.set(bookId, addToRanges(r, pageIndex));
      const d = bucket(today());
      d.p += 1;
      if (!d.b.includes(bookId)) d.b.push(bookId);
      totals.pages += 1;
      try { await set("readpages:" + bookId, ranges.get(bookId)); } catch (_) { /* نتابع */ }
      await save();
      return true;
    },
    // تُجمَّع الثواني في الذاكرة وتُكتب عند flush
    addSeconds(bookId, secs) {
      if (!(secs > 0) || secs > 600) return;
      pendingSeconds += secs;
      const d = bucket(today());
      d.s += secs;
      totals.seconds += secs;
      if (!d.b.includes(bookId)) d.b.push(bookId);
    },
    async flush() { if (pendingSeconds > 0) { pendingSeconds = 0; await save(); } },

    todayStats() { const d = days[today()]; return { pages: d ? d.p : 0, seconds: d ? d.s : 0 }; },
    totals: () => ({ ...totals }),

    // آخر n يومًا (الأقدم أولًا) مع أيام فارغة
    series(n) {
      const out = [];
      const base = now();
      for (let i = n - 1; i >= 0; i--) {
        const d = new Date(base.getFullYear(), base.getMonth(), base.getDate() - i);
        const k = dayKey(d);
        const v = days[k];
        out.push({ key: k, date: d, pages: v ? v.p : 0, seconds: v ? v.s : 0, books: v ? v.b.length : 0 });
      }
      return out;
    },
    // معدلات وسلسلة الأيام المتتالية
    summary() {
      const w = api.series(7), m = api.series(30), month4 = api.series(28);
      const sum = (a, f) => a.reduce((s, x) => s + x[f], 0);
      const active = (x) => x.pages > 0 || x.seconds >= 30;
      let streak = 0;
      const lastDays = api.series(MAX_DAYS > 120 ? 120 : MAX_DAYS);
      let i = lastDays.length - 1;
      if (!active(lastDays[i])) i--; // اليوم لم يبدأ بعد: لا نكسر السلسلة
      for (; i >= 0 && active(lastDays[i]); i--) streak++;
      let best = 0, run = 0;
      for (const x of lastDays) { run = active(x) ? run + 1 : 0; if (run > best) best = run; }
      return {
        weekPages: sum(w, "pages"), weekSeconds: sum(w, "seconds"),
        monthPages: sum(m, "pages"), monthSeconds: sum(m, "seconds"),
        avgDayPages: Math.round((sum(w, "pages") / 7) * 10) / 10, avgDaySeconds: Math.round(sum(w, "seconds") / 7),
        avgWeekPages: Math.round((sum(month4, "pages") / 4) * 10) / 10, avgWeekSeconds: Math.round(sum(month4, "seconds") / 4),
        streak, bestStreak: best, activeDays30: m.filter(active).length
      };
    }
  };
  return api;
}
