// الربط الحديثي: يقرأ عمود page.services (JSON فيه hadeeth مفاتيح وesnad سلاسل رواة) ويربطه بما استُورد من services.db:
// أسماء الرواة (rawi) ومواضع الحديث نفسه في كتب أخرى (hadith_link بمفتاح موحّد). لا مطابقة نصية.
// ثبت على 711 أن المفتاح في الصفحة = key_id في hadith_link، وأن page_id = page.id. الكتب بلا services (مثل 735) لا ميزة لها.
import { kvGet } from "../database/idb.js";

const KEY = "services-links";
let cache = null;
export const resetLinksCache = () => { cache = null; };

export function indexLinks(raw) {
  const byKey = new Map();
  const h = raw.hadithLinks || [];
  for (let i = 0; i + 2 < h.length; i += 3) {
    let a = byKey.get(h[i]); if (!a) { a = []; byKey.set(h[i], a); }
    a.push([h[i + 1], h[i + 2]]);
  }
  const rawiIndex = new Map();
  const ids = raw.rawiIds || [];
  for (let i = 0; i < ids.length; i++) rawiIndex.set(ids[i], i);
  return { byKey, rawiIndex, rawiNames: raw.rawiNames || [], rawiDeath: raw.rawiDeath || [], hadithBooks: new Set(raw.hadithBooks || []) };
}

export async function loadLinks(get = kvGet) {
  if (cache) return cache;
  let raw = null;
  try { raw = await get(KEY); } catch (_) { raw = null; }
  if (!raw || raw.version !== 1) return null;
  cache = indexLinks(raw);
  return cache;
}

// "02464 s 2651 3234 …" ← المفتاح، علامة، ثم أرقام الرواة بترتيب التخزين
export function parseEsnad(str) {
  const toks = String(str).trim().split(/\s+/);
  if (toks.length < 2) return null;
  const key = Number(toks[0]);
  const rest = toks.slice(1);
  const ids = rest.filter((x) => /^\d+$/.test(x)).map(Number);
  if (!Number.isFinite(key) || !ids.length) return null;
  return { key, ids };
}

export function parseServices(s) {
  if (!s) return null;
  let o;
  try { o = JSON.parse(s); } catch (_) { return null; }
  if (!o || typeof o !== "object") return null;
  const keys = (Array.isArray(o.hadeeth) ? o.hadeeth : []).filter((k) => Number.isInteger(k));
  const esnad = (Array.isArray(o.esnad) ? o.esnad : []).filter((x) => typeof x === "string").map(parseEsnad).filter(Boolean);
  return { keys, esnad };
}

// يعيد لكل مفتاح: السلاسل (مرتبة من صاحب الكتاب = آخر المخزَّن) والمواضع الأخرى مجمّعة بحسب الكتاب
export function buildHadithView(sv, links, bookId, pageId, { maxChains = 3 } = {}) {
  return sv.keys.map((key) => {
    const chains = sv.esnad.filter((e) => e.key === key);
    const shown = !links ? [] : chains.slice(0, maxChains).map((c) => ({
      steps: [...c.ids].reverse().map((rid) => {
        const i = links.rawiIndex.get(rid);
        if (i === undefined) return { id: rid, name: null, death: null };
        const d = links.rawiDeath[i];
        return { id: rid, name: links.rawiNames[i] || null, death: d > 0 ? d : null };
      })
    }));
    const groups = [];
    if (links) {
      const seen = new Set(), by = new Map();
      for (const [b, p] of links.byKey.get(key) || []) {
        if (b === bookId && p === pageId) continue;
        const k = b + ":" + p; if (seen.has(k)) continue; seen.add(k);
        let g = by.get(b); if (!g) { g = { book: b, pages: [] }; by.set(b, g); groups.push(g); }
        g.pages.push(p);
      }
    }
    return { key, hasLinks: !!links, chains: shown, moreChains: Math.max(0, chains.length - maxChains), totalChains: chains.length, groups };
  });
}
