// مدير التنزيل: قائمة انتظار تنزّل كتابًا واحدًا في كل مرة، على قطع (Range) تُحفظ تباعًا،
// فيمكن الإيقاف والاستئناف من آخر قطعة حتى بعد إغلاق التطبيق. لا يبدأ شيء إلا بطلب المستخدم.
import { sha256Hex, gunzip, ConnectorError } from "../services/data-connector.js";
import { t } from "../strings.js";

const DEFAULT_CHUNK = 2 * 1024 * 1024;

export function createDownloadManager({ store, source, catalog, chunkSize = DEFAULT_CHUNK }) {
  const records = new Map();
  const queue = [];
  const listeners = new Set();
  const pauseReq = new Set();
  const cancelReq = new Set();
  let runPromise = null;
  let current = null;
  let manifest = null;

  const emit = () => { for (const fn of listeners) { try { fn(); } catch (_) { /* مستمع معطوب لا يوقف المدير */ } } };
  const save = (rec) => { rec.updatedAt = Date.now(); return store.putRecord(rec); };
  const messageOf = (e) => (e && e.name === "ConnectorError" ? e.message : t("err.generic", { message: (e && e.message) || String(e) }));

  async function dropAll(id) {
    await store.deleteChunks(id);
    await store.deleteRecord(id);
    records.delete(id);
    pauseReq.delete(id);
    cancelReq.delete(id);
  }

  async function assemble(id, rec) {
    const out = new Uint8Array(rec.total);
    let pos = 0;
    for (let n = 0; n < rec.nChunks; n++) {
      const c = await store.getChunk(id, n);
      if (!c) throw new ConnectorError("MISSING_CHUNK", t("err.generic", { message: "chunk " + n }));
      out.set(c, pos);
      pos += c.length;
    }
    return out;
  }

  async function process(id) {
    const rec = records.get(id);
    if (!rec || rec.status !== "queued") return;
    rec.status = "downloading";
    rec.error = null;
    current = id;
    await save(rec);
    emit();
    try {
      if (!manifest) manifest = await source.manifest();
      const entry = catalog.fileInfo(id);
      while (rec.chunks < rec.nChunks) {
        if (cancelReq.has(id)) { await dropAll(id); emit(); return; }
        if (pauseReq.has(id)) { pauseReq.delete(id); rec.status = "paused"; await save(rec); emit(); return; }
        const n = rec.chunks;
        const start = n * chunkSize;
        const len = Math.min(chunkSize, rec.total - start);
        const bytes = await source.bookRange(manifest, entry, start, len);
        await store.putChunk(id, n, bytes);
        rec.chunks = n + 1;
        rec.done = start + len;
        await save(rec);
        emit();
      }
      if (cancelReq.has(id)) { await dropAll(id); emit(); return; }
      const all = await assemble(id, rec);
      if ((await sha256Hex(all)) !== rec.sha256) {
        await store.deleteChunks(id);
        rec.chunks = 0; rec.done = 0; rec.status = "failed"; rec.error = t("err.sha");
      } else {
        rec.status = "done"; rec.doneAt = Date.now(); rec.error = null;
      }
      await save(rec);
    } catch (e) {
      manifest = null; // قد تكون الروابط تغيّرت؛ نجلب بيانات المصدر من جديد في المحاولة التالية
      rec.status = "failed";
      rec.error = messageOf(e);
      try { await save(rec); } catch (_) { /* نتابع */ }
    } finally {
      current = null;
      emit();
    }
  }

  function start() {
    if (runPromise) return runPromise;
    runPromise = (async () => {
      try {
        while (queue.length) await process(queue.shift());
      } finally {
        runPromise = null;
        emit();
      }
    })();
    return runPromise;
  }

  const api = {
    async init() {
      for (const r of await store.allRecords()) {
        if (r.status === "downloading" || r.status === "queued") { r.status = "paused"; await store.putRecord(r); }
        records.set(r.id, r);
      }
      emit();
    },

    subscribe(fn) { listeners.add(fn); return () => listeners.delete(fn); },
    whenIdle() { return runPromise || Promise.resolve(); },

    async enqueue(ids) {
      for (const id of ids) {
        const entry = catalog.fileInfo(id);
        if (!entry) continue;
        let rec = records.get(id);
        if (rec && ["done", "queued", "downloading"].includes(rec.status)) continue;
        if (rec && (rec.sha256 !== entry.sha256 || rec.total !== entry.length)) { await store.deleteChunks(id); rec = null; }
        if (!rec) {
          rec = { id, total: entry.length, sha256: entry.sha256, chunks: 0, nChunks: Math.max(1, Math.ceil(entry.length / chunkSize)), done: 0, addedAt: Date.now() };
        }
        rec.status = "queued";
        rec.error = null;
        await save(rec);
        records.set(id, rec);
        queue.push(id);
      }
      emit();
      start();
    },

    async pause(id) {
      const rec = records.get(id);
      if (!rec) return;
      if (rec.status === "queued") {
        const i = queue.indexOf(id); if (i >= 0) queue.splice(i, 1);
        rec.status = "paused"; await save(rec); emit();
      } else if (rec.status === "downloading") {
        pauseReq.add(id);
      }
    },
    async pauseAll() { for (const id of [...records.keys()]) await api.pause(id); },
    resume: (id) => api.enqueue([id]),
    async resumeAll() { await api.enqueue([...records.values()].filter((r) => r.status === "paused").map((r) => r.id)); },
    retry: (id) => api.enqueue([id]),

    async cancel(id) {
      const rec = records.get(id);
      if (!rec) return;
      if (current === id) { cancelReq.add(id); return; }
      const i = queue.indexOf(id); if (i >= 0) queue.splice(i, 1);
      await dropAll(id);
      emit();
    },
    remove(id) { return api.cancel(id); },
    async removeAll() { for (const id of [...records.keys()]) if (id !== current) await api.cancel(id); },

    status: (id) => records.get(id) || null,
    isDownloaded: (id) => { const r = records.get(id); return !!r && r.status === "done"; },
    list() {
      const order = { downloading: 0, queued: 1, paused: 2, failed: 3, done: 4 };
      return [...records.values()].sort((a, b) => (order[a.status] - order[b.status]) || (b.addedAt - a.addedAt));
    },
    totals() {
      let done = 0, doneBytes = 0, active = 0;
      for (const r of records.values()) {
        if (r.status === "done") { done++; doneBytes += r.total; } else active++;
      }
      return { done, doneBytes, active };
    },
    // تقدير ما سيُنزَّل فعلًا (يستثني المنزّل والمتاح غير الموجود)
    estimate(ids) {
      let count = 0, bytes = 0, skipped = 0;
      for (const id of ids) {
        const entry = catalog.fileInfo(id);
        const rec = records.get(id);
        if (!entry || (rec && (rec.status === "done" || rec.status === "queued" || rec.status === "downloading"))) { skipped++; continue; }
        count++;
        bytes += entry.length - (rec && rec.sha256 === entry.sha256 ? rec.done : 0);
      }
      return { count, bytes, skipped };
    },

    // بايتات قاعدة الكتاب (SQLite) بعد فك الضغط، من الجهاز فقط
    async getBookBytes(id) {
      const rec = records.get(id);
      if (!rec || rec.status !== "done") throw new ConnectorError("NOT_DOWNLOADED", t("err.notDownloaded"));
      return gunzip(await assemble(id, rec));
    }
  };
  return api;
}
