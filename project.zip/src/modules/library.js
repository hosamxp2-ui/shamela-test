// مكتبتي الشخصية: المفضلة وتقييماتك (محلية). التقييم شخصي لأن المصدر لا يحوي تقييمات.
import { kvGet, kvSet } from "../database/idb.js";

const MAX_FAVS = 1000;

export function createLibraryStore({ get = kvGet, set = kvSet, now = () => Date.now() } = {}) {
  let favs = [];      // [{ id, at }] الأحدث أولًا
  let ratings = {};   // { [bookId]: 1..5 }
  let loaded = false;

  const save = async (key, value) => { try { await set(key, value); return true; } catch (_) { return false; } };

  return {
    async load() {
      try {
        const f = await get("favorites");
        favs = Array.isArray(f) ? f.filter((x) => x && Number.isInteger(x.id)).map((x) => ({ id: x.id, at: Number(x.at) || 0 })) : [];
      } catch (_) { favs = []; }
      try {
        const r = await get("ratings");
        ratings = {};
        if (r && typeof r === "object" && !Array.isArray(r)) {
          for (const [k, v] of Object.entries(r)) if (Number.isInteger(v) && v >= 1 && v <= 5 && /^\d+$/.test(k)) ratings[k] = v;
        }
      } catch (_) { ratings = {}; }
      loaded = true;
    },
    isLoaded: () => loaded,

    isFavorite: (id) => favs.some((x) => x.id === id),
    favoriteIds: () => favs.slice().sort((a, b) => b.at - a.at).map((x) => x.id),
    async toggleFavorite(id) {
      const had = favs.some((x) => x.id === id);
      favs = had ? favs.filter((x) => x.id !== id) : [{ id, at: now() }, ...favs].slice(0, MAX_FAVS);
      await save("favorites", favs);
      return !had;
    },

    rating: (id) => ratings[String(id)] || 0,
    // نفس النجمة مرة ثانية تمسح التقييم
    async setRating(id, n) {
      const v = Number(n);
      if (!Number.isInteger(v) || v < 0 || v > 5) return this.rating(id);
      const key = String(id);
      if (v === 0 || ratings[key] === v) delete ratings[key]; else ratings[key] = v;
      await save("ratings", ratings);
      return ratings[key] || 0;
    }
  };
}
