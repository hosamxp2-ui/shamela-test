// يتذكر موافقة المستخدم على فتح كتب بين الحد التلقائي (100MB) والحد الأقصى (220MB) فلا يضغط «فتحه رغم ذلك» كل مرة.
// حماية من حلقة انهيار: قبل الفتح يُسجَّل «معلَّق»؛ يُمحى عند اكتمال التحميل. إن وُجد معلّقًا للكتاب نفسه عند الفتح التالي
// فمعناه أن المحاولة السابقة لم تكتمل (انهيار/شاشة بيضاء) فتُسحب الموافقة ويُطلب منه الضغط صراحةً من جديد.
import { kvGet, kvSet } from "../database/idb.js";

export const BIG_KEY = "bigbooks";
export const PENDING_KEY = "bigbook-pending";

export async function decideForce({ id, sizeBytes, limitBytes, forceParam = false, get = kvGet, set = kvSet }) {
  if (!(sizeBytes > limitBytes)) return { force: false, track: false };
  let allowed = (await get(BIG_KEY)) || [];
  if (!Array.isArray(allowed)) allowed = [];
  const pending = await get(PENDING_KEY);
  if (pending === id) {                       // محاولة سابقة لم تكتمل
    allowed = allowed.filter((x) => x !== id);
    await set(BIG_KEY, allowed); await set(PENDING_KEY, null);
    if (!forceParam) return { force: false, track: false, retracted: true };
  }
  if (forceParam && !allowed.includes(id)) { allowed.push(id); await set(BIG_KEY, allowed); }
  if (!forceParam && !allowed.includes(id)) return { force: false, track: false };
  await set(PENDING_KEY, id);
  return { force: true, track: true };
}

export async function finishBigOpen({ set = kvSet } = {}) { await set(PENDING_KEY, null); }
export async function forgetBigBooks({ set = kvSet } = {}) { await set(BIG_KEY, []); await set(PENDING_KEY, null); }
