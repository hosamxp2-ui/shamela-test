// فهرسة محلية لكتب تفسير لا ربط لها في الشاملة: تُستخرج «مراسي» (آية → صفحة) من بنية الكتاب نفسه:
//   1) عناوين السور (اسم سورة مطابق)  2) عناوين أرقام الآيات (١، ٦ - ٧، الآية ٢٥٥)  3) عناوين تحوي ﴿آية﴾
//   4) آيات ﴿ ﴾ في متن الصفحة بشرط التقدّم الرتيب داخل السورة الحالية (لتجاهل الاستشهادات بآيات أخرى).
// ما تعطيه: صفحة «دقيقة» إن وقعت الآية ضمن مرساة، أو «تقريبية» (أقرب مرساة سابقة). هذا استنتاج من بنية الكتاب لا معرّف رسمي.
// ما لا تغطيه: كتب بلا عناوين آيات ولا ﴿ ﴾ في المتن، والآيات المذكورة بلا أقواس.
import { kvGet } from "../database/idb.js";

export const LOCAL_TAFSIR_KEY = "tafsir-local";
const toWest = (s) => String(s).replace(/[٠-٩]/g, (c) => String(c.charCodeAt(0) - 0x660));
const NUM_TITLE = /^(?:تفسير\s+)?(?:الآيات?|آيات?|الايات?|الآية|الاية)?\s*[\[(]?\s*([٠-٩0-9]{1,3})\s*(?:(?:-|–|إلى|الى)\s*([٠-٩0-9]{1,3}))?\s*[\])]?\s*[.:]?\s*$/;
const stripTags = (h) => String(h || "").replace(/<[^>]*>/g, " ");
// أنواع الأقواس التي قد تُكتب بها الآية. المطابقة مع نص القرآن هي الفاصل، فلا خطر من الأقواس العامة.
const BR = /﴿([^﴿﴾]{3,800})﴾|\{([^{}]{3,800})\}|«([^«»]{3,800})»|\(([^()]{3,400})\)|\[([^\[\]]{3,400})\]/g;
const KINDS = ["fancy", "curly", "guil", "paren", "square"];
function* segments(text) {
  BR.lastIndex = 0; let m;
  while ((m = BR.exec(text))) { const i = [1, 2, 3, 4, 5].find((k) => m[k] !== undefined); yield { inner: m[i], kind: KINDS[i - 1], end: BR.lastIndex }; }
}

// أطول متتالية غير متناقصة (حسب from): تُبقي التسلسل القرآني الغالب وتُسقط الاستشهادات الشاردة
function lnds(items) {
  const tails = [], tailIdx = [], prev = new Array(items.length).fill(-1);
  for (let i = 0; i < items.length; i++) {
    const v = items[i].from; let lo = 0, hi = tails.length;
    while (lo < hi) { const m = (lo + hi) >> 1; if (tails[m] <= v) lo = m + 1; else hi = m; }
    tails[lo] = v; tailIdx[lo] = i; prev[i] = lo ? tailIdx[lo - 1] : -1;
  }
  const out = new Set(); let k = tailIdx[tails.length - 1];
  while (k !== undefined && k >= 0) { out.add(k); k = prev[k]; }
  return out;
}

export async function indexTafsirBook({ db, quran, chunk = 300, onProgress = () => {}, yieldFn = () => new Promise((r) => setTimeout(r, 0)) }) {
  const st = { pages: 0, titles: 0, suraTitles: 0, numTitles: 0, verseTitles: 0, bodyAccepted: 0, bodyRejected: 0, brackets: {}, bracketHits: {}, samples: [] };
  for (const k of KINDS) { st.brackets[k] = 0; st.bracketHits[k] = 0; }
  let titles = [];
  try { titles = db.all("SELECT id, page, parent, text FROM title ORDER BY id"); } catch (_) { titles = []; }
  st.titles = titles.length;
  const byPage = new Map();
  for (const t of titles) { let a = byPage.get(t.page); if (!a) { a = []; byPage.set(t.page, a); } a.push(t); }
  const suraOf = (aya) => { const l = quran.label(aya); return l ? l.sura : null; };

  // الأحداث بترتيب الكتاب، مقسّمة إلى مقاطع عند كل عنوان سورة
  const sections = [{ sura: null, events: [] }];
  const suraSeen = new Set(); const raw = [];
  const anchors = { push(from, to, page, src) { const n = raw.length; if (n >= 4 && raw[n - 4] === from && raw[n - 3] === to && raw[n - 2] === page && raw[n - 1] === src) return; raw.push(from, to, page, src); } };
  const sec = () => sections[sections.length - 1];
  const addVerses = (text, page, src) => {
    for (const sg of segments(text)) {
      st.brackets[sg.kind]++;
      const r = quran.find(sg.inner, text.slice(sg.end, sg.end + 70));
      if (!r || r.conf === "ref") continue;
      st.bracketHits[sg.kind]++;
      sec().events.push({ page, src, r });
    }
  };

  const total = db.all("SELECT COUNT(*) AS c, MIN(id) AS lo, MAX(id) AS hi FROM page")[0] || {};
  for (let lo = total.lo; total.c && lo <= total.hi; lo += chunk) {
    const rows = db.all("SELECT id, body FROM page WHERE id >= " + Number(lo) + " AND id < " + Number(lo + chunk) + " ORDER BY id");
    for (const row of rows) {
      st.pages++;
      for (const t of byPage.get(row.id) || []) {
        const text = String(t.text || "").trim();
        const sura = quran.suraByName(text);
        if (sura) { sections.push({ sura: sura.id, events: [] }); st.suraTitles++; suraSeen.add(sura.id); anchors.push(sura.first, sura.first, row.id, 3); continue; }
        const m = NUM_TITLE.exec(text), cs = sec().sura;
        if (m && cs != null) {
          const info = quran.suraInfo(cs), a = Number(toWest(m[1])), b = m[2] ? Number(toWest(m[2])) : a;
          if (a >= 1 && b >= a && b <= info.ayat) { anchors.push(info.first + a - 1, info.first + b - 1, row.id, 0); st.numTitles++; }
          continue;
        }
        addVerses(text, row.id, 1);
      }
      const body = stripTags(row.body);
      if (st.samples.length < 2) { const i = body.indexOf("قوله تعالى"); if (i >= 0) st.samples.push(body.slice(i, i + 110).replace(/\s+/g, " ")); }
      addVerses(body, row.id, 2);
    }
    onProgress({ done: st.pages, of: total.c });
    await yieldFn();
  }

  // حسم كل مقطع: آية واحدة داخل السورة ثم أطول تسلسل متصاعد، ثم الملتبس بين جارَيه
  for (const S of sections) {
    const singles = [], manys = [];
    S.events.forEach((e, order) => {
      const cands = (e.r.cands || [e.r.from]).filter((c) => S.sura == null || suraOf(c) === S.sura);
      if (cands.length === 1) singles.push({ order, page: e.page, src: e.src, from: cands[0], to: e.r.cands ? cands[0] : Math.max(cands[0], e.r.to) });
      else if (cands.length > 1) manys.push({ order, page: e.page, src: e.src, cands });
      else st.bodyRejected++;
    });
    const keep = lnds(singles);
    const chosen = singles.filter((_, i) => keep.has(i));
    st.bodyRejected += singles.length - chosen.length;
    for (const m of manys) {
      let lo = -Infinity, hi = Infinity;
      for (const c of chosen) { if (c.order < m.order) lo = c.from; else { hi = c.from; break; } }
      const ok = m.cands.filter((x) => x >= lo && x <= hi);
      if (ok.length === 1) chosen.push({ order: m.order, page: m.page, src: m.src, from: ok[0], to: ok[0] }); else st.bodyRejected++;
    }
    chosen.sort((x, y) => x.order - y.order);
    for (const c of chosen) { anchors.push(c.from, c.to, c.page, c.src); if (c.src === 1) st.verseTitles++; else st.bodyAccepted++; }
  }
  const arr = Int32Array.from(raw);
  const covered = new Uint8Array(6300);
  for (let i = 0; i < arr.length; i += 4) { if (arr[i + 3] === 3) continue; for (let a = arr[i]; a <= arr[i + 1] && a < 6300; a++) covered[a] = 1; }
  let cov = 0; for (let a = 1; a <= 6236; a++) cov += covered[a];
  return { anchors: arr, stats: { ...st, anchors: arr.length / 4, suras: suraSeen.size, coveredAyas: cov } };
}

// ---------- التخزين والاستعلام ----------
export async function loadLocalTafsir(get = kvGet) {
  let raw = null;
  try { raw = await get(LOCAL_TAFSIR_KEY); } catch (_) { raw = null; }
  return prepareLocal(raw);
}

export function prepareLocal(raw) {
  if (!raw || raw.version !== 1 || !raw.books) return null;
  const books = new Map();
  for (const [id, b] of Object.entries(raw.books)) {
    const a = b.anchors, n = a.length / 4, order = Array.from({ length: n }, (_, i) => i).sort((x, y) => a[x * 4] - a[y * 4] || (a[y * 4 + 3] === 3) - (a[x * 4 + 3] === 3) || a[x * 4 + 2] - a[y * 4 + 2]);
    books.set(Number(id), { a, order, stats: b.stats });
  }
  return { books };
}

// يعيد [{ book, pages: [page.id…], approx }] لكل كتاب مفهرس محليًا
export function localTafsirFor(idx, ayaId) {
  const out = [];
  if (!idx) return out;
  for (const [book, b] of idx.books) {
    const { a, order } = b;
    let lo = 0, hi = order.length;
    while (lo < hi) { const m = (lo + hi) >> 1; if (a[order[m] * 4] <= ayaId) lo = m + 1; else hi = m; }
    if (!lo) continue;
    const pages = [];
    for (let i = lo - 1, steps = 0; i >= 0 && steps < 60; i--, steps++) { const k = order[i] * 4; if (a[k + 3] !== 3 && a[k] <= ayaId && ayaId <= a[k + 1] && !pages.includes(a[k + 2])) pages.push(a[k + 2]); }
    if (pages.length) { out.push({ book, pages: pages.sort((x, y) => x - y), approx: false }); continue; }
    const prev = order[lo - 1] * 4;
    out.push({ book, pages: [a[prev + 2]], approx: true });
  }
  return out;
}

// يدمج نتيجة كتاب في المخزن القائم ويحفظ
export async function saveLocalBook(bookId, result, { get = kvGet, set }) {
  let raw = null;
  try { raw = await get(LOCAL_TAFSIR_KEY); } catch (_) { raw = null; }
  if (!raw || raw.version !== 1) raw = { version: 1, books: {} };
  raw.books[bookId] = { anchors: result.anchors, stats: result.stats, builtAt: new Date().toISOString() };
  await set(LOCAL_TAFSIR_KEY, raw);
}

export function bookReport(name, bookId, result, quran, idx) {
  const s = result.stats, L = [];
  L.push("## " + name + " (" + bookId + ")");
  L.push("صفحات " + s.pages + " | عناوين " + s.titles + " | عناوين سور معروفة " + s.suraTitles + " (سور مختلفة " + s.suras + "/114) | عناوين أرقام آيات " + s.numTitles + " | عناوين بآية " + s.verseTitles);
  L.push("آيات من المتن: قُبلت " + s.bodyAccepted + " ورُفضت " + s.bodyRejected + " (استشهاد بآية خارج التقدّم الرتيب) | مراسٍ " + s.anchors + " | آيات لها صفحة دقيقة " + s.coveredAyas + "/6236 (" + Math.round((s.coveredAyas / 6236) * 100) + "٪)");
  const nm = { fancy: "﴿﴾", curly: "{}", guil: "«»", paren: "()", square: "[]" };
  L.push("أقواس مطابقة للقرآن/كل الأقواس: " + Object.keys(nm).map((k) => nm[k] + " " + s.bracketHits[k] + "/" + s.brackets[k]).join(" | "));
  if (s.coveredAyas < 6236 * 0.3) for (const x of s.samples || []) L.push("   عينة نص «قوله تعالى»: " + x);
  for (const [su, ay] of [[1, 1], [2, 255], [18, 10], [36, 1], [112, 1]]) {
    const id = quran.idOf(su, ay), r = (localTafsirFor(idx, id).find((x) => x.book === bookId)) || null;
    L.push("   تجربة " + su + ":" + ay + " ← " + (r ? "صفحة معرّفها " + r.pages.join("، ") + (r.approx ? " (تقريبي)" : " (دقيق)") : "لا شيء"));
  }
  return L;
}
