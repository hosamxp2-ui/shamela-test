// فهرسة محلية لكتب تفسير لا ربط لها في الشاملة: تُستخرج «مراسي» (آية → صفحة) من بنية الكتاب نفسه:
//   1) عناوين السور (اسم سورة مطابق)  2) عناوين أرقام الآيات (١، ٦ - ٧، الآية ٢٥٥)  3) عناوين تحوي ﴿آية﴾
//   4) آيات ﴿ ﴾ في متن الصفحة بشرط التقدّم الرتيب داخل السورة الحالية (لتجاهل الاستشهادات بآيات أخرى).
// ما تعطيه: صفحة «دقيقة» إن وقعت الآية ضمن مرساة، أو «تقريبية» (أقرب مرساة سابقة). هذا استنتاج من بنية الكتاب لا معرّف رسمي.
// ما لا تغطيه: كتب بلا عناوين آيات ولا ﴿ ﴾ في المتن، والآيات المذكورة بلا أقواس.
import { kvGet } from "../database/idb.js";

export const LOCAL_TAFSIR_KEY = "tafsir-local";
const MAX_JUMP = 120;
const toWest = (s) => String(s).replace(/[٠-٩]/g, (c) => String(c.charCodeAt(0) - 0x660));
const NUM_TITLE = /^(?:تفسير\s+)?(?:الآيات?|آيات?|الايات?|الآية|الاية)?\s*[\[(]?\s*([٠-٩0-9]{1,3})\s*(?:(?:-|–|إلى|الى)\s*([٠-٩0-9]{1,3}))?\s*[\])]?\s*[.:]?\s*$/;
const stripTags = (h) => String(h || "").replace(/<[^>]*>/g, " ");

export async function indexTafsirBook({ db, quran, chunk = 300, onProgress = () => {}, yieldFn = () => new Promise((r) => setTimeout(r, 0)) }) {
  const st = { pages: 0, titles: 0, suraTitles: 0, numTitles: 0, verseTitles: 0, bodyAccepted: 0, bodyRejected: 0 };
  let titles = [];
  try { titles = db.all("SELECT id, page, parent, text FROM title ORDER BY id"); } catch (_) { titles = []; }
  st.titles = titles.length;
  const byPage = new Map();
  for (const t of titles) { let a = byPage.get(t.page); if (!a) { a = []; byPage.set(t.page, a); } a.push(t); }

  const raw = []; // [from, to, page, src] src: 0 رقم آية، 1 عنوان بآية، 2 متن، 3 سورة
  const anchors = { push(from, to, page, src) { const n = raw.length; if (n >= 4 && raw[n - 4] === from && raw[n - 3] === to && raw[n - 2] === page && raw[n - 1] === src) return; raw.push(from, to, page, src); } };
  const suraSeen = new Set();
  let cur = null, last = null; // cur: رقم السورة الحالية، last: معرّف آخر آية
  const suraOf = (aya) => { const l = quran.label(aya); return l ? l.sura : null; };
  const firstOf = (sid) => quran.suraInfo(sid).first;

  // يقرّر قبول آية مرشحة من نص (عنوان/متن) بقاعدة التقدّم الرتيب
  function accept(r, strict) {
    const cands = r.cands || [r.from];
    const ok = cands.filter((c) => {
      const s = suraOf(c); if (!s) return false;
      if (cur == null) return !strict;
      if (s === cur) return last == null || (c >= last && c <= last + MAX_JUMP);
      return s === cur + 1 && c - firstOf(s) <= 30;      // بداية السورة التالية
    });
    return ok.length === 1 ? { from: ok[0], to: r.cands ? ok[0] : r.to } : null;
  }

  const total = db.all("SELECT COUNT(*) AS c, MIN(id) AS lo, MAX(id) AS hi FROM page")[0] || {};
  for (let lo = total.lo; total.c && lo <= total.hi; lo += chunk) {
    const rows = db.all("SELECT id, body FROM page WHERE id >= " + Number(lo) + " AND id < " + Number(lo + chunk) + " ORDER BY id");
    for (const row of rows) {
      st.pages++;
      for (const t of byPage.get(row.id) || []) {
        const text = String(t.text || "").trim();
        const sura = quran.suraByName(text);
        if (sura) { cur = sura.id; last = sura.first - 1; st.suraTitles++; suraSeen.add(sura.id); anchors.push(sura.first, sura.first, row.id, 3); continue; }
        const m = NUM_TITLE.exec(text);
        if (m && cur != null) {
          const info = quran.suraInfo(cur), a = Number(toWest(m[1])), b = m[2] ? Number(toWest(m[2])) : a;
          if (a >= 1 && b >= a && b <= info.ayat) { const from = info.first + a - 1, to = info.first + b - 1; anchors.push(from, to, row.id, 0); last = to; st.numTitles++; }
          continue;
        }
        const vm = /﴿([^﴿﴾]{3,800})﴾/.exec(text);
        if (vm) {
          const r = quran.find(vm[1], "");
          const ok = r && accept(r, false);
          if (ok) { anchors.push(ok.from, ok.to, row.id, 1); last = ok.to; cur = suraOf(ok.from); st.verseTitles++; }
        }
      }
      const body = stripTags(row.body);
      if (body.includes("﴿")) {
        const re = /﴿([^﴿﴾]{3,800})﴾/g; let m;
        while ((m = re.exec(body))) {
          const after = body.slice(re.lastIndex, re.lastIndex + 70);
          const r = quran.find(m[1], after);
          if (!r || r.conf === "ref") continue;
          const ok = accept(r, false);
          if (ok) { anchors.push(ok.from, ok.to, row.id, 2); last = ok.to; cur = suraOf(ok.from); st.bodyAccepted++; } else st.bodyRejected++;
        }
      }
    }
    onProgress({ done: st.pages, of: total.c });
    await yieldFn();
  }
  const arr = Int32Array.from(raw);
  // تغطية دقيقة
  const covered = new Uint8Array(6300);
  for (let i = 0; i < arr.length; i += 4) { if (arr[i + 3] === 3) continue; for (let a = arr[i]; a <= arr[i + 1] && a < 6300; a++) covered[a] = 1; }
  let cov = 0; for (let a = 1; a <= 6236; a++) cov += covered[a];
  return { anchors: arr, stats: { ...st, anchors: arr.length / 4, suras: suraSeen.size, coveredAyas: cov } };
}

// ---------- التخزين والاستعلام ----------
export async function loadLocalTafsir(get = kvGet) {
  let raw = null;
  try { raw = await get(LOCAL_TAFSIR_KEY); } catch (_) { raw = null; }
  return prepareLocal(raw);
}

export function prepareLocal(raw) {
  if (!raw || raw.version !== 1 || !raw.books) return null;
  const books = new Map();
  for (const [id, b] of Object.entries(raw.books)) {
    const a = b.anchors, n = a.length / 4, order = Array.from({ length: n }, (_, i) => i).filter((i) => a[i * 4 + 3] !== 3).sort((x, y) => a[x * 4] - a[y * 4] || a[x * 4 + 2] - a[y * 4 + 2]);
    books.set(Number(id), { a, order, stats: b.stats });
  }
  return { books };
}

// يعيد [{ book, pages: [page.id…], approx }] لكل كتاب مفهرس محليًا
export function localTafsirFor(idx, ayaId) {
  const out = [];
  if (!idx) return out;
  for (const [book, b] of idx.books) {
    const { a, order } = b;
    let lo = 0, hi = order.length;
    while (lo < hi) { const m = (lo + hi) >> 1; if (a[order[m] * 4] <= ayaId) lo = m + 1; else hi = m; }
    if (!lo) continue;
    const pages = [];
    for (let i = lo - 1, steps = 0; i >= 0 && steps < 60; i--, steps++) { const k = order[i] * 4; if (a[k] <= ayaId && ayaId <= a[k + 1] && !pages.includes(a[k + 2])) pages.push(a[k + 2]); }
    if (pages.length) { out.push({ book, pages: pages.sort((x, y) => x - y), approx: false }); continue; }
    const prev = order[lo - 1] * 4;
    out.push({ book, pages: [a[prev + 2]], approx: true });
  }
  return out;
}

// يدمج نتيجة كتاب في المخزن القائم ويحفظ
export async function saveLocalBook(bookId, result, { get = kvGet, set }) {
  let raw = null;
  try { raw = await get(LOCAL_TAFSIR_KEY); } catch (_) { raw = null; }
  if (!raw || raw.version !== 1) raw = { version: 1, books: {} };
  raw.books[bookId] = { anchors: result.anchors, stats: result.stats, builtAt: new Date().toISOString() };
  await set(LOCAL_TAFSIR_KEY, raw);
}

export function bookReport(name, bookId, result, quran, idx) {
  const s = result.stats, L = [];
  L.push("## " + name + " (" + bookId + ")");
  L.push("صفحات " + s.pages + " | عناوين " + s.titles + " | عناوين سور معروفة " + s.suraTitles + " (سور مختلفة " + s.suras + "/114) | عناوين أرقام آيات " + s.numTitles + " | عناوين بآية " + s.verseTitles);
  L.push("آيات من المتن: قُبلت " + s.bodyAccepted + " ورُفضت " + s.bodyRejected + " (استشهاد بآية خارج التقدّم الرتيب) | مراسٍ " + s.anchors + " | آيات لها صفحة دقيقة " + s.coveredAyas + "/6236 (" + Math.round((s.coveredAyas / 6236) * 100) + "٪)");
  for (const [su, ay] of [[1, 1], [2, 255], [18, 10], [36, 1], [112, 1]]) {
    const id = quran.idOf(su, ay), r = (localTafsirFor(idx, id).find((x) => x.book === bookId)) || null;
    L.push("   تجربة " + su + ":" + ay + " ← " + (r ? "صفحة معرّفها " + r.pages.join("، ") + (r.approx ? " (تقريبي)" : " (دقيق)") : "لا شيء"));
  }
  return L;
}
