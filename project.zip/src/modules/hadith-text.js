// مطابقة متون الأحاديث نصيًا لصفحات الكتب غير المرتبطة في services.db.
// الفكرة: نفهرس نص الصفحات المرتبطة في الكتب العشرة (المنزّلة) بمفتاح الحديث، كبصمات n-gram لكلمات موحَّدة (تُنتقى بالتجزئة)،
// ثم نقيس لكل صفحة جديدة: كم من بصمات كل حديث مفهرس تظهر فيها (احتواء). النتيجة "مرجّح" بنسبة، لا معرّف رسمي.
// البصمات الشائعة (أكثر من maxOwners حديثًا) تُحذف. ما لا تغطيه: الفروق الكبيرة في اللفظ بين الروايات، والأحاديث غير الموجودة في الكتب المنزّلة.
import { kvGet } from "../database/idb.js";
import { normalizeArabic } from "./arabic.js";

export const TEXT_INDEX_KEY = "hadith-text-index";
export const PARAMS = { n: 4, mod: 3, maxOwners: 20, minShared: 4, minContain: 0.4, top: 4 };
const MULT = 2097152; // 2^21: المفتاح < 2^21 وhash < 2^32 فالمجموع < 2^53

export function words(html) {
  const t = String(html || "").replace(/<[^>]*>/g, " ").replace(/\(\s*¬?\s*[٠-٩0-9]{1,3}\s*\)/g, " ");
  const n = normalizeArabic(t).replace(/[^\u0621-\u064A ]/g, " ").replace(/\s+/g, " ").trim();
  return n ? n.split(" ") : [];
}
function wordHash(w) { let h = 0x811c9dc5; for (let i = 0; i < w.length; i++) { h ^= w.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }

// مجموعة البصمات المنتقاة (أعداد بلا إشارة) لنص
export function shingles(text, { n = PARAMS.n, mod = PARAMS.mod } = {}) {
  const w = words(text).map(wordHash), out = new Set();
  for (let i = 0; i + n <= w.length; i++) {
    let h = 0x9e3779b9;
    for (let j = 0; j < n; j++) h = Math.imul(h ^ w[i + j], 16777619);
    h >>>= 0;
    if (h % mod === 0) out.add(h);
  }
  return out;
}

// narrs: [{ key, hashes: Uint32Array|Set }] — رواية واحدة لكل (كتاب، صفحة). الفهرس يحفظ كل رواية على حدة
// (فلا يُخفَّف التطابق بدمج ألفاظ كتب مختلفة)، ويُجمَّع الناتج بحسب المفتاح عند السؤال.
export function buildIndex(narrs, { mod = PARAMS.mod, n = PARAMS.n, maxOwners = PARAMS.maxOwners } = {}) {
  const ordered = narrs.map((r, i) => ({ key: r.key, hs: r.hashes, i })).filter((r) => r.key >= 0 && r.key < MULT).sort((a, b) => a.key - b.key || a.i - b.i);
  const cnt = new Map(), last = new Map();
  for (const r of ordered) for (const h of r.hs) { if (last.get(h) !== r.key) { last.set(h, r.key); cnt.set(h, (cnt.get(h) || 0) + 1); } }
  const enc = [], narrKey = [], narrCount = []; let dropped = 0;
  for (const r of ordered) {
    const id = narrKey.length; let c = 0;
    for (const h of r.hs) { if (cnt.get(h) > maxOwners) { dropped++; continue; } enc.push(h * MULT + id); c++; }
    narrKey.push(r.key); narrCount.push(c);
  }
  const arr = Float64Array.from(enc).sort();
  const hashes = new Uint32Array(arr.length), owners = new Int32Array(arr.length);
  for (let i = 0; i < arr.length; i++) { const h = Math.floor(arr[i] / MULT); hashes[i] = h; owners[i] = arr[i] - h * MULT; }
  return { version: 2, n, mod, hashes, owners, narrKey: Int32Array.from(narrKey), narrCount: Int32Array.from(narrCount), keys: new Set(narrKey).size, droppedCommon: dropped };
}

export function prepareIndex(raw) { return raw && raw.version === 2 ? raw : null; }

function lowerBound(a, x) { let lo = 0, hi = a.length; while (lo < hi) { const m = (lo + hi) >> 1; if (a[m] < x) lo = m + 1; else hi = m; } return lo; }

// hashSet: بصمات الصفحة. النسبة = الأكبر من: حصة الرواية المفهرسة الظاهرة في الصفحة، وحصة الصفحة الظاهرة في الرواية.
// يعيد [{ key, shared, total, score }] لكل مفتاح بأفضل رواياته، مرتبة بالنسبة ثم عدد المشترك
export function matchHashes(idx, hashSet, opts = {}) {
  const { minShared, minContain, top } = { ...PARAMS, ...opts };
  const pageTotal = hashSet.size || hashSet.length || 0;
  if (!pageTotal) return [];
  const shared = new Map();
  for (const h of hashSet) {
    for (let i = lowerBound(idx.hashes, h); i < idx.hashes.length && idx.hashes[i] === h; i++) shared.set(idx.owners[i], (shared.get(idx.owners[i]) || 0) + 1);
  }
  const best = new Map();
  for (const [nid, sh] of shared) {
    const total = idx.narrCount[nid];
    if (!total || sh < minShared) continue;
    const score = Math.max(sh / total, sh / pageTotal);
    if (score < minContain) continue;
    const key = idx.narrKey[nid], cur = best.get(key);
    if (!cur || score > cur.score || (score === cur.score && sh > cur.shared)) best.set(key, { key, shared: sh, total, score });
  }
  return [...best.values()].sort((a, b) => b.score - a.score || b.shared - a.shared).slice(0, top);
}

export const matchPage = (idx, body, opts) => matchHashes(idx, shingles(body, { n: idx.n, mod: idx.mod }), opts);

let cache;
export const resetTextIndexCache = () => { cache = undefined; };
export async function loadTextIndex(get = kvGet) {
  if (cache !== undefined) return cache;
  let raw = null;
  try { raw = await get(TEXT_INDEX_KEY); } catch (_) { raw = null; }
  cache = prepareIndex(raw);
  return cache;
}

// عرض المرشحين: لكل حديث مواضعه في الكتب المرتبطة (دون الصفحة الحالية)
export function buildMatchView(cands, links, bookId, pageId) {
  return cands.map((c) => {
    const groups = [], by = new Map(), seen = new Set();
    for (const [b, p] of (links && links.byKey.get(c.key)) || []) {
      if (b === bookId && p === pageId) continue;
      const k = b + ":" + p; if (seen.has(k)) continue; seen.add(k);
      let g = by.get(b); if (!g) { g = { book: b, pages: [] }; by.set(b, g); groups.push(g); }
      g.pages.push(p);
    }
    return { key: c.key, pct: Math.round(c.score * 100), shared: c.shared, groups };
  });
}

// تقييم ذاتي بالأرضية الحقيقية: لكل كتاب مرتبط X نبني فهرسًا من بقية الكتب ونسأله عن صفحات X (التي نعرف مفاتيحها).
// تنبيه: هذا يقيس مطابقة «الحديث نفسه بين مصنِّفين مختلفين» (ألفاظ مختلفة)، لا مطابقة طبعتين لكتاب واحد.
// books: [{ book, narrs: [{ key, hashes }], pages: [{ keys:[k], hashes:Set }] }]
export function evaluate(books, grid = [[4, 0.4], [6, 0.4], [6, 0.5], [8, 0.5]]) {
  const rows = [];
  for (const X of books) {
    const others = []; for (const o of books) if (o !== X) others.push(...o.narrs);
    if (!others.length) continue;
    const idx = buildIndex(others);
    const have = new Set(idx.narrKey);
    const pages = X.pages.filter((p) => p.keys.length === 1 && have.has(p.keys[0]));
    for (const [ms, mc] of grid) {
      let any = 0, top1 = 0, cands = 0, wrongOnly = 0;
      for (const p of pages) {
        const res = matchHashes(idx, p.hashes, { minShared: ms, minContain: mc });
        cands += res.length;
        const i = res.findIndex((r) => r.key === p.keys[0]);
        if (i >= 0) { any++; if (i === 0) top1++; } else if (res.length) wrongOnly++;
      }
      rows.push({ book: X.book, ms, mc, pages: pages.length, any, top1, cands, wrongOnly });
    }
  }
  return rows;
}
