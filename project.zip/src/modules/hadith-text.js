// مطابقة متون الأحاديث نصيًا لصفحات الكتب غير المرتبطة في services.db.
// الفكرة: نفهرس نص الصفحات المرتبطة في الكتب العشرة (المنزّلة) بمفتاح الحديث، كبصمات n-gram لكلمات موحَّدة (تُنتقى بالتجزئة)،
// ثم نقيس لكل صفحة جديدة: كم من بصمات كل حديث مفهرس تظهر فيها (احتواء). النتيجة "مرجّح" بنسبة، لا معرّف رسمي.
// البصمات الشائعة (أكثر من maxOwners حديثًا) تُحذف. ما لا تغطيه: الفروق الكبيرة في اللفظ بين الروايات، والأحاديث غير الموجودة في الكتب المنزّلة.
import { kvGet } from "../database/idb.js";
import { normalizeArabic } from "./arabic.js";

export const TEXT_INDEX_KEY = "hadith-text-index";
export const PARAMS = { n: 4, mod: 3, maxOwners: 20, minShared: 4, minContain: 0.4, top: 4 };
const MULT = 2097152; // 2^21: المفتاح < 2^21 وhash < 2^32 فالمجموع < 2^53

export function words(html) {
  const t = String(html || "").replace(/<[^>]*>/g, " ").replace(/\(\s*¬?\s*[٠-٩0-9]{1,3}\s*\)/g, " ");
  const n = normalizeArabic(t).replace(/[^\u0621-\u064A ]/g, " ").replace(/\s+/g, " ").trim();
  return n ? n.split(" ") : [];
}
function wordHash(w) { let h = 0x811c9dc5; for (let i = 0; i < w.length; i++) { h ^= w.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }

// مجموعة البصمات المنتقاة (أعداد بلا إشارة) لنص
export function shingles(text, { n = PARAMS.n, mod = PARAMS.mod } = {}) {
  const w = words(text).map(wordHash), out = new Set();
  for (let i = 0; i + n <= w.length; i++) {
    let h = 0x9e3779b9;
    for (let j = 0; j < n; j++) h = Math.imul(h ^ w[i + j], 16777619);
    h >>>= 0;
    if (h % mod === 0) out.add(h);
  }
  return out;
}

// maps: Map<keyId, Set<hash>> مدموجة من كل الكتب → فهرس مرتب
export function buildIndex(keyHashes, { mod = PARAMS.mod, n = PARAMS.n, maxOwners = PARAMS.maxOwners } = {}) {
  const owners = new Map();
  for (const [key, set] of keyHashes) for (const h of set) owners.set(h, (owners.get(h) || 0) + 1);
  const enc = []; const counts = new Map(); let dropped = 0;
  for (const [key, set] of keyHashes) {
    if (!(key >= 0 && key < MULT)) continue;
    let c = 0;
    for (const h of set) { if (owners.get(h) > maxOwners) { dropped++; continue; } enc.push(h * MULT + key); c++; }
    if (c) counts.set(key, c);
  }
  const arr = Float64Array.from(enc).sort();
  const hashes = new Uint32Array(arr.length), own = new Int32Array(arr.length);
  for (let i = 0; i < arr.length; i++) { const h = Math.floor(arr[i] / MULT); hashes[i] = h; own[i] = arr[i] - h * MULT; }
  const keyIds = Int32Array.from(counts.keys()), keyCounts = Int32Array.from(counts.values());
  return { version: 1, n, mod, hashes, owners: own, keyIds, keyCounts, droppedCommon: dropped };
}

export function prepareIndex(raw) {
  if (!raw || raw.version !== 1) return null;
  const counts = new Map();
  for (let i = 0; i < raw.keyIds.length; i++) counts.set(raw.keyIds[i], raw.keyCounts[i]);
  return { ...raw, counts };
}

function lowerBound(a, x) { let lo = 0, hi = a.length; while (lo < hi) { const m = (lo + hi) >> 1; if (a[m] < x) lo = m + 1; else hi = m; } return lo; }

// hashSet: بصمات الصفحة. يعيد [{ key, shared, total, score }] مرتبة بالنسبة ثم عدد المشترك
export function matchHashes(idx, hashSet, opts = {}) {
  const { minShared, minContain, top } = { ...PARAMS, ...opts };
  const shared = new Map();
  for (const h of hashSet) {
    for (let i = lowerBound(idx.hashes, h); i < idx.hashes.length && idx.hashes[i] === h; i++) shared.set(idx.owners[i], (shared.get(idx.owners[i]) || 0) + 1);
  }
  const out = [];
  for (const [key, s] of shared) {
    const total = idx.counts.get(key) || 0;
    if (!total || s < minShared) continue;
    const score = s / total;
    if (score >= minContain) out.push({ key, shared: s, total, score });
  }
  return out.sort((a, b) => b.score - a.score || b.shared - a.shared).slice(0, top);
}

export const matchPage = (idx, body, opts) => matchHashes(idx, shingles(body, { n: idx.n, mod: idx.mod }), opts);

let cache;
export const resetTextIndexCache = () => { cache = undefined; };
export async function loadTextIndex(get = kvGet) {
  if (cache !== undefined) return cache;
  let raw = null;
  try { raw = await get(TEXT_INDEX_KEY); } catch (_) { raw = null; }
  cache = prepareIndex(raw);
  return cache;
}

// عرض المرشحين: لكل حديث مواضعه في الكتب المرتبطة (دون الصفحة الحالية)
export function buildMatchView(cands, links, bookId, pageId) {
  return cands.map((c) => {
    const groups = [], by = new Map(), seen = new Set();
    for (const [b, p] of (links && links.byKey.get(c.key)) || []) {
      if (b === bookId && p === pageId) continue;
      const k = b + ":" + p; if (seen.has(k)) continue; seen.add(k);
      let g = by.get(b); if (!g) { g = { book: b, pages: [] }; by.set(b, g); groups.push(g); }
      g.pages.push(p);
    }
    return { key: c.key, pct: Math.round(c.score * 100), shared: c.shared, groups };
  });
}

// تقييم ذاتي بالأرضية الحقيقية: لكل كتاب مرتبط X نبني فهرسًا من بقية الكتب ونسأله عن صفحات X (التي نعرف مفاتيحها).
// books: [{ book, keyHashes: Map, pages: [{ keys:[k], hashes:Set }] }]
export function evaluate(books, grid = [[4, 0.3], [4, 0.4], [4, 0.5], [6, 0.5], [6, 0.6]]) {
  const rows = [];
  for (const X of books) {
    const merged = new Map();
    for (const o of books) { if (o === X) continue; for (const [k, s] of o.keyHashes) { let m = merged.get(k); if (!m) { m = new Set(); merged.set(k, m); } for (const h of s) m.add(h); } }
    if (!merged.size) continue;
    const idx = prepareIndex(buildIndex(merged));
    const pages = X.pages.filter((p) => p.keys.length === 1 && idx.counts.has(p.keys[0]));
    for (const [ms, mc] of grid) {
      let any = 0, top1 = 0, cands = 0, wrongOnly = 0;
      for (const p of pages) {
        const res = matchHashes(idx, p.hashes, { minShared: ms, minContain: mc });
        cands += res.length;
        const i = res.findIndex((r) => r.key === p.keys[0]);
        if (i >= 0) { any++; if (i === 0) top1++; } else if (res.length) wrongOnly++;
      }
      rows.push({ book: X.book, ms, mc, pages: pages.length, any, top1, cands, wrongOnly });
    }
  }
  return rows;
}
