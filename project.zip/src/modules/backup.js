// نسخة احتياطية لبيانات المستخدم فقط (ملاحظات، تقدّم القراءة، إحصاءات، مفضلات، تقييمات، إعدادات)
// كنصّ JSON يُنسخ ويُلصق. لا تشمل الكتب المنزّلة (تُسجَّل أسماؤها للتنزيل من جديد) ولا الفهارس المشتقة (تُعاد بنيتها بالأدوات).
import { kvGet, kvSet, kvKeys } from "../database/idb.js";

const ALLOWED = /^(settings|favorites|ratings|recentBooks|lastBook|bigbooks|notes:index|notes:[^:]+|progress:[^:]+|stats:(days|totals)|readpages:[^:]+)$/;
export const isUserKey = (k) => typeof k === "string" && k.length < 80 && ALLOWED.test(k);
const MAX_BYTES = 20 * 1024 * 1024;
export const FORMAT = "islamic-library-backup";

export async function collectBackup({ keys = kvKeys, get = kvGet, appVersion = "", downloaded = [], now = () => new Date().toISOString() } = {}) {
  const data = {};
  for (const k of await keys()) {
    if (!isUserKey(k)) continue;
    const v = await get(k);
    if (v !== null && v !== undefined) data[k] = v;
  }
  return { format: FORMAT, version: 1, appVersion, createdAt: now(), downloaded: downloaded.map((d) => ({ id: d.id, name: d.name || "" })), data };
}

export function parseBackup(text) {
  if (typeof text !== "string" || !text.trim()) return { ok: false, error: "empty" };
  if (text.length > MAX_BYTES) return { ok: false, error: "too_big" };
  let o;
  try { o = JSON.parse(text.trim()); } catch (_) { return { ok: false, error: "not_json" }; }
  if (!o || o.format !== FORMAT || o.version !== 1 || !o.data || typeof o.data !== "object" || Array.isArray(o.data)) return { ok: false, error: "not_backup" };
  return { ok: true, backup: o };
}

const byId = (a, b, field = "id") => { const seen = new Set((a || []).map((x) => x && x[field])); return [...(a || []), ...(b || []).filter((x) => x && !seen.has(x[field]))]; };

// يدمج: الملاحظات والمفضلات (اتحاد بالمعرّف)، وبقية المفاتيح تُستبدل بما في النسخة
export async function restoreBackup(text, { get = kvGet, set = kvSet } = {}) {
  const p = parseBackup(text);
  if (!p.ok) return { ok: false, error: p.error };
  let restored = 0, skipped = 0;
  for (const [k, v] of Object.entries(p.backup.data)) {
    if (!isUserKey(k) || v === null || v === undefined || typeof v === "function") { skipped++; continue; }
    let next = v;
    try {
      const cur = await get(k);
      if (/^notes:[^:]+$/.test(k) && k !== "notes:index" && Array.isArray(v) && Array.isArray(cur)) next = byId(cur, v);
      else if (k === "notes:index" && Array.isArray(v) && Array.isArray(cur)) next = [...new Set([...cur, ...v])];
      else if (k === "favorites" && Array.isArray(v) && Array.isArray(cur)) next = byId(cur, v);
      await set(k, next); restored++;
    } catch (_) { skipped++; }
  }
  return { ok: true, restored, skipped, createdAt: p.backup.createdAt || "", downloaded: Array.isArray(p.backup.downloaded) ? p.backup.downloaded.filter((d) => d && Number.isInteger(d.id)) : [] };
}
