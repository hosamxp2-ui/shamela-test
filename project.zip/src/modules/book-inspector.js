// فحص بنية قاعدة كتاب واحد صغير: يجلبه بـ Range، يتحقق، يفك الضغط، ويعرض جداوله.
// الغرض: معرفة تنسيق الصفحات والهوامش قبل بناء القارئ. لا يحفظ شيئًا.
import { LIMITS } from "../config.js";
import { source as defaultSource } from "../services/shamela-nas-source.js";
import { openDatabase as defaultOpen } from "../services/sqlite.js";
import { ConnectorError } from "../services/data-connector.js";
import { t } from "../strings.js";

const cut = (v, n = 90) => {
  if (v == null) return "NULL";
  if (v instanceof Uint8Array) return "<blob " + v.length + ">";
  const s = String(v).replace(/\s+/g, " ");
  return s.length > n ? s.slice(0, n) + "…" : s;
};

export async function inspectBook(catalog, id, { source = defaultSource, open = defaultOpen, onProgress = () => {} } = {}) {
  const book = catalog.getBook(id);
  const entry = catalog.fileInfo(id);
  if (!book || !entry) throw new ConnectorError("NOT_AVAILABLE", t("err.notAvailable"));
  if (entry.length > LIMITS.inspectMaxBytes) {
    throw new ConnectorError("TOO_BIG", t("err.tooBig", {
      mb: (entry.length / 1048576).toFixed(1), max: LIMITS.inspectMaxBytes / 1048576
    }));
  }

  onProgress(t("tools.inspectStart", { id }));
  const manifest = await source.manifest();
  const bytes = await source.bookBytes(manifest, entry);
  const db = await open(bytes);
  const lines = [];
  try {
    lines.push("كتاب " + id + ": " + book.name);
    lines.push("مضغوط " + entry.length + " بايت | بعد الفك " + bytes.length + " بايت | صفحات الفهرس " + entry.pages);
    lines.push("");
    const tables = db.all("SELECT name, sql FROM sqlite_master WHERE type='table' ORDER BY name");
    for (const tb of tables) {
      const q = '"' + String(tb.name).replace(/"/g, '""') + '"';
      const n = db.all("SELECT COUNT(*) AS n FROM " + q)[0].n;
      lines.push("## " + tb.name + " (" + n + " صف)");
      lines.push(String(tb.sql || "").replace(/\s+/g, " "));
      for (const row of db.all("SELECT * FROM " + q + " LIMIT 2")) {
        lines.push("  - " + Object.entries(row).map(([k, v]) => k + "=" + cut(v)).join(" | "));
      }
      lines.push("");
    }
  } finally {
    db.close();
  }
  return lines;
}
