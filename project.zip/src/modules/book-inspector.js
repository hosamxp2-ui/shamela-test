// فحص بنية قاعدة كتاب واحد صغير: يجلبه بـ Range، يتحقق، يفك الضغط، ويعرض جداوله.
// الغرض: معرفة تنسيق الصفحات والهوامش قبل بناء القارئ. لا يحفظ شيئًا.
import { LIMITS } from "../config.js";
import { source as defaultSource } from "../services/shamela-nas-source.js";
import { openDatabase as defaultOpen } from "../services/sqlite.js";
import { ConnectorError } from "../services/data-connector.js";
import { t } from "../strings.js";

const cut = (v, n = 90) => {
  if (v == null) return "NULL";
  if (v instanceof Uint8Array) return "<blob " + v.length + ">";
  const s = String(v).replace(/\s+/g, " ");
  return s.length > n ? s.slice(0, n) + "…" : s;
};

export async function inspectBook(catalog, id, { source = defaultSource, open = defaultOpen, onProgress = () => {} } = {}) {
  const book = catalog.getBook(id);
  const entry = catalog.fileInfo(id);
  if (!book || !entry) throw new ConnectorError("NOT_AVAILABLE", t("err.notAvailable"));
  if (entry.length > LIMITS.inspectMaxBytes) {
    throw new ConnectorError("TOO_BIG", t("err.tooBig", {
      mb: (entry.length / 1048576).toFixed(1), max: LIMITS.inspectMaxBytes / 1048576
    }));
  }

  onProgress(t("tools.inspectStart", { id }));
  const manifest = await source.manifest();
  const bytes = await source.bookBytes(manifest, entry);
  const db = await open(bytes);
  const lines = [];
  try {
    lines.push("كتاب " + id + ": " + book.name);
    lines.push("مضغوط " + entry.length + " بايت | بعد الفك " + bytes.length + " بايت | صفحات الفهرس " + entry.pages);
    lines.push("");
    const objects = db.all("SELECT type, name FROM sqlite_master ORDER BY type, name");
    lines.push("الكائنات: " + objects.map((o) => o.type + ":" + o.name).join(", "));
    lines.push("");
    const tables = db.all("SELECT name, sql FROM sqlite_master WHERE type='table' ORDER BY name");
    for (const tb of tables) {
      const virtual = /^\s*CREATE\s+VIRTUAL\s+TABLE/i.test(String(tb.sql || ""));
      lines.push("## " + tb.name + (virtual ? " [جدول افتراضي]" : ""));
      lines.push(String(tb.sql || "").replace(/\s+/g, " "));
      if (virtual) {
        // الجداول الافتراضية (مثل FTS5) تحتاج وحدة قد لا تتوفر في sql.js؛ نعرض تعريفها فقط.
        lines.push("  (لم يُقرأ محتواه: يحتاج وحدة SQLite خاصة)");
        lines.push("");
        continue;
      }
      try {
        const q = '"' + String(tb.name).replace(/"/g, '""') + '"';
        const n = db.all("SELECT COUNT(*) AS n FROM " + q)[0].n;
        lines.push("  عدد الصفوف: " + n);
        for (const row of db.all("SELECT * FROM " + q + " LIMIT 2")) {
          lines.push("  - " + Object.entries(row).map(([k, v]) => k + "=" + cut(v)).join(" | "));
        }
      } catch (e) {
        lines.push("  تعذّرت القراءة: " + (e && e.message ? e.message : e));
      }
      lines.push("");
    }
    deepSample(db, lines);
  } finally {
    db.close();
  }
  return lines;
}

const inc = (map, key) => map.set(key, (map.get(key) || 0) + 1);
const top = (map, n) => [...map.entries()].sort((a, b) => b[1] - a[1]).slice(0, n).map(([k, v]) => k + "×" + v).join(", ");
const MARKER = /\(\s*[٠-٩0-9]+\s*\)|\[\s*[٠-٩0-9]+\s*\]|data-type="(?:fn|footnote|note)[^"]*"/;

// عينات موجّهة لمعرفة تنسيق الصفحات والهوامش والخدمات (للقارئ في المرحلة 6)
function deepSample(db, lines) {
  try {
    if (!db.all("SELECT name FROM sqlite_master WHERE type='table' AND name='page'").length) return;
    lines.push("=== عينات القراءة ===");
    try { for (const r of db.all("SELECT key, value FROM meta")) lines.push("meta: " + r.key + " = " + cut(r.value, 160)); } catch (_) { /* لا meta */ }
    const pages = db.all("SELECT id, part, page, number, body, foot, services FROM page");
    const tags = new Map(), attrs = new Map();
    let withFoot = 0, withServices = 0, numberNull = 0;
    for (const p of pages) {
      if (p.foot) withFoot++;
      if (p.services) withServices++;
      if (p.number == null) numberNull++;
      for (const col of [p.body, p.foot]) {
        if (!col) continue;
        for (const m of String(col).matchAll(/<([a-zA-Z][\w-]*)([^>]*)>/g)) {
          inc(tags, m[1]);
          for (const a of m[2].matchAll(/([\w-]+)\s*=\s*"?([^"\s>]*)/g)) inc(attrs, a[1] === "data-type" || a[1] === "class" ? a[1] + "=" + a[2] : a[1]);
        }
      }
    }
    lines.push("صفحات: " + pages.length + " | بها هوامش: " + withFoot + " | بها services: " + withServices + " | number فارغ: " + numberNull);
    lines.push("أوسمة HTML: " + (top(tags, 15) || "لا يوجد"));
    lines.push("خصائص: " + (top(attrs, 25) || "لا يوجد"));
    lines.push("قيم part: " + db.all("SELECT DISTINCT part FROM page LIMIT 8").map((r) => cut(r.part, 30)).join(" | "));
    for (const p of pages.filter((x) => x.foot).slice(0, 2)) {
      const i = String(p.body).search(MARKER);
      lines.push("صفحة " + p.id + " (page=" + p.page + ") هامش:");
      lines.push("  body[بداية]: " + cut(p.body, 260));
      if (i >= 0) lines.push("  body[حول العلامة]: " + cut(String(p.body).slice(Math.max(0, i - 60), i + 120), 200));
      lines.push("  foot: " + cut(p.foot, 400));
    }
    for (const p of pages.filter((x) => x.services).slice(0, 2)) {
      lines.push("صفحة " + p.id + " services: " + cut(p.services, 400));
    }
    lines.push("-- العناوين:");
    const titles = db.all("SELECT id, page, parent, text FROM title ORDER BY id LIMIT 12");
    for (const tt of titles) lines.push("  " + tt.id + " | page=" + tt.page + " | parent=" + tt.parent + " | " + cut(tt.text, 70));
    for (const tt of titles.slice(0, 3)) {
      const row = db.all("SELECT id, part, page, number FROM page WHERE id=" + Number(tt.page))[0];
      lines.push("  عنوان " + tt.id + " -> page.id=" + tt.page + (row ? " (part=" + cut(row.part, 20) + ", page=" + row.page + ", number=" + row.number + ")" : " غير موجود"));
    }
    lines.push("");
  } catch (e) {
    lines.push("تعذّرت العينات: " + (e && e.message ? e.message : e));
  }
}
