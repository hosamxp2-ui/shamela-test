// إحصاء أحجام الكتب (بعد الفك) لتقدير أثر حد القارئ (100MB تلقائيًا، 220MB بالقوة): كم كتابًا يتجاوزه؟
const MB = 1048576;
export const BUCKETS = [[0, 25, "حتى 25"], [25, 50, "25 – 50"], [50, 100, "50 – 100"], [100, 220, "100 – 220 (يُفتح بالقوة إن تحمّل الهاتف)"], [220, Infinity, "فوق 220 (لا يُفتح)"]];

export function sizeStats(catalog, { top = 12 } = {}) {
  const rows = [];
  for (const b of catalog.searchBooks({ sort: "name", dir: "asc" })) {
    const f = catalog.fileInfo(b.id);
    if (f && Number.isFinite(f.size)) rows.push({ id: b.id, name: b.name, mb: f.size / MB, pages: f.pages });
  }
  const L = ["كتب لها ملف: " + rows.length, ""];
  for (const [lo, hi, label] of BUCKETS) {
    const n = rows.filter((r) => r.mb >= lo && r.mb < hi).length;
    L.push(label + " ميغابايت: " + n + " كتابًا (" + (rows.length ? ((n / rows.length) * 100).toFixed(1) : "0") + "٪)");
  }
  L.push("", "أكبر " + top + " كتابًا:");
  for (const r of [...rows].sort((a, b) => b.mb - a.mb).slice(0, top)) L.push("- " + r.name + " (" + r.id + "): " + Math.round(r.mb) + " MB" + (r.pages ? "، " + r.pages + " صفحة" : ""));
  return L;
}
