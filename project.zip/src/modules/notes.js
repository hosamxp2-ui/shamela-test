// الإشارات المرجعية والملاحظات (محلية). لكل كتاب سجل واحد في التخزين، وفهرس بالكتب التي فيها شيء.
import { kvGet, kvSet } from "../database/idb.js";

const MAX_NOTE = 2000;
const MAX_QUOTE = 600;

const newId = () =>
  (globalThis.crypto && globalThis.crypto.randomUUID ? globalThis.crypto.randomUUID() : "n" + Date.now().toString(36) + Math.random().toString(36).slice(2, 8));

const clip = (s, n) => String(s == null ? "" : s).trim().slice(0, n);

export function createNotesStore({ get = kvGet, set = kvSet, now = () => Date.now(), id = newId } = {}) {
  const cache = new Map();

  async function persist(bookId) {
    const items = cache.get(bookId) || [];
    try {
      await set("notes:" + bookId, items);
      const idx = (await get("notes:index")) || [];
      const has = idx.includes(bookId);
      if (items.length && !has) await set("notes:index", [...idx, bookId]);
      if (!items.length && has) await set("notes:index", idx.filter((b) => b !== bookId));
      return true;
    } catch (_) { return false; }
  }

  const sorted = (items) => items.slice().sort((a, b) => a.pageIndex - b.pageIndex || a.createdAt - b.createdAt);

  const api = {
    async load(bookId) {
      let items = [];
      try { const v = await get("notes:" + bookId); if (Array.isArray(v)) items = v.filter((x) => x && typeof x.id === "string" && Number.isInteger(x.pageIndex)); } catch (_) { /* نبدأ فارغين */ }
      cache.set(bookId, items);
      return sorted(items);
    },
    list: (bookId) => sorted(cache.get(bookId) || []),

    // للعرض السريع في الصفحة الحالية (من الذاكرة)
    pageMarks(bookId, pageIndex) {
      const items = (cache.get(bookId) || []).filter((x) => x.pageIndex === pageIndex);
      return { bookmark: items.some((x) => x.kind === "bookmark"), notes: items.filter((x) => x.kind === "note").length };
    },

    // تظليل نص محدد (بلا نص ملاحظة): يُحفظ كعنصر kind="highlight" مع المقتطف
    async addHighlight(bookId, { pageIndex, pageId, label, quote }) {
      const q = clip(quote, MAX_QUOTE);
      if (!q) return null;
      const items = cache.get(bookId) || [];
      if (items.some((x) => x.kind === "highlight" && x.pageIndex === pageIndex && x.quote === q)) return items.find((x) => x.kind === "highlight" && x.pageIndex === pageIndex && x.quote === q);
      const item = { id: id(), kind: "highlight", pageIndex, pageId, label: clip(label, 80), text: "", quote: q, createdAt: now(), updatedAt: now() };
      cache.set(bookId, [...items, item]);
      await persist(bookId);
      return item;
    },
    highlightsOn(bookId, pageIndex) { return (cache.get(bookId) || []).filter((x) => x.kind === "highlight" && x.pageIndex === pageIndex); },

    async toggleBookmark(bookId, { pageIndex, pageId, label }) {
      const items = cache.get(bookId) || [];
      const existing = items.find((x) => x.kind === "bookmark" && x.pageIndex === pageIndex);
      let on;
      if (existing) { cache.set(bookId, items.filter((x) => x !== existing)); on = false; }
      else { cache.set(bookId, [...items, { id: id(), kind: "bookmark", pageIndex, pageId, label: clip(label, 80), text: "", quote: "", createdAt: now(), updatedAt: now() }]); on = true; }
      await persist(bookId);
      return { on };
    },

    async addNote(bookId, { pageIndex, pageId, label, text, quote }) {
      const body = clip(text, MAX_NOTE), q = clip(quote, MAX_QUOTE);
      if (!body && !q) return null;
      const item = { id: id(), kind: "note", pageIndex, pageId, label: clip(label, 80), text: body, quote: q, createdAt: now(), updatedAt: now() };
      cache.set(bookId, [...(cache.get(bookId) || []), item]);
      await persist(bookId);
      return item;
    },

    async updateNote(bookId, noteId, text) {
      const items = cache.get(bookId) || [];
      const it = items.find((x) => x.id === noteId && x.kind === "note");
      if (!it) return false;
      const body = clip(text, MAX_NOTE);
      if (!body && !it.quote) return false;
      it.text = body;
      it.updatedAt = now();
      await persist(bookId);
      return true;
    },

    async remove(bookId, noteId) {
      const items = cache.get(bookId) || [];
      if (!items.some((x) => x.id === noteId)) return false;
      cache.set(bookId, items.filter((x) => x.id !== noteId));
      await persist(bookId);
      return true;
    },

    async allBooks() {
      try { const idx = await get("notes:index"); return Array.isArray(idx) ? idx : []; } catch (_) { return []; }
    }
  };
  return api;
}
