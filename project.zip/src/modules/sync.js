// تنزيل الفهرس وحفظه محليًا وفحص وجود تحديث. لا يعمل شيء منها تلقائيًا إلا فحص التحديث الخفيف.
import { kvGet, kvSet } from "../database/idb.js";
import { source as defaultSource } from "../services/shamela-nas-source.js";
import { openDatabase as defaultOpen } from "../services/sqlite.js";
import { buildRaw } from "./catalog.js";
import { t } from "../strings.js";

export function loadSaved() {
  return kvGet("catalog");
}

export async function downloadCatalog(onProgress = () => {}, deps = {}) {
  const src = deps.source || defaultSource;
  const open = deps.open || defaultOpen;
  const save = deps.save || kvSet;

  onProgress(t("progress.manifest"));
  const manifest = await src.manifest();

  onProgress(t("progress.master"));
  const masterBytes = await src.master(manifest);

  onProgress(t("progress.index"));
  const index = await src.index(manifest);

  onProgress(t("progress.parse"));
  const db = await open(masterBytes);
  let raw;
  try {
    raw = buildRaw(db, index, manifest);
  } finally {
    db.close();
  }

  onProgress(t("progress.save"));
  await save("catalog", raw);
  onProgress(t("progress.done"));
  return raw;
}

export async function checkForUpdate(raw, deps = {}) {
  const src = deps.source || defaultSource;
  const manifest = await src.manifest();
  const remote = manifest && manifest.data ? manifest.data.version : "";
  return { available: !!remote && remote !== raw.meta.dataVersion, version: remote };
}
