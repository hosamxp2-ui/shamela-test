// يكشف الخطوط العربية المتاحة فعلًا (التي نُسخت أثناء البناء). يُخزَّن الناتج بعد أول فحص.
import { FONTS } from "./settings.js";

let cached = null;
export function detectFonts() {
  if (!cached) {
    cached = (async () => {
      const avail = {};
      for (const [key, f] of Object.entries(FONTS)) {
        if (!f.load) { avail[key] = true; continue; }
        try { avail[key] = (await document.fonts.load('16px "' + f.load + '"', "ابت")).length > 0; } catch (_) { avail[key] = false; }
      }
      return avail;
    })();
  }
  return cached;
}
