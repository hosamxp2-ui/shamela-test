// فحص قاعدتي services وtashkeel دون تنزيلهما كاملتين: نجلب بداية الملف المضغوط (Range)،
// نفكّ ما أمكن، ونقرأ جدول sqlite_master (التعريفات) وعينات من الجداول التي وقعت في هذا الجزء.
import { LIMITS } from "../config.js";
import { source as defaultSource } from "../services/shamela-nas-source.js";
import { gunzipPartial } from "../services/data-connector.js";
import { openDatabase as defaultOpen } from "../services/sqlite.js";

const cut = (v, n = 90) => {
  if (v == null) return "NULL";
  if (v instanceof Uint8Array) return "<blob " + v.length + ">";
  const s = String(v).replace(/\s+/g, " ");
  return s.length > n ? s.slice(0, n) + "…" : s;
};

// قاعدة SQLite مقطوعة تُعدّ تالفة لأن حجمها أقل من المعلن في الترويسة. نقصّها لصفحات كاملة ونصفّر حقل الحجم
// في الترويسة (بايتات 28-31) فيعتمد SQLite على حجم الملف الفعلي، فتُقرأ الجداول الواقعة في هذا الجزء.
export function trimToPages(raw) {
  const ps = ((raw[16] << 8) | raw[17]) || 65536;
  const declared = new DataView(raw.buffer, raw.byteOffset, raw.byteLength).getUint32(28);
  const pages = Math.floor(raw.length / ps);
  const bytes = raw.slice(0, pages * ps);
  bytes[28] = bytes[29] = bytes[30] = bytes[31] = 0;
  return { bytes, pageSize: ps, pages, declared };
}

export async function inspectDbPrefix(which, { source = defaultSource, open = defaultOpen, onProgress = () => {}, prefixBytes = LIMITS.dbPrefixBytes } = {}) {
  onProgress("قراءة بيانات المصدر…");
  const manifest = await source.manifest();
  const meta = manifest.data[which];
  const lines = [];
  lines.push("قاعدة " + which + ": المضغوط " + meta.size + " بايت، بعد الفك " + (meta.raw_size || "؟") + " بايت");
  onProgress("جلب بداية الملف (" + Math.round(prefixBytes / 1048576) + " ميغابايت)…");
  const gz = await source.dbPrefix(manifest, which, prefixBytes);
  onProgress("فك الضغط الجزئي…");
  const raw = await gunzipPartial(gz);
  lines.push("جُلب " + gz.length + " بايت مضغوطة وفُكّ منها " + raw.length + " بايت (جزء من الملف، ولم يُتحقق من SHA256 لأنه غير كامل)");
  if (raw.length < 100) { lines.push("لم يمكن فك البيانات."); return lines; }
  const hdr = String.fromCharCode(...raw.slice(0, 15));
  lines.push("ترويسة الملف: " + (hdr === "SQLite format 3" ? "SQLite سليمة" : "غير معروفة (" + hex(raw.slice(0, 8)) + ")"));
  if (hdr !== "SQLite format 3") return lines;
  lines.push("");

  const fixed = trimToPages(raw);
  lines.push("حجم الصفحة " + fixed.pageSize + " | الصفحات المتاحة " + fixed.pages + " من " + (fixed.declared || "؟") + " المعلنة");
  let db;
  try { db = await open(fixed.bytes); } catch (e) { lines.push("تعذّر فتح القاعدة: " + (e && e.message ? e.message : e)); return lines; }
  try {
    let objects = [];
    try { objects = db.all("SELECT type, name, tbl_name, sql FROM sqlite_master ORDER BY type, name"); }
    catch (e) { lines.push("تعذّرت قراءة التعريفات: " + (e && e.message ? e.message : e)); return lines; }
    lines.push("الكائنات: " + objects.map((o) => o.type + ":" + o.name).join(", "));
    lines.push("");
    for (const o of objects.filter((x) => x.type === "table")) {
      const virtual = /^\s*CREATE\s+VIRTUAL\s+TABLE/i.test(String(o.sql || ""));
      lines.push("## " + o.name + (virtual ? " [جدول افتراضي]" : ""));
      lines.push(String(o.sql || "").replace(/\s+/g, " "));
      if (virtual) { lines.push("  (لم يُقرأ)"); lines.push(""); continue; }
      try {
        const q = '"' + String(o.name).replace(/"/g, '""') + '"';
        for (const row of db.all("SELECT * FROM " + q + " LIMIT 3")) {
          lines.push("  - " + Object.entries(row).map(([k, v]) => k + "=" + cut(v)).join(" | "));
        }
      } catch (e) {
        lines.push("  (لا عينات: الجدول خارج الجزء المجلوب أو تعذّرت قراءته: " + (e && e.message ? e.message : e) + ")");
      }
      lines.push("");
    }
  } finally {
    db.close();
  }
  return lines;
}

const hex = (u8) => Array.from(u8).map((b) => b.toString(16).padStart(2, "0")).join("");
