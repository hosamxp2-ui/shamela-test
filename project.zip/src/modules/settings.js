// إعدادات القارئ: قيم افتراضية، تحقق وحدود، ألوان الثيمات، وحفظ محلي.
import { kvGet, kvSet } from "../database/idb.js";

export const FONTS = {
  amiri: { family: "'Amiri', 'Noto Naskh Arabic', serif", load: "Amiri" },
  naskh: { family: "'Noto Naskh Arabic', 'Amiri', serif", load: "Noto Naskh Arabic" },
  scheherazade: { family: "'Scheherazade New', 'Amiri', serif", load: "Scheherazade New" },
  kufi: { family: "'Noto Kufi Arabic', sans-serif", load: "Noto Kufi Arabic" },
  system: { family: "system-ui, 'Noto Naskh Arabic', serif", load: null }
};

export const THEMES = {
  light: { bg: "#fbfaf7", fg: "#1d1d1d", accent: "#0f5b46", muted: "#6b6b6b" },
  dark: { bg: "#121815", fg: "#e8eee9", accent: "#5fd3a0", muted: "#9fb0a6" },
  oled: { bg: "#000000", fg: "#d9e2dc", accent: "#5fd3a0", muted: "#8a9a90" },
  sepia: { bg: "#f4ecd8", fg: "#3b2f1e", accent: "#8a4b12", muted: "#7a6a50" }
};

export const DEFAULTS = {
  font: "amiri", weight: 400, size: 24, line: 2, para: 0.6, width: 100, margin: 14,
  theme: "app", custom: { bg: "#ffffff", fg: "#1a1a1a", accent: "#0f5b46" },
  showNotes: true, orientation: "auto"
};

export const RANGES = {
  size: [14, 48], line: [1.2, 3.2], para: [0, 2], width: [60, 100], margin: [0, 40]
};

const clamp = (v, [lo, hi], fallback) => {
  const n = Number(v);
  return Number.isFinite(n) ? Math.min(hi, Math.max(lo, n)) : fallback;
};
const hex = (v, fallback) => (typeof v === "string" && /^#[0-9a-fA-F]{6}$/.test(v) ? v : fallback);

export function sanitizeSettings(raw) {
  const r = raw && typeof raw === "object" ? raw : {};
  const c = r.custom && typeof r.custom === "object" ? r.custom : {};
  return {
    font: Object.prototype.hasOwnProperty.call(FONTS, r.font) ? r.font : DEFAULTS.font,
    weight: r.weight === 700 ? 700 : 400,
    size: clamp(r.size, RANGES.size, DEFAULTS.size),
    line: clamp(r.line, RANGES.line, DEFAULTS.line),
    para: clamp(r.para, RANGES.para, DEFAULTS.para),
    width: clamp(r.width, RANGES.width, DEFAULTS.width),
    margin: clamp(r.margin, RANGES.margin, DEFAULTS.margin),
    theme: ["app", "light", "dark", "oled", "sepia", "custom"].includes(r.theme) ? r.theme : DEFAULTS.theme,
    custom: {
      bg: hex(c.bg, DEFAULTS.custom.bg), fg: hex(c.fg, DEFAULTS.custom.fg), accent: hex(c.accent, DEFAULTS.custom.accent)
    },
    showNotes: r.showNotes !== false,
    orientation: ["auto", "portrait", "landscape"].includes(r.orientation) ? r.orientation : "auto"
  };
}

// appTheme: الثيم الفعّال للتطبيق (يُستعمل حين يكون ثيم القارئ "حسب التطبيق")
export function themeColors(s, appTheme = "light") {
  if (s.theme === "custom") return { ...THEMES.light, ...s.custom, muted: s.custom.fg };
  if (s.theme === "app") return THEMES[appTheme] || THEMES.light;
  return THEMES[s.theme] || THEMES.light;
}

// متغيرات CSS تُطبَّق على عنصر القارئ
export function toCssVars(s, appTheme = "light") {
  const c = themeColors(s, appTheme);
  return {
    "--r-font": FONTS[s.font].family,
    "--r-weight": String(s.weight),
    "--r-size": s.size + "px",
    "--r-line": String(s.line),
    "--r-para": s.para + "em",
    "--r-width": s.width + "%",
    "--r-margin": s.margin + "px",
    "--r-bg": c.bg, "--r-fg": c.fg, "--r-accent": c.accent, "--r-muted": c.muted
  };
}

export function createSettingsStore({ get = kvGet, set = kvSet } = {}) {
  let current = sanitizeSettings(null);
  return {
    async load() { try { current = sanitizeSettings(await get("settings")); } catch (_) { current = sanitizeSettings(null); } return current; },
    get: () => current,
    async update(patch) { current = sanitizeSettings({ ...current, ...patch, custom: { ...current.custom, ...(patch.custom || {}) } }); try { await set("settings", current); } catch (_) { /* نتابع بدون حفظ */ } return current; },
    async reset() { current = sanitizeSettings(null); try { await set("settings", current); } catch (_) { /* نتابع */ } return current; }
  };
}

// يحوّل تغيير عنصر تحكم في واجهة الإعدادات إلى تعديل على الإعدادات (أو null إن لم يُعرف)
export function patchFromControl(name, value, checked) {
  if (name === "font" || name === "theme" || name === "orientation") return { [name]: String(value) };
  if (["weight", "size", "line", "para", "width", "margin"].includes(name)) return { [name]: Number(value) };
  if (["bg", "fg", "accent"].includes(name)) return { theme: "custom", custom: { [name]: String(value) } };
  if (name === "showNotes") return { showNotes: !!checked };
  return null;
}
