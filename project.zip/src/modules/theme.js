// ثيم التطبيق: فاتح / داكن / OLED / بني، مع تشغيل تلقائي حسب النظام أو حسب الوقت.
import { kvGet, kvSet } from "../database/idb.js";

export const APP_THEMES = ["light", "dark", "oled", "sepia"];
export const DAY_THEMES = ["light", "sepia"];
export const NIGHT_THEMES = ["dark", "oled"];

export const APP_DEFAULTS = {
  theme: "light", auto: "system", dayTheme: "light", nightTheme: "dark", nightFrom: "19:00", nightTo: "06:00"
};

const hhmm = (v, fallback) => (typeof v === "string" && /^([01]\d|2[0-3]):[0-5]\d$/.test(v) ? v : fallback);

export function sanitizeAppSettings(raw) {
  const r = raw && typeof raw === "object" ? raw : {};
  return {
    theme: APP_THEMES.includes(r.theme) ? r.theme : APP_DEFAULTS.theme,
    auto: ["off", "system", "schedule"].includes(r.auto) ? r.auto : APP_DEFAULTS.auto,
    dayTheme: DAY_THEMES.includes(r.dayTheme) ? r.dayTheme : APP_DEFAULTS.dayTheme,
    nightTheme: NIGHT_THEMES.includes(r.nightTheme) ? r.nightTheme : APP_DEFAULTS.nightTheme,
    nightFrom: hhmm(r.nightFrom, APP_DEFAULTS.nightFrom),
    nightTo: hhmm(r.nightTo, APP_DEFAULTS.nightTo)
  };
}

const minutes = (s) => { const [h, m] = s.split(":").map(Number); return h * 60 + m; };

export function isNight(date, from, to) {
  const m = date.getHours() * 60 + date.getMinutes();
  const a = minutes(from), b = minutes(to);
  if (a === b) return false;
  return a < b ? m >= a && m < b : m >= a || m < b;
}

export function effectiveTheme(s, { systemDark = false, now = new Date() } = {}) {
  if (s.auto === "system") return systemDark ? s.nightTheme : s.dayTheme;
  if (s.auto === "schedule") return isNight(now, s.nightFrom, s.nightTo) ? s.nightTheme : s.dayTheme;
  return s.theme;
}

export function createThemeManager({ get = kvGet, set = kvSet, root, media, now = () => new Date(), timer } = {}) {
  const rootEl = root || (typeof document !== "undefined" ? document.documentElement : { dataset: {} });
  const mq = media || (typeof matchMedia !== "undefined" ? matchMedia("(prefers-color-scheme: dark)") : null);
  let s = sanitizeAppSettings(null);
  let current = null;
  const listeners = new Set();
  const compute = () => effectiveTheme(s, { systemDark: !!(mq && mq.matches), now: now() });
  const apply = () => {
    const e = compute();
    if (e === current) return;
    current = e;
    rootEl.dataset.theme = e;
    for (const fn of listeners) { try { fn(e); } catch (_) { /* مستمع معطوب */ } }
  };
  return {
    async load() { try { s = sanitizeAppSettings(await get("appSettings")); } catch (_) { s = sanitizeAppSettings(null); } apply(); return s; },
    get: () => s,
    effective: () => current || compute(),
    async update(patch) {
      s = sanitizeAppSettings({ ...s, ...patch });
      try { await set("appSettings", s); } catch (_) { /* نتابع دون حفظ */ }
      apply();
      return s;
    },
    subscribe(fn) { listeners.add(fn); return () => listeners.delete(fn); },
    refresh: apply,
    start() {
      if (mq && mq.addEventListener) mq.addEventListener("change", apply);
      (timer || setInterval)(apply, 60000);
    }
  };
}
