// مسح كامل لقاعدة services/tashkeel أثناء تنزيلها على قطع (Range) وفكّها بـ fflate، دون حفظها.
// الغرض: معرفة حجم كل جدول وعدد صفوفه وعيّنة منه قبل تصميم استيراد ما نحتاجه فقط.
import { source as defaultSource } from "../services/shamela-nas-source.js";
import { ConnectorError } from "../services/data-connector.js";
import { createScanner, reportLines } from "../services/sqlite-scan.js";
import { t } from "../strings.js";

const tick = () => new Promise((r) => setTimeout(r, 0));

export async function scanDb(which, { source = defaultSource, fflate = globalThis.fflate, chunk = 2 * 1024 * 1024, token = { cancelled: false }, onProgress = () => {} } = {}) {
  if (!fflate || !fflate.Gunzip) throw new ConnectorError("NO_FFLATE", t("err.noFflate"));
  const manifest = await source.manifest();
  const meta = manifest.data[which];
  const size = Number(meta.size);
  const scanner = createScanner();
  let produced = 0;
  const gz = new fflate.Gunzip((data) => { produced += data.length; scanner.push(data); });
  const lines = ["قاعدة " + which + ": المضغوط " + size + " بايت، بعد الفك المعلن " + (meta.raw_size || "؟") + " بايت"];
  let stopped = "";
  for (let off = 0; off < size; off += chunk) {
    if (token.cancelled) { stopped = "أُوقف المسح يدويًا؛ النتائج جزئية."; break; }
    const len = Math.min(chunk, size - off);
    const bytes = await source.dbRange(manifest, which, off, len);
    try {
      gz.push(bytes, off + len >= size);
    } catch (e) {
      stopped = "توقف فك الضغط عند " + off + " بايت: " + ((e && e.message) || e) + "؛ النتائج جزئية.";
      break;
    }
    onProgress({ done: off + len, total: size, produced });
    await tick();
  }
  lines.push("مفكوك " + produced + " بايت");
  if (stopped) lines.push(stopped);
  const rep = scanner.finish();
  lines.push(...reportLines(rep));
  return { lines, rep, produced, complete: !stopped };
}
