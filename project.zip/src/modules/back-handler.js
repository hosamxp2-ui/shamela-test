// قرار زر الرجوع في أندرويد (دالة نقية). الترتيب: نافذة، ثم لوحة القارئ، ثم ملء الشاشة، ثم التنقل.
export function decideBack({ modalOpen, sheetOpen, fullscreen, route, lastBackAt, now, exitWindow = 2000 }) {
  if (modalOpen) return { action: "close-modal", lastBackAt };
  if (sheetOpen) return { action: "close-sheet", lastBackAt };
  if (fullscreen) return { action: "exit-fullscreen", lastBackAt };
  if (!route || route === "categories") {
    if (lastBackAt != null && now - lastBackAt <= exitWindow) return { action: "exit", lastBackAt: null };
    return { action: "toast-exit", lastBackAt: now };
  }
  if (["authors", "books", "downloads", "settings", "tools"].includes(route)) return { action: "go-home", lastBackAt: null };
  return { action: "history-back", lastBackAt: null };
}
