// يبني فهرس متون الأحاديث من كتب الحديث المرتبطة المنزّلة على الجهاز ويقيّمه ذاتيًا (leave-one-book-out).
import { parseServices } from "./hadith-links.js";
import { shingles, buildIndex, evaluate, PARAMS, TEXT_INDEX_KEY, resetTextIndexCache } from "./hadith-text.js";
import { kvSet } from "../database/idb.js";

const tick = () => new Promise((r) => setTimeout(r, 0));

export async function buildHadithTextIndex({ books, openBook, nameOf = (b) => "#" + b, onProgress = () => {}, store = kvSet, evalPerBook = 300, statusLines = [], chunk = 400 }) {
  const data = [];
  let skippedMulti = 0, pagesUsed = 0;
  for (let bi = 0; bi < books.length; bi++) {
    const book = books[bi];
    onProgress({ book, bi, total: books.length, phase: "read", done: 0 });
    const db = await openBook(book);
    const keyHashes = new Map(), pages = [];
    try {
      // قراءة على دفعات بالمعرّف كي لا تُحمَّل نصوص كتاب كبير (مثل مسند أحمد) كلها في الذاكرة دفعة واحدة
      const bounds = db.all("SELECT MIN(id) AS lo, MAX(id) AS hi, COUNT(*) AS c FROM page WHERE services IS NOT NULL")[0] || {};
      const total = bounds.c || 0;
      const step = Math.max(1, Math.floor(total / evalPerBook));
      let seen = 0;
      for (let lo = bounds.lo; total && lo <= bounds.hi; lo += chunk) {
        const rows = db.all("SELECT id, body, services FROM page WHERE services IS NOT NULL AND id >= " + Number(lo) + " AND id < " + Number(lo + chunk) + " ORDER BY id");
        for (const row of rows) {
          seen++;
          const sv = parseServices(row.services);
          if (!sv || !sv.keys.length) continue;
          if (sv.keys.length > 1) { skippedMulti++; continue; }
          const key = sv.keys[0];
          const hs = shingles(row.body);
          if (!hs.size) continue;
          pagesUsed++;
          let m = keyHashes.get(key); if (!m) { m = new Set(); keyHashes.set(key, m); }
          for (const h of hs) m.add(h);
          if (seen % step === 0) pages.push({ keys: [key], hashes: hs });
        }
        onProgress({ book, bi, total: books.length, phase: "read", done: seen, of: total });
        await tick();
      }
    } finally { db.close(); }
    data.push({ book, keyHashes, pages });
  }
  const merged = new Map();
  for (const d of data) for (const [k, s] of d.keyHashes) { let m = merged.get(k); if (!m) { m = new Set(); merged.set(k, m); } for (const h of s) m.add(h); }
  onProgress({ phase: "index" }); await tick();
  const idx = buildIndex(merged);
  await store(TEXT_INDEX_KEY, idx);
  resetTextIndexCache();
  const L = [];
  L.push("## تقرير فهرس متون الأحاديث");
  for (const x of statusLines) L.push(x);
  if (statusLines.length) L.push("");
  L.push("كتب مفهرسة (" + books.length + "): " + books.map(nameOf).join("، "));
  L.push("أحاديث (مفاتيح) مفهرسة: " + idx.keyIds.length + " | بصمات: " + idx.hashes.length + " | حُذفت لشيوعها: " + idx.droppedCommon);
  L.push("صفحات استُعملت: " + pagesUsed + " | تُركت لاحتوائها أكثر من حديث: " + skippedMulti);
  L.push("حجم الفهرس ~" + ((idx.hashes.byteLength + idx.owners.byteLength) / 1048576).toFixed(1) + " MB | معاملات: n=" + idx.n + " mod=" + idx.mod);
  L.push("العتبات الحالية في القارئ: مشترك≥" + PARAMS.minShared + "، احتواء≥" + PARAMS.minContain);
  if (data.length >= 2) {
    L.push(""); L.push("## تقييم ذاتي (كل كتاب يُسأل بفهرس بقية الكتب)");
    L.push("الأعمدة: كتاب | حد المشترك/الاحتواء | صفحات قابلة للتقييم | إصابة الحديث الصحيح (أي ترتيب) | إصابة في المرتبة الأولى | متوسط المرشحين | صفحات رُشّح لها غير الصحيح فقط");
    for (const r of evaluate(data)) L.push(nameOf(r.book) + " | " + r.ms + "/" + r.mc + " | " + r.pages + " | " + r.any + " | " + r.top1 + " | " + (r.pages ? (r.cands / r.pages).toFixed(2) : "-") + " | " + r.wrongOnly);
  } else L.push("\nالتقييم الذاتي يحتاج كتابين مرتبطين منزّلين على الأقل.");
  return { lines: L, idx };
}
