// يبني فهرس متون الأحاديث من كتب الحديث المرتبطة المنزّلة على الجهاز، ويقيّمه ذاتيًا (leave-one-book-out)،
// ويقيس تغطيته على كتب غير مرتبطة منزّلة (مثل صحيح البخاري ت البغا) مع عينات للتحقق اليدوي.
import { parseServices } from "./hadith-links.js";
import { shingles, buildIndex, evaluate, matchPage, PARAMS, TEXT_INDEX_KEY, resetTextIndexCache, words } from "./hadith-text.js";
import { kvSet } from "../database/idb.js";

const tick = () => new Promise((r) => setTimeout(r, 0));

// قراءة صفحات كتاب على دفعات بالمعرّف (لا تُحمَّل نصوصه كلها دفعة واحدة)
async function eachPageChunked(db, where, chunk, fn, onChunk) {
  const b = db.all("SELECT MIN(id) AS lo, MAX(id) AS hi, COUNT(*) AS c FROM page" + (where ? " WHERE " + where : ""))[0] || {};
  if (!b.c) return 0;
  let seen = 0;
  for (let lo = b.lo; lo <= b.hi; lo += chunk) {
    const rows = db.all("SELECT id, body, services FROM page WHERE " + (where ? where + " AND " : "") + "id >= " + Number(lo) + " AND id < " + Number(lo + chunk) + " ORDER BY id");
    for (const row of rows) { seen++; fn(row, seen, b.c); }
    onChunk(seen, b.c);
    await tick();
  }
  return b.c;
}

export async function buildHadithTextIndex({ books, openBook, nameOf = (b) => "#" + b, onProgress = () => {}, store = kvSet, evalPerBook = 300, statusLines = [], chunk = 400, coverageBooks = [], locate = () => "" }) {
  const data = [];
  let skippedMulti = 0, pagesUsed = 0;
  for (let bi = 0; bi < books.length; bi++) {
    const book = books[bi];
    onProgress({ book, bi, total: books.length, phase: "read", done: 0 });
    const db = await openBook(book);
    const narrs = [], pages = [];
    try {
      let step = 1;
      const total = db.all("SELECT COUNT(*) AS c FROM page WHERE services IS NOT NULL")[0].c || 0;
      step = Math.max(1, Math.floor(total / evalPerBook));
      await eachPageChunked(db, "services IS NOT NULL", chunk, (row, seen) => {
        const sv = parseServices(row.services);
        if (!sv || !sv.keys.length) return;
        if (sv.keys.length > 1) { skippedMulti++; return; }
        const hs = shingles(row.body);
        if (!hs.size) return;
        pagesUsed++;
        narrs.push({ key: sv.keys[0], hashes: Uint32Array.from(hs) });
        if (seen % step === 0) pages.push({ keys: [sv.keys[0]], hashes: hs });
      }, (done, of) => onProgress({ book, bi, total: books.length, phase: "read", done, of }));
    } finally { db.close(); }
    data.push({ book, narrs, pages });
  }
  onProgress({ phase: "index" }); await tick();
  const all = []; for (const d of data) all.push(...d.narrs);
  const idx = buildIndex(all);
  await store(TEXT_INDEX_KEY, idx);
  resetTextIndexCache();

  const L = [];
  for (const x of statusLines) L.push(x);
  if (statusLines.length) L.push("");
  L.push("## تقرير فهرس متون الأحاديث");
  L.push("كتب مفهرسة (" + books.length + "): " + books.map(nameOf).join("، "));
  L.push("روايات (صفحات) مفهرسة: " + idx.narrKey.length + " | أحاديث (مفاتيح): " + idx.keys + " | بصمات: " + idx.hashes.length + " | حُذفت لشيوعها: " + idx.droppedCommon);
  L.push("تُركت لاحتوائها أكثر من حديث: " + skippedMulti + " | حجم الفهرس ~" + ((idx.hashes.byteLength + idx.owners.byteLength) / 1048576).toFixed(1) + " MB | n=" + idx.n + " mod=" + idx.mod);
  L.push("العتبات الحالية في القارئ: مشترك≥" + PARAMS.minShared + "، نسبة≥" + PARAMS.minContain);

  if (coverageBooks.length) {
    L.push(""); L.push("## تغطية كتب غير مرتبطة (للتحقق اليدوي)");
    L.push("صفحة «مغطّاة» = فيها حديث مرجّح واحد على الأقل. الصفحات القصيرة (<25 كلمة) لا تُحسب.");
    for (const book of coverageBooks) {
      onProgress({ book, phase: "cover", done: 0 });
      const db = await openBook(book);
      let textPages = 0, covered = 0; const samples = [];
      try {
        const marks = [];
        await eachPageChunked(db, "", chunk, (row) => {
          if (words(row.body).length < 25) return;
          textPages++;
          const c = matchPage(idx, row.body);
          if (c.length) { covered++; if (covered % 150 === 1 && samples.length < 8) samples.push({ id: row.id, c: c[0] }); }
        }, (done, of) => onProgress({ book, phase: "cover", done, of }));
      } finally { db.close(); }
      L.push(nameOf(book) + ": صفحات نصية " + textPages + " | مغطّاة " + covered + (textPages ? " (" + Math.round((covered / textPages) * 100) + "٪)" : ""));
      for (const s of samples) L.push("   عينة: صفحة معرّفها " + s.id + " ← حديث مفتاح " + s.c.key + " بنسبة " + Math.round(s.c.score * 100) + "٪ ← " + (locate(s.c.key) || "بلا موضع مسجّل"));
    }
  }

  if (data.length >= 2) {
    L.push(""); L.push("## تقييم ذاتي: الحديث نفسه بين مصنِّفين مختلفين (ألفاظ مختلفة)");
    L.push("كتاب | مشترك/نسبة | صفحات قابلة للتقييم | إصابة الحديث الصحيح | في المرتبة الأولى | متوسط المرشحين | صفحات رُشّح لها غير الصحيح فقط");
    for (const r of evaluate(data.map((d) => ({ book: d.book, narrs: d.narrs, pages: d.pages })))) L.push(nameOf(r.book) + " | " + r.ms + "/" + r.mc + " | " + r.pages + " | " + r.any + " | " + r.top1 + " | " + (r.pages ? (r.cands / r.pages).toFixed(2) : "-") + " | " + r.wrongOnly);
  } else L.push("\nالتقييم الذاتي يحتاج كتابين مرتبطين منزّلين على الأقل.");
  return { lines: L, idx };
}
