// آخر موضع قراءة لكل كتاب، وقائمة الكتب الأخيرة (للشاشة الرئيسية).
import { kvGet, kvSet } from "../database/idb.js";

const MAX_RECENT = 30;

// منتهٍ إن بلغ القارئ 97% من الصفحات فأكثر
export const isFinished = (p) => !!p && p.total > 1 && (p.index + 1) / p.total >= 0.97;

export function createProgressStore({ get = kvGet, set = kvSet, now = () => Date.now() } = {}) {
  const valid = (p) => p && Number.isInteger(p.index) && p.index >= 0;
  return {
    async load(bookId) {
      try {
        const p = await get("progress:" + bookId);
        return valid(p) ? p : null;
      } catch (_) { return null; }
    },
    async save(bookId, index, total) {
      try {
        const at = now();
        await set("progress:" + bookId, { index, total, at });
        await set("lastBook", { id: bookId, at });
        const list = (await get("recentBooks")) || [];
        const next = [{ id: bookId, at }, ...(Array.isArray(list) ? list.filter((x) => x && x.id !== bookId) : [])].slice(0, MAX_RECENT);
        await set("recentBooks", next);
      } catch (_) { /* لا نكسر القراءة */ }
    },
    // الكتب التي قُرئ فيها مؤخرًا مع تقدمها، الأحدث أولًا
    async recent(limit = 12) {
      try {
        const list = (await get("recentBooks")) || [];
        const out = [];
        for (const x of Array.isArray(list) ? list : []) {
          if (!x || !Number.isInteger(x.id)) continue;
          const p = await this.load(x.id);
          if (p) out.push({ id: x.id, at: x.at, index: p.index, total: p.total });
          if (out.length >= limit) break;
        }
        return out;
      } catch (_) { return []; }
    }
  };
}
