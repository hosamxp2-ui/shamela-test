// آخر موضع قراءة لكل كتاب (نسخة مصغّرة؛ الإحصائيات الكاملة في مرحلة لاحقة).
import { kvGet, kvSet } from "../database/idb.js";

export function createProgressStore({ get = kvGet, set = kvSet } = {}) {
  return {
    async load(bookId) {
      try {
        const p = await get("progress:" + bookId);
        return p && Number.isInteger(p.index) && p.index >= 0 ? p : null;
      } catch (_) { return null; }
    },
    async save(bookId, index, total) {
      try { await set("progress:" + bookId, { index, total, at: Date.now() }); await set("lastBook", { id: bookId, at: Date.now() }); } catch (_) { /* لا نكسر القراءة */ }
    }
  };
}
