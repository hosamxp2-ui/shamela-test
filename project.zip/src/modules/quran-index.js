// كشف الآيات في نص أي كتاب وربطها بمعرّف الآية (aya_id) المستورد من services.db، ومنه إلى التفاسير (tafsir_link).
// طريقة المطابقة (حتمية، بلا ذكاء اصطناعي): المقطع بين ﴿ ﴾ يُوحَّد (حذف التشكيل وعلامات المصحف وتوحيد الألف والياء والهاء)
// ثم يُبحث عنه ككلمات كاملة في نص القرآن المتصل. درجات الثقة:
//   sure  = تطابق النص + مرجع مذكور بجانبه (/الأنعام: ١٦٣/) متفقان
//   ref   = مرجع مذكور فقط (النص لا يطابق حرفيًا، كاختلاف رسم)
//   exact = تطابق حرفي في موضع واحد من القرآن
//   many  = تطابق في عدة مواضع (يعرض المرشحين ولا يختار)
// ما لا يغطيه: مقطع أقل من كلمتين، قوسان غير ﴿ ﴾، قوسان مفصولان بوسم HTML، الاختلاف الإملائي بين الرسمين.
import { normalizeArabic } from "./arabic.js";

export const qnorm = (s) => normalizeArabic(s).replace(/[^\u0621-\u064A ]/g, " ").replace(/\s+/g, " ").trim();
const toWest = (s) => String(s).replace(/[٠-٩]/g, (c) => String(c.charCodeAt(0) - 0x660));

export function buildQuranIndex({ ayaText, sura }) {
  if (!ayaText || !sura || !sura.length) return null;
  const parts = [], starts = [], ids = [];
  let off = 0;
  for (let id = 1; id < ayaText.length; id++) {
    const n = qnorm(ayaText[id] || "");
    if (!n) continue;
    starts.push(off); ids.push(id); parts.push(n);
    off += n.length + 1;
  }
  const flat = parts.join(" ");
  const verseAt = (pos) => { let lo = 0, hi = starts.length - 1; while (lo < hi) { const m = (lo + hi + 1) >> 1; if (starts[m] <= pos) lo = m; else hi = m - 1; } return ids[lo]; };
  const names = new Map(sura.map((s) => [qnorm(String(s.name).replace(/^سورة\s*/, "")), s]));
  const bySura = [...sura].sort((a, b) => a.first - b.first);

  const label = (id) => {
    let s = null; for (const x of bySura) { if (x.first <= id) s = x; else break; }
    return s && id < s.first + s.ayat ? { sura: s.id, name: s.name, aya: id - s.first + 1 } : null;
  };
  const idOf = (suraId, aya) => { const s = sura.find((x) => x.id === suraId); return s && aya >= 1 && aya <= s.ayat ? s.first + aya - 1 : null; };

  // مرجع يلي الآية مباشرة، مثل: /الأنعام: ١٦٣/ أو [البقرة: ٢٥٥] أو (النجم: ٣ - ٤)
  function parseRef(after) {
    const m = /^\s*[\/\[(]\s*(?:سورة\s+)?([\u0621-\u064A\u064B-\u0652\u0670\s]{2,25}?)\s*[:：]\s*([٠-٩0-9]{1,3})(?:\s*[-–ـ]\s*([٠-٩0-9]{1,3}))?\s*[\/\])]/.exec(after || "");
    if (!m) return null;
    const s = names.get(qnorm(m[1]));
    if (!s) return null;
    const a = Number(toWest(m[2])), b = m[3] ? Number(toWest(m[3])) : a;
    const from = idOf(s.id, a), to = idOf(s.id, b);
    return from && to && to >= from ? { from, to } : null;
  }

  function occurrences(n, cap = 200) {
    const out = [];
    let pos = flat.indexOf(n);
    while (pos !== -1 && out.length < cap) {
      const before = pos === 0 || flat[pos - 1] === " ", end = pos + n.length;
      if (before && (end === flat.length || flat[end] === " ")) out.push({ from: verseAt(pos), to: verseAt(end - 1) });
      pos = flat.indexOf(n, pos + 1);
    }
    return out;
  }

  // يعيد { conf, from, to } أو { conf: "many", cands: [aya_id…], total } أو null
  function find(segment, after = "") {
    const n = qnorm(segment);
    if (n.split(" ").length < 2) return null;
    const ref = parseRef(after);
    const occ = occurrences(n);
    if (ref) {
      const hit = occ.find((o) => o.from <= ref.from && ref.to <= o.to) || occ.find((o) => o.from === ref.from);
      if (hit) return { conf: "sure", from: ref.from, to: ref.to };
      return { conf: "ref", from: ref.from, to: ref.to };
    }
    if (occ.length === 1) return { conf: "exact", from: occ[0].from, to: occ[0].to };
    if (occ.length > 1) return { conf: "many", cands: occ.slice(0, 8).map((o) => o.from), total: occ.length };
    return null;
  }

  // يغلّف ﴿…﴾ في نص HTML (خارج الأوسمة فقط) بوسم span.ayah
  function wrapVerses(html) {
    return String(html).split(/(<[^>]*>)/).map((seg) => {
      if (seg.startsWith("<") || !seg.includes("﴿")) return seg;
      return seg.replace(/﴿([^﴿﴾]{3,800})﴾/g, (whole, inner, offset) => {
        const after = seg.slice(offset + whole.length, offset + whole.length + 70);
        const r = find(inner, after);
        if (!r) return whole;
        const attrs = r.conf === "many" ? `data-conf="many" data-cands="${r.cands.join(",")}" data-total="${r.total}"` : `data-conf="${r.conf}" data-a="${r.from}" data-b="${r.to}"`;
        return `<span class="ayah" ${attrs}>${whole}</span>`;
      });
    }).join("");
  }

  const suraByName = (text) => names.get(qnorm(String(text).replace(/^[\d٠-٩\s\-–.)(]+/, "").replace(/^(?:تفسير\s+)?سورة\s*/, ""))) || null;
  const suraInfo = (id) => sura.find((x) => x.id === id) || null;
  return { find, parseRef, label, idOf, wrapVerses, suraByName, suraInfo, count: ids.length };
}
