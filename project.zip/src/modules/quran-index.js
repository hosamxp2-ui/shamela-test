// كشف الآيات في نص أي كتاب وربطها بمعرّف الآية (aya_id) المستورد من services.db، ومنه إلى التفاسير (tafsir_link).
// طريقة المطابقة (حتمية، بلا ذكاء اصطناعي): المقطع بين ﴿ ﴾ يُوحَّد (حذف التشكيل وعلامات المصحف وتوحيد الألف والياء والهاء)
// ثم يُبحث عنه ككلمات كاملة في نص القرآن المتصل. درجات الثقة:
//   sure  = تطابق النص + مرجع مذكور بجانبه (/الأنعام: ١٦٣/) متفقان
//   ref   = مرجع مذكور فقط (النص لا يطابق حرفيًا، كاختلاف رسم)
//   exact = تطابق حرفي في موضع واحد من القرآن
//   many  = تطابق في عدة مواضع (يعرض المرشحين ولا يختار)
// ما لا يغطيه: مقطع أقل من كلمتين، قوسان غير ﴿ ﴾، قوسان مفصولان بوسم HTML، الاختلاف الإملائي بين الرسمين.
import { normalizeArabic } from "./arabic.js";

export const qnorm = (s) => normalizeArabic(s).replace(/[^\u0621-\u064A ]/g, " ").replace(/\s+/g, " ").trim();
const toWest = (s) => String(s).replace(/[٠-٩]/g, (c) => String(c.charCodeAt(0) - 0x660));

// مقاطع بين أقواس، بلا تداخل: ﴿ ﴾ لها الأولوية، ثم { } و« » و( ) و[ ]. المطابقة مع القرآن هي الفاصل لا شكل القوسين.
const RE_FANCY = /﴿([^﴿﴾]{3,800})﴾/g;
const RE_OTHER = /\{([^{}]{3,800})\}|«([^«»]{3,800})»|\(([^()]{3,400})\)|\[([^\[\]]{3,400})\]/g;
const OTHER_KINDS = ["curly", "guil", "paren", "square"];
export function scanSegments(text) {
  const out = []; let m;
  RE_FANCY.lastIndex = 0;
  while ((m = RE_FANCY.exec(text))) out.push({ inner: m[1], kind: "fancy", start: m.index, end: RE_FANCY.lastIndex });
  const fancy = out.slice();
  RE_OTHER.lastIndex = 0;
  while ((m = RE_OTHER.exec(text))) {
    const start = m.index, end = RE_OTHER.lastIndex;
    if (fancy.some((f) => f.start < end && start < f.end)) continue;
    const i = [1, 2, 3, 4].find((k) => m[k] !== undefined);
    out.push({ inner: m[i], kind: OTHER_KINDS[i - 1], start, end });
  }
  return out.sort((a, b) => a.start - b.start);
}

export function buildQuranIndex({ ayaText, sura }) {
  if (!ayaText || !sura || !sura.length) return null;
  const parts = [], starts = [], ids = [];
  let off = 0;
  for (let id = 1; id < ayaText.length; id++) {
    const n = qnorm(ayaText[id] || "");
    if (!n) continue;
    starts.push(off); ids.push(id); parts.push(n);
    off += n.length + 1;
  }
  const flat = parts.join(" ");
  const verseAt = (pos) => { let lo = 0, hi = starts.length - 1; while (lo < hi) { const m = (lo + hi + 1) >> 1; if (starts[m] <= pos) lo = m; else hi = m - 1; } return ids[lo]; };
  // فهرس كلمات القرآن المتصل لكشف مقاطع بلا أقواس
  const fw = flat.split(" "), wordStarts = new Int32Array(fw.length);
  { let o = 0; for (let k = 0; k < fw.length; k++) { wordStarts[k] = o; o += fw[k].length + 1; } }
  const trigrams = new Set(); for (let k = 0; k + 2 < fw.length; k++) trigrams.add(fw[k] + " " + fw[k + 1] + " " + fw[k + 2]);
  const wordIdxAt = (pos) => { let lo = 0, hi = wordStarts.length - 1; while (lo < hi) { const m = (lo + hi + 1) >> 1; if (wordStarts[m] <= pos) lo = m; else hi = m - 1; } return lo; };
  const MIN_PLAIN = 5, MIN_PLAIN_LETTERS = 18;

  // يعيد [{ start, end, from, to }] لمقاطع متصلة بلا أقواس تطابق القرآن في موضع واحد
  function plainRuns(text) {
    const toks = [];
    for (const m of text.matchAll(/[\u0621-\u064A\u064B-\u0652\u0670\u0671\u0640]+/g)) { const n = qnorm(m[0]); if (n) toks.push({ start: m.index, end: m.index + m[0].length, n }); }
    const out = [];
    for (let i = 0; i + 2 < toks.length;) {
      if (!trigrams.has(toks[i].n + " " + toks[i + 1].n + " " + toks[i + 2].n)) { i++; continue; }
      const key3 = toks[i].n + " " + toks[i + 1].n + " " + toks[i + 2].n;
      let best = 0; const heads = new Set(); const hits = [];
      let pos = flat.indexOf(key3), guard = 0;
      while (pos !== -1 && guard++ < 60) {
        if ((pos === 0 || flat[pos - 1] === " ")) {
          const w0 = wordIdxAt(pos); let k = 3;
          while (i + k < toks.length && w0 + k < fw.length && fw[w0 + k] === toks[i + k].n) k++;
          if (k > best) { best = k; hits.length = 0; }
          if (k === best) hits.push({ pos, w0, k });
        }
        pos = flat.indexOf(key3, pos + 1);
      }
      const letters = toks.slice(i, i + best).reduce((a, t) => a + t.n.length, 0);
      for (const h of hits) heads.add(verseAt(h.pos));
      if (best >= MIN_PLAIN && letters >= MIN_PLAIN_LETTERS && hits.length === 1) {
        const h = hits[0], lastPos = wordStarts[h.w0 + best - 1];
        out.push({ start: toks[i].start, end: toks[i + best - 1].end, from: verseAt(h.pos), to: verseAt(lastPos) });
        i += best;
      } else i += best >= 3 ? 1 : 1;
    }
    return out;
  }

  const names = new Map(sura.map((s) => [qnorm(String(s.name).replace(/^سورة\s*/, "")), s]));
  const bySura = [...sura].sort((a, b) => a.first - b.first);

  const label = (id) => {
    let s = null; for (const x of bySura) { if (x.first <= id) s = x; else break; }
    return s && id < s.first + s.ayat ? { sura: s.id, name: s.name, aya: id - s.first + 1 } : null;
  };
  const idOf = (suraId, aya) => { const s = sura.find((x) => x.id === suraId); return s && aya >= 1 && aya <= s.ayat ? s.first + aya - 1 : null; };

  // مرجع يلي الآية مباشرة، مثل: /الأنعام: ١٦٣/ أو [البقرة: ٢٥٥] أو (النجم: ٣ - ٤)
  function parseRef(after) {
    const m = /^\s*[\/\[(]\s*(?:سورة\s+)?([\u0621-\u064A\u064B-\u0652\u0670\s]{2,25}?)\s*[:：]\s*([٠-٩0-9]{1,3})(?:\s*[-–ـ]\s*([٠-٩0-9]{1,3}))?\s*[\/\])]/.exec(after || "");
    if (!m) return null;
    const s = names.get(qnorm(m[1]));
    if (!s) return null;
    const a = Number(toWest(m[2])), b = m[3] ? Number(toWest(m[3])) : a;
    const from = idOf(s.id, a), to = idOf(s.id, b);
    return from && to && to >= from ? { from, to } : null;
  }

  function occurrences(n, cap = 200) {
    const out = [];
    let pos = flat.indexOf(n);
    while (pos !== -1 && out.length < cap) {
      const before = pos === 0 || flat[pos - 1] === " ", end = pos + n.length;
      if (before && (end === flat.length || flat[end] === " ")) out.push({ from: verseAt(pos), to: verseAt(end - 1) });
      pos = flat.indexOf(n, pos + 1);
    }
    return out;
  }

  // يعيد { conf, from, to } أو { conf: "many", cands: [aya_id…], total } أو null
  function find(segment, after = "") {
    const n = qnorm(segment);
    if (n.split(" ").length < 2) return null;
    const ref = parseRef(after);
    const occ = occurrences(n);
    if (ref) {
      const hit = occ.find((o) => o.from <= ref.from && ref.to <= o.to) || occ.find((o) => o.from === ref.from);
      if (hit) return { conf: "sure", from: ref.from, to: ref.to };
      return { conf: "ref", from: ref.from, to: ref.to };
    }
    if (occ.length === 1) return { conf: "exact", from: occ[0].from, to: occ[0].to };
    if (occ.length > 1) return { conf: "many", cands: occ.slice(0, 8).map((o) => o.from), total: occ.length };
    return null;
  }

  // يغلّف الآيات في نص HTML (خارج الأوسمة فقط) بوسم span.ayah. ﴿ ﴾: كل الدرجات. الأقواس الأخرى: ثلاث كلمات فأكثر ودرجة sure/exact فقط.
  function wrapVerses(html) {
    return String(html).split(/(<[^>]*>)/).map((seg) => {
      if (seg.startsWith("<") || seg.length < 15) return seg;
      const spans = [];
      for (const sg of scanSegments(seg)) {
        const r = find(sg.inner, seg.slice(sg.end, sg.end + 70));
        if (!r) continue;
        if (sg.kind !== "fancy" && (r.conf === "many" || r.conf === "ref" || qnorm(sg.inner).split(" ").length < 3)) continue;
        const attrs = r.conf === "many" ? `data-conf="many" data-cands="${r.cands.join(",")}" data-total="${r.total}"` : `data-conf="${r.conf}" data-a="${r.from}" data-b="${r.to}"`;
        spans.push({ start: sg.start, end: sg.end, attrs });
      }
      // مقاطع متصلة بلا أقواس في الفراغات بين ما كُشف بالأقواس
      let gapStart = 0; const all = [];
      for (const sp of spans.concat([{ start: seg.length, end: seg.length, attrs: null }])) {
        if (sp.start > gapStart) for (const pr of plainRuns(seg.slice(gapStart, sp.start))) all.push({ start: gapStart + pr.start, end: gapStart + pr.end, attrs: `data-conf="plain" data-a="${pr.from}" data-b="${pr.to}"` });
        if (sp.attrs) all.push(sp);
        gapStart = sp.end;
      }
      if (!all.length) return seg;
      let out = "", pos = 0;
      for (const sp of all) { out += seg.slice(pos, sp.start) + `<span class="ayah" ${sp.attrs}>${seg.slice(sp.start, sp.end)}</span>`; pos = sp.end; }
      return out + seg.slice(pos);
    }).join("");
  }

  const suraByName = (text) => names.get(qnorm(String(text).replace(/^[\d٠-٩\s\-–.)(]+/, "").replace(/^(?:تفسير\s+)?سورة\s*/, ""))) || null;
  const suraInfo = (id) => sura.find((x) => x.id === id) || null;
  return { find, parseRef, label, idOf, wrapVerses, plainRuns, suraByName, suraInfo, count: ids.length };
}
