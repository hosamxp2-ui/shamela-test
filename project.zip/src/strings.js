// كل نصوص الواجهة هنا، لتسهيل إضافة الإنجليزية لاحقًا (أضف كائن en وبدّل LANG).
const ar = {
  appName: "المكتبة الإسلامية الشاملة",
  nav: { categories: "الأقسام", authors: "المؤلفون", books: "الكتب", tools: "الأدوات" },
  firstRun: {
    title: "مرحبًا بك",
    body: "لعرض الأقسام والمؤلفين والكتب نحتاج تنزيل فهرس المكتبة مرة واحدة (نحو 4 ميغابايت). لا تُنزَّل أي كتب تلقائيًا.",
    button: "تنزيل الفهرس"
  },
  progress: {
    manifest: "قراءة بيانات المصدر…",
    master: "تنزيل فهرس الأقسام والكتب…",
    unpack: "فك الضغط…",
    parse: "قراءة الفهرس…",
    index: "تنزيل مواضع الكتب…",
    save: "حفظ الفهرس على الجهاز…",
    done: "اكتمل تنزيل الفهرس."
  },
  err: {
    notNative: "هذه الميزة تعمل داخل تطبيق Android فقط.",
    network: "تعذّر الاتصال بالخادم. تحقق من الإنترنت وحاول مرة أخرى.",
    serverPage: "أعاد الخادم صفحة بدل الملف المطلوب. حاول مرة أخرى بعد قليل.",
    http: "رفض الخادم الطلب (رمز {status}).",
    sha: "فشل التحقق من سلامة الملف (SHA256). لن يُستخدم.",
    noRange: "الخادم لا يؤكد دعم الجلب الجزئي، فلن أجلب الكتاب.",
    range: "لم يرجع الخادم الجزء المطلوب من الكتاب.",
    tooBig: "هذا الكتاب كبير ({mb} ميغابايت مضغوطًا)، ويحتاج مرحلة التنزيل. الحد الحالي {max} ميغابايت.",
    notAvailable: "هذا الكتاب غير متوفر في بيانات الخادم.",
    sqlNotLoaded: "لم تُحمَّل مكتبة قراءة قواعد البيانات.",
    generic: "حدث خطأ غير متوقع: {message}"
  },
  online: { offline: "لا يوجد اتصال بالإنترنت. تعمل المكتبة بالفهرس المحفوظ." },
  update: { available: "يتوفر إصدار أحدث من الفهرس ({version}). يمكنك تحديثه من تبويب الأدوات.", none: "الفهرس محدّث." },
  books: {
    search: "ابحث في العناوين والمؤلفين",
    count: "{n} كتاب",
    pagesN: "{n} صفحة",
    more: "عرض المزيد",
    empty: "لا نتائج مطابقة.",
    unavailable: "غير متاح على الخادم",
    sort: { name: "الاسم", author: "المؤلف", added: "تاريخ الإضافة", pages: "عدد الصفحات" },
    asc: "تصاعدي", desc: "تنازلي",
    filterCat: "القسم: {name}", filterAuthor: "المؤلف: {name}"
  },
  authors: { search: "ابحث في المؤلفين", died: "ت {year} هـ" },
  book: {
    author: "المؤلف", category: "القسم", pages: "الصفحات", titles: "العناوين",
    size: "الحجم المضغوط", rawSize: "الحجم بعد الفك", added: "تاريخ الإضافة",
    inspect: "فحص بنية الكتاب", downloadSoon: "تنزيل الكتاب وقراءته: في المراحل القادمة."
  },
  tools: {
    catalog: "الفهرس المحفوظ",
    version: "إصدار البيانات", built: "تاريخ الحفظ", counts: "الكتب / المتاحة / المؤلفون / الأقسام",
    refresh: "تحديث الفهرس من الخادم",
    inspectTitle: "فحص بنية كتاب",
    inspectHint: "يجلب كتابًا صغيرًا واحدًا فقط من الخادم ويعرض جداوله.",
    inspectButton: "فحص",
    bookIdPlaceholder: "رقم الكتاب",
    copy: "نسخ النتيجة",
    inspectStart: "جاري فحص الكتاب {id}…",
    inspectBadId: "أدخل رقم كتاب صحيح موجود في الفهرس.",
    refreshing: "جاري تحديث الفهرس…"
  }
};

const LANGS = { ar };
export const LANG = "ar";

export function t(path, vars) {
  let cur = LANGS[LANG];
  for (const part of path.split(".")) cur = cur == null ? undefined : cur[part];
  if (typeof cur !== "string") return path;
  return vars ? cur.replace(/\{(\w+)\}/g, (_, k) => (vars[k] != null ? vars[k] : "")) : cur;
}
