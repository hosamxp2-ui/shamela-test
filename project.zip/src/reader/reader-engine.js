// محرك القارئ: يفتح قاعدة كتاب منزّل ويعطي الصفحات بالتتابع والعناوين كشجرة.
import { openDatabase as defaultOpen } from "../services/sqlite.js";
import { ConnectorError } from "../services/data-connector.js";
import { LIMITS } from "../config.js";
import { t } from "../strings.js";

export function buildToc(titles) {
  const byId = new Map(titles.map((x) => [x.id, x]));
  const depth = (x) => { let d = 0, p = x; const seen = new Set(); while (p && p.parent && p.parent !== p.id && byId.has(p.parent) && !seen.has(p.id)) { seen.add(p.id); p = byId.get(p.parent); d++; } return d; };
  return titles.map((x) => ({ id: x.id, page: x.page, parent: x.parent || 0, text: String(x.text || "").trim(), depth: depth(x) })).filter((x) => x.text);
}

export async function openReader({ id, dl, catalog, open = defaultOpen }) {
  const entry = catalog.fileInfo(id);
  if (entry && entry.size > LIMITS.readerMaxRawBytes) {
    throw new ConnectorError("TOO_BIG_READ", t("reader.tooBig", { mb: Math.round(entry.size / 1048576) }));
  }
  const bytes = await dl.getBookBytes(id);
  const db = await open(bytes);
  try {
    const pageIds = db.all("SELECT id FROM page ORDER BY id").map((r) => r.id);
    if (!pageIds.length) throw new ConnectorError("EMPTY_BOOK", t("reader.empty"));
    let titles = [];
    try { titles = db.all("SELECT id, page, parent, text FROM title ORDER BY id"); } catch (_) { /* كتاب بلا عناوين */ }
    const indexOfPageId = new Map(pageIds.map((pid, i) => [pid, i]));
    return {
      total: pageIds.length,
      toc: buildToc(titles),
      indexOfPageId: (pid) => (indexOfPageId.has(pid) ? indexOfPageId.get(pid) : 0),
      getPage(index) {
        const i = Math.min(pageIds.length - 1, Math.max(0, index));
        const row = db.all("SELECT id, part, page, number, body, foot FROM page WHERE id=" + Number(pageIds[i]))[0];
        return { index: i, ...row };
      },
      close: () => db.close()
    };
  } catch (e) {
    db.close();
    throw e;
  }
}
