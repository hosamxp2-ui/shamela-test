// كتب عربية: الصفحة التالية بتحريك الإصبع نحو اليمين (الكتاب مجلّد من اليمين).
export function swipeDirection(dx, dy, { min = 70, ratio = 1.5 } = {}) {
  if (Math.abs(dx) < min || Math.abs(dx) < ratio * Math.abs(dy)) return null;
  return dx > 0 ? "next" : "prev";
}

export function clampIndex(i, total) {
  return Math.min(total - 1, Math.max(0, Number.isFinite(i) ? Math.trunc(i) : 0));
}
