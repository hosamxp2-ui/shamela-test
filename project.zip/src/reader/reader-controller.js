// ربط القارئ بالصفحة (DOM). المنطق الحسابي في ملفات نقية مختبرة:
// content.js، reader-engine.js، toc.js، gestures.js، notes.js، settings.js.
import { parseServices, buildHadithView, tafsirFor } from "../modules/hadith-links.js";
import { matchPage, buildMatchView } from "../modules/hadith-text.js";
import { openReader } from "./reader-engine.js";
import { renderPage, esc } from "./content.js";
import { swipeDirection, clampIndex } from "./gestures.js";
import { buildTree, visibleRows, currentTitleId, initialExpanded, allWithChildren } from "./toc.js";
import { toCssVars, patchFromControl, sanitizeSettings, RANGES } from "../modules/settings.js";
import { detectFonts } from "../modules/fonts.js";
import { formatAdded } from "../modules/catalog.js";
import { highlightTermsOf } from "../search/text-search.js";
import { searchSheetInner, searchHitsHtml } from "../components/search-view.js";
import { SITE_BOOK_URL } from "../config.js";
import { fmtBytes } from "../components/views.js";
import * as V from "../components/reader-view.js";
import { t } from "../strings.js";

export async function mountReader({ container, id, catalog, dl, settingsStore, progressStore, themeManager, notesStore, statsStore, toast = () => {}, startIndex = null, startPageId = null, highlight = null, loadLinks = null, loadTextIndex = null }) {
  const book = catalog.getBook(id);
  container.innerHTML = V.readerShellHtml({ title: book ? book.name : "" });
  document.body.classList.add("reading");
  const root = container.querySelector("#reader");
  const $ = (s) => root.querySelector(s);
  const scrollEl = $("#r-scroll"), pageEl = $("#r-page"), sheet = $("#r-sheet"), slider = $("#r-slider"), pos = $("#r-pos");
  const st = {
    reader: null, index: 0, pageId: 0, page: null, settings: await settingsStore.load(), fonts: {}, entries: [],
    destroyed: false, saveTimer: null, tick: null, flushT: null, dwell: null, lastActive: Date.now(), hl: highlight && highlight.q ? highlight.q : "", hlx: !!(highlight && highlight.exact), floatCollapsed: false, lastQuote: "", lastQuoteAt: 0,
    toc: { tree: null, expanded: new Set(), filter: "" }, links: null, textIdx: null, cands: [], candsFor: null
  };
  const fontsReady = detectFonts().then((f) => { st.fonts = f; return f; });
  const appTheme = () => (themeManager ? themeManager.effective() : "light");

  const apply = (s = st.settings) => { for (const [k, v] of Object.entries(toCssVars(s, appTheme()))) root.style.setProperty(k, v); };
  apply();
  const unsubTheme = themeManager ? themeManager.subscribe(() => apply()) : () => {};

  let ratio = 0, resizing = false, resizeTimer = null;
  const onScroll = () => { if (resizing) return; const h = scrollEl.scrollHeight - scrollEl.clientHeight; ratio = h > 0 ? scrollEl.scrollTop / h : 0; };
  const onResize = () => {
    resizing = true;
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => { const h = scrollEl.scrollHeight - scrollEl.clientHeight; scrollEl.scrollTop = ratio * h; setTimeout(() => { resizing = false; }, 60); }, 150);
  };
  const onSelection = () => {
    const sel = window.getSelection();
    const txt = sel ? String(sel).trim() : "";
    if (txt && sel.anchorNode && pageEl.contains(sel.anchorNode)) { st.lastQuote = txt.slice(0, 600); st.lastQuoteAt = Date.now(); }
  };
  scrollEl.addEventListener("scroll", onScroll, { passive: true });
  window.addEventListener("resize", onResize);
  document.addEventListener("selectionchange", onSelection);

  const closeSheet = () => { sheet.hidden = true; sheet.innerHTML = ""; };
  const api = { destroy: () => destroy(), closeSheet, sheetOpen: () => !sheet.hidden };

  function destroy() {
    if (st.destroyed) return;
    st.destroyed = true;
    clearTimeout(st.saveTimer);
    clearTimeout(resizeTimer);
    clearInterval(st.tick); clearInterval(st.flushT); clearTimeout(st.dwell);
    if (statsStore) statsStore.flush();
    unsubTheme();
    window.removeEventListener("resize", onResize);
    document.removeEventListener("selectionchange", onSelection);
    if (st.reader) { progressStore.save(id, st.index, st.reader.total); st.reader.close(); }
    document.body.classList.remove("reading");
    try { if (document.fullscreenElement) document.exitFullscreen(); } catch (_) { /* لا شيء */ }
    try { screen.orientation.unlock(); } catch (_) { /* لا شيء */ }
  }

  try {
    st.reader = await openReader({ id, dl, catalog });
    if (notesStore) await notesStore.load(id);
    if (statsStore) await statsStore.loadBook(id);
    try { st.links = loadLinks ? await loadLinks() : null; } catch (_) { st.links = null; }
    try { st.textIdx = loadTextIndex ? await loadTextIndex() : null; } catch (_) { st.textIdx = null; }
    if (startPageId != null && Number.isInteger(Number(startPageId))) {
      const want = Number(startPageId), idx = st.reader.indexOfPageId(want);
      if (st.reader.getPage(idx).id === want) startIndex = idx;
    }
  } catch (e) {
    const msg = e && e.name === "ConnectorError" ? e.message : t("err.generic", { message: (e && e.message) || String(e) });
    pageEl.innerHTML = `<p class="r-msg bad">${esc(msg)}</p>`;
    root.addEventListener("click", (ev) => { if (ev.target.closest('[data-r="back"]')) history.back(); });
    return api;
  }

  // ---------- الصفحة ----------
  const labelOf = (p) => [V.partLabel(p.part), p.page != null ? t("reader.page", { p: p.page }) : ""].filter(Boolean).join(" • ");
  const marks = () => (notesStore ? notesStore.pageMarks(id, st.index) : { bookmark: false, notes: 0 });

  function refreshFloat() {
    const el = $("#r-float");
    const sv = st.page ? parseServices(st.page.services) : null;
    const own = !!(sv && sv.keys.length);
    if (st.page && st.candsFor !== st.page.id) { // مطابقة نصية لصفحة بلا مفتاح رسمي، تُحسب مرة لكل صفحة
      st.candsFor = st.page.id;
      st.cands = !own && st.textIdx && st.links ? matchPage(st.textIdx, st.page.body) : [];
    }
    if (el) el.outerHTML = V.floatHtml({ bookmarked: marks().bookmark, collapsed: st.floatCollapsed, hadith: own ? true : st.cands.length ? "guess" : false });
  }

  const saveSoon = () => {
    clearTimeout(st.saveTimer);
    st.saveTimer = setTimeout(() => progressStore.save(id, st.index, st.reader.total), 500);
  };

  function show(index, anchor) {
    const p = st.reader.getPage(index);
    st.index = p.index; st.pageId = p.id; st.page = p;
    if (statsStore) { clearTimeout(st.dwell); const idx = p.index; st.dwell = setTimeout(() => statsStore.recordPage(id, idx), 4000); }
    const r = renderPage(p, { showNotes: st.settings.showNotes, highlightTerms: st.hl ? highlightTermsOf(st.hl) : [], quran: st.links ? st.links.quran : null });
    st.entries = r.entries;
    pageEl.innerHTML = V.pageHtmlWithMarks(p, r, marks());
    scrollEl.scrollTop = 0;
    if (anchor) { const el = pageEl.querySelector("#toc-" + anchor); if (el) el.scrollIntoView({ block: "start" }); }
    slider.max = String(st.reader.total - 1);
    slider.value = String(st.index);
    pos.textContent = t("reader.position", { i: st.index + 1, n: st.reader.total });
    refreshFloat();
    saveSoon();
  }
  const go = (delta) => { const i = clampIndex(st.index + delta, st.reader.total); if (i !== st.index) show(i); };

  const openSheet = (title, inner) => { sheet.innerHTML = V.sheetHtml(title, inner); sheet.hidden = false; };
  const openSettings = async () => { await fontsReady; openSheet(t("reader.settings"), V.settingsHtml(st.settings, st.fonts)); };

  function scrollToRef(n) {
    const el = pageEl.querySelector("#fnref-" + n);
    if (!el) return;
    el.scrollIntoView({ block: "center" });
    el.classList.add("flash");
    setTimeout(() => el.classList.remove("flash"), 1400);
  }

  async function applyOrientation() {
    const note = $("#r-note");
    try {
      if (st.settings.orientation === "auto") screen.orientation.unlock();
      else await screen.orientation.lock(st.settings.orientation);
      if (note) note.textContent = "";
    } catch (_) { if (note) note.textContent = t("reader.set.orientationFail"); }
  }

  async function toggleFullscreen() {
    try {
      if (document.fullscreenElement) await document.exitFullscreen();
      else await root.requestFullscreen();
    } catch (_) {
      root.classList.add("bars-hidden");
      const note = $("#r-note");
      if (note) note.textContent = t("reader.set.fullscreenFail");
    }
  }

  async function change(name, value, checked) {
    const patch = patchFromControl(name, value, checked);
    if (!patch) return;
    st.settings = await settingsStore.update(patch);
    apply();
    if (name === "showNotes") show(st.index);
    if (name === "orientation") { await openSettings(); await applyOrientation(); }
    else if (name === "theme" || name === "weight") { if (!sheet.hidden && sheet.querySelector("[data-seg]")) await openSettings(); }
  }

  // ---------- الفهرس الشجري ----------
  function renderTocList() {
    const list = $("#toc-list");
    if (!list) return;
    const cur = currentTitleId(st.reader.toc, st.pageId);
    list.innerHTML = V.tocListHtml(visibleRows(st.toc.tree, st.toc.expanded, st.toc.filter), cur);
  }
  function openToc() {
    st.toc.tree = buildTree(st.reader.toc);
    st.toc.filter = "";
    const cur = currentTitleId(st.reader.toc, st.pageId);
    st.toc.expanded = initialExpanded(st.toc.tree, cur);
    openSheet(t("reader.tb.toc"), st.reader.toc.length ? V.tocSheetInner() : `<p class="r-msg">${esc(t("reader.noToc"))}</p>`);
    if (!st.reader.toc.length) return;
    renderTocList();
    const row = sheet.querySelector("#toc-row-" + cur);
    if (row) row.scrollIntoView({ block: "center" });
  }

  // ---------- الإشارات والملاحظات ----------
  function openNotes() {
    openSheet(t("reader.notes.title"), V.notesSheetInner(notesStore ? notesStore.list(id) : []));
  }
  function openEditor({ quote = "", text = "", editingId = null } = {}) {
    st.editingId = editingId;
    st.editorQuote = quote;
    openSheet(t("reader.notes.editTitle"), V.noteEditorHtml({ quote, text, editing: !!editingId }));
    const ta = $("#note-text");
    if (ta) ta.focus();
  }
  async function saveNote() {
    const text = ($("#note-text").value || "").trim();
    let okSave;
    if (st.editingId) okSave = await notesStore.updateNote(id, st.editingId, text);
    else okSave = !!(await notesStore.addNote(id, { pageIndex: st.index, pageId: st.pageId, label: labelOf(st.page), text, quote: st.editorQuote }));
    if (!okSave) { const err = $("#note-err"); if (err) err.hidden = false; return; }
    st.lastQuote = ""; st.lastQuoteAt = 0;
    toast(t("reader.notes.saved"));
    refreshPageMarks();
    openNotes();
  }
  function refreshPageMarks() {
    const meta = pageEl.querySelector(".r-meta");
    if (meta) meta.innerHTML = esc(labelOf(st.page)) + " " + V.marksHtml(marks());
    refreshFloat();
  }
  async function toggleBookmark() {
    if (!notesStore) return;
    const r = await notesStore.toggleBookmark(id, { pageIndex: st.index, pageId: st.pageId, label: labelOf(st.page) });
    toast(r.on ? t("reader.notes.bookmarkOn") : t("reader.notes.bookmarkOff"));
    refreshPageMarks();
  }

  // ---------- معلومات الكتاب ----------
  function openInfo() {
    const entry = catalog.fileInfo(id);
    const cat = book ? catalog.getCategory(book.cat) : null;
    openSheet(t("reader.info.title"), V.infoHtml({
      authors: catalog.bookAuthorIds(id).map((a) => { const au = catalog.getAuthor(a); return { name: au ? au.name : "", death: au && au.death ? au.death : "" }; }),
      category: cat ? cat.name : "",
      pages: entry ? entry.pages : st.reader.total,
      titles: entry ? entry.titles : st.reader.toc.length,
      size: entry ? fmtBytes(entry.length) : "",
      rawSize: entry ? fmtBytes(entry.size) : "",
      added: book ? formatAdded(book.added) : "",
      url: SITE_BOOK_URL.replace("{id}", String(id))
    }));
  }

  async function quickNight() {
    const eff = st.settings.theme === "app" ? appTheme() : st.settings.theme === "custom" ? "light" : st.settings.theme;
    const app = themeManager ? themeManager.get() : { dayTheme: "light", nightTheme: "dark" };
    await change("theme", eff === "dark" || eff === "oled" ? app.dayTheme : app.nightTheme);
  }
  const stepSize = (d) => change("size", Math.min(RANGES.size[1], Math.max(RANGES.size[0], st.settings.size + d)));

  // ---------- الحديث والإسناد ----------
  async function openHadith() {
    const sv = st.page ? parseServices(st.page.services) : null;
    if (!sv || !sv.keys.length) {
      if (!st.cands.length) return;
      openSheet(t("reader.hadith.matchTitle"), V.hadithMatchInner(buildMatchView(st.cands, st.links, id, st.page.id), fxLinks));
      return;
    }
    const items = buildHadithView(sv, st.links, id, st.pageId);
    openSheet(t("reader.hadith.title"), V.hadithSheetInner(items, {
      bookName: (b) => { const x = catalog.getBook(b); return x ? x.name : "#" + b; },
      downloaded: (b) => !!(dl && dl.isDownloaded(b))
    }));
  }

  // ---------- تفسير الآية ----------
  const fxLinks = {
    bookName: (b) => { const x = catalog.getBook(b); return x ? x.name : "#" + b; },
    downloaded: (b) => !!(dl && dl.isDownloaded(b))
  };
  const ayaLoc = (a, b) => {
    const q = st.links && st.links.quran, la = q ? q.label(a) : null, lb = q ? q.label(b) : null;
    if (!la) return "";
    if (a === b) return t("reader.ayah.loc", { s: la.name, a: la.aya });
    if (lb && lb.sura === la.sura) return t("reader.ayah.locRange", { s: la.name, a: la.aya, b: lb.aya });
    return t("reader.ayah.locCross", { s: la.name, a: la.aya });
  };
  const ayaTextOf = (a, b) => { const T = (st.links && st.links.ayaText) || []; const o = []; for (let i = a; i <= Math.min(b, a + 6); i++) if (T[i]) o.push(T[i]); return o.join(" "); };
  function showAyah(a, b, conf) {
    const L = st.links;
    openSheet(t("reader.ayah.title"), V.ayahSheetInner({
      loc: ayaLoc(a, b), text: ayaTextOf(a, b), conf, hasLinks: !!L, groups: L ? tafsirFor(L, a) : [],
      note: b > a ? t("reader.ayah.rangeNote") : ""
    }, fxLinks));
  }
  function openAyah(el) {
    const L = st.links;
    if (!L) { openSheet(t("reader.ayah.title"), V.ayahSheetInner({ loc: "", text: "", conf: "exact", hasLinks: false, groups: [] }, fxLinks)); return; }
    if (el.dataset.conf === "many") {
      const cands = String(el.dataset.cands || "").split(",").map(Number).filter(Boolean).map((id) => ({ id, loc: ayaLoc(id, id), text: ayaTextOf(id, id) }));
      openSheet(t("reader.ayah.title"), V.ayahCandidatesInner(Number(el.dataset.total) || cands.length, cands));
      return;
    }
    showAyah(Number(el.dataset.a), Number(el.dataset.b), el.dataset.conf);
  }

  // ---------- البحث داخل الكتاب ----------
  function openSearch() {
    openSheet(t("reader.rs.title"), searchSheetInner({ q: st.hl, exact: st.hlx }));
    const q = $("#rs-q");
    if (q) q.focus();
    if (st.hl) runSearch();
  }
  async function runSearch() {
    const q = ($("#rs-q").value || "").trim();
    const exact = !!$("#rs-exact").checked;
    const status = $("#rs-status"), list = $("#rs-list");
    if (!q) return;
    status.textContent = t("search.progress", { done: 0, total: 1 });
    list.innerHTML = "";
    try {
      const hits = await st.reader.search(q, { exact, perBook: 100 });
      if (st.destroyed || sheet.hidden) return;
      st.hl = q; st.hlx = exact;
      status.textContent = hits.length ? t("reader.rs.count", { n: hits.length }) + (hits.length >= 100 ? " " + t("reader.rs.capped", { n: 100 }) : "") : "";
      list.innerHTML = searchHitsHtml(hits);
      show(st.index); // لتمييز الكلمات في الصفحة الحالية
    } catch (e) { status.textContent = t("err.generic", { message: (e && e.message) || String(e) }); }
  }

  // ---------- الأحداث ----------
  root.addEventListener("click", async (e) => {
    const r = e.target.closest("[data-r]");
    if (r) {
      const a = r.dataset.r;
      if (a === "back") history.back();
      else if (a === "toc") openToc();
      else if (a === "notes") openNotes();
      else if (a === "info") openInfo();
      else if (a === "search") openSearch();
      else if (a === "hadith") await openHadith();
      else if (a === "rs-run") await runSearch();
      else if (a === "rs-clear") { st.hl = ""; st.hlx = false; closeSheet(); show(st.index); }
      else if (a === "settings") await openSettings();
      else if (a === "prev") go(-1);
      else if (a === "next") go(1);
      else if (a === "close-sheet") closeSheet();
      else if (a === "to-text") { const n = r.dataset.fn; closeSheet(); scrollToRef(n); }
      else if (a === "fullscreen") await toggleFullscreen();
      else if (a === "reset") { st.settings = await settingsStore.reset(); apply(); show(st.index); await openSettings(); }
      else if (a === "size-down") await stepSize(-2);
      else if (a === "size-up") await stepSize(2);
      else if (a === "fonts") { await fontsReady; openSheet(t("reader.fontsTitle"), V.fontSheetInner(st.settings, st.fonts)); }
      else if (a === "bright") openSheet(t("reader.brightTitle"), V.brightnessInner(st.settings.dim));
      else if (a === "night") await quickNight();
      else if (a === "bookmark") await toggleBookmark();
      else if (a === "float-toggle") { st.floatCollapsed = !st.floatCollapsed; refreshFloat(); }
      return;
    }
    const nbtn = e.target.closest("[data-n]");
    if (nbtn && notesStore) {
      const act = nbtn.dataset.n, nid = nbtn.dataset.id;
      if (act === "go") { closeSheet(); show(Number(nbtn.dataset.index)); }
      else if (act === "add") {
        const fresh = st.lastQuote && Date.now() - st.lastQuoteAt < 30000;
        openEditor({ quote: fresh ? st.lastQuote : "" });
      } else if (act === "edit") {
        const n = notesStore.list(id).find((x) => x.id === nid);
        if (n) openEditor({ quote: n.quote, text: n.text, editingId: nid });
      } else if (act === "del") { await notesStore.remove(id, nid); refreshPageMarks(); openNotes(); }
      else if (act === "save") await saveNote();
      else if (act === "cancel") openNotes();
      return;
    }
    const hit = e.target.closest("[data-hit]");
    if (hit) { closeSheet(); show(Number(hit.dataset.hit)); return; }
    const tog = e.target.closest("[data-tog]");
    if (tog) { const n = Number(tog.dataset.tog); if (st.toc.expanded.has(n)) st.toc.expanded.delete(n); else st.toc.expanded.add(n); renderTocList(); return; }
    const all = e.target.closest("[data-toc-all]");
    if (all) { st.toc.expanded = all.dataset.tocAll === "expand" ? allWithChildren(st.toc.tree) : new Set(); renderTocList(); return; }
    const toc = e.target.closest("[data-toc]");
    if (toc) { closeSheet(); show(st.reader.indexOfPageId(Number(toc.dataset.page)), toc.dataset.toc); return; }
    const fontBtn = e.target.closest("[data-font]");
    if (fontBtn) { await change("font", fontBtn.dataset.font); openSheet(t("reader.fontsTitle"), V.fontSheetInner(st.settings, st.fonts)); return; }
    const seg = e.target.closest("[data-seg]");
    if (seg) { await change(seg.dataset.seg, seg.dataset.value); return; }
    const ay = e.target.closest(".ayah");
    if (ay) { openAyah(ay); return; }
    const pick = e.target.closest("[data-ayah]");
    if (pick) { const a = Number(pick.dataset.ayah); showAyah(a, a, "picked"); return; }
    const fn = e.target.closest(".fnref");
    if (fn) {
      const entry = st.entries.find((x) => String(x.n) === String(fn.dataset.fn));
      if (entry) openSheet("\u2066(" + fn.dataset.fn + ")\u2069", V.footnoteHtml(fn.dataset.fn, entry.text));
      return;
    }
    const jump = e.target.closest("[data-fnjump]");
    if (jump) { scrollToRef(jump.dataset.fnjump); return; }
    if (e.target === sheet) { closeSheet(); return; }
    if (scrollEl.contains(e.target) && String(window.getSelection()) === "") root.classList.toggle("bars-hidden");
  });

  root.addEventListener("keydown", (e) => { if (e.key === "Enter" && e.target.id === "rs-q") { e.preventDefault(); runSearch(); } });
  root.addEventListener("input", (e) => {
    if (e.target.id === "toc-filter") { st.toc.filter = e.target.value; renderTocList(); return; }
    if (e.target.matches && e.target.matches("[data-bright]")) {
      const out = e.target.parentElement.querySelector("output");
      if (out) out.textContent = e.target.value + "%";
      apply(sanitizeSettings({ ...st.settings, dim: 1 - Number(e.target.value) / 100 }));
      return;
    }
    const c = e.target.closest("[data-set]");
    if (c && c.type === "range") {
      const out = c.parentElement.querySelector("output");
      if (out) out.textContent = c.value;
      const patch = patchFromControl(c.dataset.set, c.value, false);
      if (patch) apply(sanitizeSettings({ ...st.settings, ...patch }));
    } else if (e.target === slider) {
      pos.textContent = t("reader.position", { i: Number(slider.value) + 1, n: st.reader.total });
    }
  });
  root.addEventListener("change", (e) => {
    if (e.target === slider) { show(Number(slider.value)); return; }
    if (e.target.matches && e.target.matches("[data-bright]")) { change("dim", 1 - Number(e.target.value) / 100); return; }
    const c = e.target.closest("[data-set]");
    if (c) change(c.dataset.set, c.value, c.checked);
  });

  let tx = 0, ty = 0;
  scrollEl.addEventListener("touchstart", (e) => { tx = e.changedTouches[0].clientX; ty = e.changedTouches[0].clientY; }, { passive: true });
  scrollEl.addEventListener("touchend", (e) => {
    const dir = swipeDirection(e.changedTouches[0].clientX - tx, e.changedTouches[0].clientY - ty);
    if (dir === "next") go(1); else if (dir === "prev") go(-1);
  }, { passive: true });

  // وقت القراءة: يُحتسب فقط والتطبيق ظاهر وخلال دقيقة من آخر لمسة
  if (statsStore) {
    const touch = () => { st.lastActive = Date.now(); };
    for (const ev of ["touchstart", "scroll", "click"]) root.addEventListener(ev, touch, { passive: true });
    st.tick = setInterval(() => { if (document.visibilityState === "visible" && Date.now() - st.lastActive < 60000) statsStore.addSeconds(id, 10); }, 10000);
    st.flushT = setInterval(() => statsStore.flush(), 30000);
  }

  const saved = await progressStore.load(id);
  let first = saved && saved.index < st.reader.total ? saved.index : 0;
  if (Number.isInteger(startIndex) && startIndex >= 0 && startIndex < st.reader.total) first = startIndex;
  show(first);
  if (st.settings.orientation !== "auto") applyOrientation();
  return api;
}
