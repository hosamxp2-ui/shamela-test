// ربط القارئ بالصفحة (DOM). المنطق الحسابي في ملفات نقية مختبرة:
// content.js، reader-engine.js، toc.js، gestures.js، notes.js، settings.js.
import { openReader } from "./reader-engine.js";
import { renderPage, esc } from "./content.js";
import { swipeDirection, clampIndex } from "./gestures.js";
import { buildTree, visibleRows, currentTitleId, initialExpanded, allWithChildren } from "./toc.js";
import { toCssVars, patchFromControl, sanitizeSettings, RANGES } from "../modules/settings.js";
import { detectFonts } from "../modules/fonts.js";
import { formatAdded } from "../modules/catalog.js";
import { SITE_BOOK_URL } from "../config.js";
import { fmtBytes } from "../components/views.js";
import * as V from "../components/reader-view.js";
import { t } from "../strings.js";

export async function mountReader({ container, id, catalog, dl, settingsStore, progressStore, themeManager, notesStore, toast = () => {}, startIndex = null }) {
  const book = catalog.getBook(id);
  container.innerHTML = V.readerShellHtml({ title: book ? book.name : "" });
  document.body.classList.add("reading");
  const root = container.querySelector("#reader");
  const $ = (s) => root.querySelector(s);
  const scrollEl = $("#r-scroll"), pageEl = $("#r-page"), sheet = $("#r-sheet"), slider = $("#r-slider"), pos = $("#r-pos");
  const st = {
    reader: null, index: 0, pageId: 0, page: null, settings: await settingsStore.load(), fonts: {}, entries: [],
    destroyed: false, saveTimer: null, floatCollapsed: false, lastQuote: "", lastQuoteAt: 0,
    toc: { tree: null, expanded: new Set(), filter: "" }
  };
  const fontsReady = detectFonts().then((f) => { st.fonts = f; return f; });
  const appTheme = () => (themeManager ? themeManager.effective() : "light");

  const apply = (s = st.settings) => { for (const [k, v] of Object.entries(toCssVars(s, appTheme()))) root.style.setProperty(k, v); };
  apply();
  const unsubTheme = themeManager ? themeManager.subscribe(() => apply()) : () => {};

  let ratio = 0, resizing = false, resizeTimer = null;
  const onScroll = () => { if (resizing) return; const h = scrollEl.scrollHeight - scrollEl.clientHeight; ratio = h > 0 ? scrollEl.scrollTop / h : 0; };
  const onResize = () => {
    resizing = true;
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => { const h = scrollEl.scrollHeight - scrollEl.clientHeight; scrollEl.scrollTop = ratio * h; setTimeout(() => { resizing = false; }, 60); }, 150);
  };
  const onSelection = () => {
    const sel = window.getSelection();
    const txt = sel ? String(sel).trim() : "";
    if (txt && sel.anchorNode && pageEl.contains(sel.anchorNode)) { st.lastQuote = txt.slice(0, 600); st.lastQuoteAt = Date.now(); }
  };
  scrollEl.addEventListener("scroll", onScroll, { passive: true });
  window.addEventListener("resize", onResize);
  document.addEventListener("selectionchange", onSelection);

  const closeSheet = () => { sheet.hidden = true; sheet.innerHTML = ""; };
  const api = { destroy: () => destroy(), closeSheet, sheetOpen: () => !sheet.hidden };

  function destroy() {
    if (st.destroyed) return;
    st.destroyed = true;
    clearTimeout(st.saveTimer);
    clearTimeout(resizeTimer);
    unsubTheme();
    window.removeEventListener("resize", onResize);
    document.removeEventListener("selectionchange", onSelection);
    if (st.reader) { progressStore.save(id, st.index, st.reader.total); st.reader.close(); }
    document.body.classList.remove("reading");
    try { if (document.fullscreenElement) document.exitFullscreen(); } catch (_) { /* لا شيء */ }
    try { screen.orientation.unlock(); } catch (_) { /* لا شيء */ }
  }

  try {
    st.reader = await openReader({ id, dl, catalog });
    if (notesStore) await notesStore.load(id);
  } catch (e) {
    const msg = e && e.name === "ConnectorError" ? e.message : t("err.generic", { message: (e && e.message) || String(e) });
    pageEl.innerHTML = `<p class="r-msg bad">${esc(msg)}</p>`;
    root.addEventListener("click", (ev) => { if (ev.target.closest('[data-r="back"]')) history.back(); });
    return api;
  }

  // ---------- الصفحة ----------
  const labelOf = (p) => [V.partLabel(p.part), p.page != null ? t("reader.page", { p: p.page }) : ""].filter(Boolean).join(" • ");
  const marks = () => (notesStore ? notesStore.pageMarks(id, st.index) : { bookmark: false, notes: 0 });

  function refreshFloat() {
    const el = $("#r-float");
    if (el) el.outerHTML = V.floatHtml({ bookmarked: marks().bookmark, collapsed: st.floatCollapsed });
  }

  const saveSoon = () => {
    clearTimeout(st.saveTimer);
    st.saveTimer = setTimeout(() => progressStore.save(id, st.index, st.reader.total), 500);
  };

  function show(index, anchor) {
    const p = st.reader.getPage(index);
    st.index = p.index; st.pageId = p.id; st.page = p;
    const r = renderPage(p, { showNotes: st.settings.showNotes });
    st.entries = r.entries;
    pageEl.innerHTML = V.pageHtmlWithMarks(p, r, marks());
    scrollEl.scrollTop = 0;
    if (anchor) { const el = pageEl.querySelector("#toc-" + anchor); if (el) el.scrollIntoView({ block: "start" }); }
    slider.max = String(st.reader.total - 1);
    slider.value = String(st.index);
    pos.textContent = t("reader.position", { i: st.index + 1, n: st.reader.total });
    refreshFloat();
    saveSoon();
  }
  const go = (delta) => { const i = clampIndex(st.index + delta, st.reader.total); if (i !== st.index) show(i); };

  const openSheet = (title, inner) => { sheet.innerHTML = V.sheetHtml(title, inner); sheet.hidden = false; };
  const openSettings = async () => { await fontsReady; openSheet(t("reader.settings"), V.settingsHtml(st.settings, st.fonts)); };

  function scrollToRef(n) {
    const el = pageEl.querySelector("#fnref-" + n);
    if (!el) return;
    el.scrollIntoView({ block: "center" });
    el.classList.add("flash");
    setTimeout(() => el.classList.remove("flash"), 1400);
  }

  async function applyOrientation() {
    const note = $("#r-note");
    try {
      if (st.settings.orientation === "auto") screen.orientation.unlock();
      else await screen.orientation.lock(st.settings.orientation);
      if (note) note.textContent = "";
    } catch (_) { if (note) note.textContent = t("reader.set.orientationFail"); }
  }

  async function toggleFullscreen() {
    try {
      if (document.fullscreenElement) await document.exitFullscreen();
      else await root.requestFullscreen();
    } catch (_) {
      root.classList.add("bars-hidden");
      const note = $("#r-note");
      if (note) note.textContent = t("reader.set.fullscreenFail");
    }
  }

  async function change(name, value, checked) {
    const patch = patchFromControl(name, value, checked);
    if (!patch) return;
    st.settings = await settingsStore.update(patch);
    apply();
    if (name === "showNotes") show(st.index);
    if (name === "orientation") { await openSettings(); await applyOrientation(); }
    else if (name === "theme" || name === "weight") { if (!sheet.hidden && sheet.querySelector("[data-seg]")) await openSettings(); }
  }

  // ---------- الفهرس الشجري ----------
  function renderTocList() {
    const list = $("#toc-list");
    if (!list) return;
    const cur = currentTitleId(st.reader.toc, st.pageId);
    list.innerHTML = V.tocListHtml(visibleRows(st.toc.tree, st.toc.expanded, st.toc.filter), cur);
  }
  function openToc() {
    st.toc.tree = buildTree(st.reader.toc);
    st.toc.filter = "";
    const cur = currentTitleId(st.reader.toc, st.pageId);
    st.toc.expanded = initialExpanded(st.toc.tree, cur);
    openSheet(t("reader.tb.toc"), st.reader.toc.length ? V.tocSheetInner() : `<p class="r-msg">${esc(t("reader.noToc"))}</p>`);
    if (!st.reader.toc.length) return;
    renderTocList();
    const row = sheet.querySelector("#toc-row-" + cur);
    if (row) row.scrollIntoView({ block: "center" });
  }

  // ---------- الإشارات والملاحظات ----------
  function openNotes() {
    openSheet(t("reader.notes.title"), V.notesSheetInner(notesStore ? notesStore.list(id) : []));
  }
  function openEditor({ quote = "", text = "", editingId = null } = {}) {
    st.editingId = editingId;
    st.editorQuote = quote;
    openSheet(t("reader.notes.editTitle"), V.noteEditorHtml({ quote, text, editing: !!editingId }));
    const ta = $("#note-text");
    if (ta) ta.focus();
  }
  async function saveNote() {
    const text = ($("#note-text").value || "").trim();
    let okSave;
    if (st.editingId) okSave = await notesStore.updateNote(id, st.editingId, text);
    else okSave = !!(await notesStore.addNote(id, { pageIndex: st.index, pageId: st.pageId, label: labelOf(st.page), text, quote: st.editorQuote }));
    if (!okSave) { const err = $("#note-err"); if (err) err.hidden = false; return; }
    st.lastQuote = ""; st.lastQuoteAt = 0;
    toast(t("reader.notes.saved"));
    refreshPageMarks();
    openNotes();
  }
  function refreshPageMarks() {
    const meta = pageEl.querySelector(".r-meta");
    if (meta) meta.innerHTML = esc(labelOf(st.page)) + " " + V.marksHtml(marks());
    refreshFloat();
  }
  async function toggleBookmark() {
    if (!notesStore) return;
    const r = await notesStore.toggleBookmark(id, { pageIndex: st.index, pageId: st.pageId, label: labelOf(st.page) });
    toast(r.on ? t("reader.notes.bookmarkOn") : t("reader.notes.bookmarkOff"));
    refreshPageMarks();
  }

  // ---------- معلومات الكتاب ----------
  function openInfo() {
    const entry = catalog.fileInfo(id);
    const cat = book ? catalog.getCategory(book.cat) : null;
    openSheet(t("reader.info.title"), V.infoHtml({
      authors: catalog.bookAuthorIds(id).map((a) => { const au = catalog.getAuthor(a); return { name: au ? au.name : "", death: au && au.death ? au.death : "" }; }),
      category: cat ? cat.name : "",
      pages: entry ? entry.pages : st.reader.total,
      titles: entry ? entry.titles : st.reader.toc.length,
      size: entry ? fmtBytes(entry.length) : "",
      rawSize: entry ? fmtBytes(entry.size) : "",
      added: book ? formatAdded(book.added) : "",
      url: SITE_BOOK_URL.replace("{id}", String(id))
    }));
  }

  async function quickNight() {
    const eff = st.settings.theme === "app" ? appTheme() : st.settings.theme === "custom" ? "light" : st.settings.theme;
    const app = themeManager ? themeManager.get() : { dayTheme: "light", nightTheme: "dark" };
    await change("theme", eff === "dark" || eff === "oled" ? app.dayTheme : app.nightTheme);
  }
  const stepSize = (d) => change("size", Math.min(RANGES.size[1], Math.max(RANGES.size[0], st.settings.size + d)));

  // ---------- الأحداث ----------
  root.addEventListener("click", async (e) => {
    const r = e.target.closest("[data-r]");
    if (r) {
      const a = r.dataset.r;
      if (a === "back") history.back();
      else if (a === "toc") openToc();
      else if (a === "notes") openNotes();
      else if (a === "info") openInfo();
      else if (a === "settings") await openSettings();
      else if (a === "prev") go(-1);
      else if (a === "next") go(1);
      else if (a === "close-sheet") closeSheet();
      else if (a === "to-text") { const n = r.dataset.fn; closeSheet(); scrollToRef(n); }
      else if (a === "fullscreen") await toggleFullscreen();
      else if (a === "reset") { st.settings = await settingsStore.reset(); apply(); show(st.index); await openSettings(); }
      else if (a === "size-down") await stepSize(-2);
      else if (a === "size-up") await stepSize(2);
      else if (a === "fonts") { await fontsReady; openSheet(t("reader.fontsTitle"), V.fontSheetInner(st.settings, st.fonts)); }
      else if (a === "bright") openSheet(t("reader.brightTitle"), V.brightnessInner(st.settings.dim));
      else if (a === "night") await quickNight();
      else if (a === "bookmark") await toggleBookmark();
      else if (a === "float-toggle") { st.floatCollapsed = !st.floatCollapsed; refreshFloat(); }
      return;
    }
    const nbtn = e.target.closest("[data-n]");
    if (nbtn && notesStore) {
      const act = nbtn.dataset.n, nid = nbtn.dataset.id;
      if (act === "go") { closeSheet(); show(Number(nbtn.dataset.index)); }
      else if (act === "add") {
        const fresh = st.lastQuote && Date.now() - st.lastQuoteAt < 30000;
        openEditor({ quote: fresh ? st.lastQuote : "" });
      } else if (act === "edit") {
        const n = notesStore.list(id).find((x) => x.id === nid);
        if (n) openEditor({ quote: n.quote, text: n.text, editingId: nid });
      } else if (act === "del") { await notesStore.remove(id, nid); refreshPageMarks(); openNotes(); }
      else if (act === "save") await saveNote();
      else if (act === "cancel") openNotes();
      return;
    }
    const tog = e.target.closest("[data-tog]");
    if (tog) { const n = Number(tog.dataset.tog); if (st.toc.expanded.has(n)) st.toc.expanded.delete(n); else st.toc.expanded.add(n); renderTocList(); return; }
    const all = e.target.closest("[data-toc-all]");
    if (all) { st.toc.expanded = all.dataset.tocAll === "expand" ? allWithChildren(st.toc.tree) : new Set(); renderTocList(); return; }
    const toc = e.target.closest("[data-toc]");
    if (toc) { closeSheet(); show(st.reader.indexOfPageId(Number(toc.dataset.page)), toc.dataset.toc); return; }
    const fontBtn = e.target.closest("[data-font]");
    if (fontBtn) { await change("font", fontBtn.dataset.font); openSheet(t("reader.fontsTitle"), V.fontSheetInner(st.settings, st.fonts)); return; }
    const seg = e.target.closest("[data-seg]");
    if (seg) { await change(seg.dataset.seg, seg.dataset.value); return; }
    const fn = e.target.closest(".fnref");
    if (fn) {
      const entry = st.entries.find((x) => String(x.n) === String(fn.dataset.fn));
      if (entry) openSheet("(" + fn.dataset.fn + ")", V.footnoteHtml(fn.dataset.fn, entry.text));
      return;
    }
    const jump = e.target.closest("[data-fnjump]");
    if (jump) { scrollToRef(jump.dataset.fnjump); return; }
    if (e.target === sheet) { closeSheet(); return; }
    if (scrollEl.contains(e.target) && String(window.getSelection()) === "") root.classList.toggle("bars-hidden");
  });

  root.addEventListener("input", (e) => {
    if (e.target.id === "toc-filter") { st.toc.filter = e.target.value; renderTocList(); return; }
    if (e.target.matches && e.target.matches("[data-bright]")) {
      const out = e.target.parentElement.querySelector("output");
      if (out) out.textContent = e.target.value + "%";
      apply(sanitizeSettings({ ...st.settings, dim: 1 - Number(e.target.value) / 100 }));
      return;
    }
    const c = e.target.closest("[data-set]");
    if (c && c.type === "range") {
      const out = c.parentElement.querySelector("output");
      if (out) out.textContent = c.value;
      const patch = patchFromControl(c.dataset.set, c.value, false);
      if (patch) apply(sanitizeSettings({ ...st.settings, ...patch }));
    } else if (e.target === slider) {
      pos.textContent = t("reader.position", { i: Number(slider.value) + 1, n: st.reader.total });
    }
  });
  root.addEventListener("change", (e) => {
    if (e.target === slider) { show(Number(slider.value)); return; }
    if (e.target.matches && e.target.matches("[data-bright]")) { change("dim", 1 - Number(e.target.value) / 100); return; }
    const c = e.target.closest("[data-set]");
    if (c) change(c.dataset.set, c.value, c.checked);
  });

  let tx = 0, ty = 0;
  scrollEl.addEventListener("touchstart", (e) => { tx = e.changedTouches[0].clientX; ty = e.changedTouches[0].clientY; }, { passive: true });
  scrollEl.addEventListener("touchend", (e) => {
    const dir = swipeDirection(e.changedTouches[0].clientX - tx, e.changedTouches[0].clientY - ty);
    if (dir === "next") go(1); else if (dir === "prev") go(-1);
  }, { passive: true });

  const saved = await progressStore.load(id);
  let first = saved && saved.index < st.reader.total ? saved.index : 0;
  if (Number.isInteger(startIndex) && startIndex >= 0 && startIndex < st.reader.total) first = startIndex;
  show(first);
  if (st.settings.orientation !== "auto") applyOrientation();
  return api;
}
