// ربط القارئ بالصفحة (DOM). المنطق الحسابي في ملفات نقية مختبرة: content.js وreader-engine.js وgestures.js.
import { openReader } from "./reader-engine.js";
import { renderPage, esc } from "./content.js";
import { swipeDirection, clampIndex } from "./gestures.js";
import { toCssVars, patchFromControl, sanitizeSettings } from "../modules/settings.js";
import { detectFonts } from "../modules/fonts.js";
import * as V from "../components/reader-view.js";
import { t } from "../strings.js";

export async function mountReader({ container, id, catalog, dl, settingsStore, progressStore, themeManager }) {
  const book = catalog.getBook(id);
  container.innerHTML = V.readerShellHtml({ title: book ? book.name : "" });
  document.body.classList.add("reading");
  const root = container.querySelector("#reader");
  const $ = (s) => root.querySelector(s);
  const scrollEl = $("#r-scroll"), pageEl = $("#r-page"), sheet = $("#r-sheet"), slider = $("#r-slider"), pos = $("#r-pos");
  const st = { reader: null, index: 0, settings: await settingsStore.load(), fonts: {}, entries: [], destroyed: false, saveTimer: null };
  const fontsReady = detectFonts().then((f) => { st.fonts = f; return f; });
  const appTheme = () => (themeManager ? themeManager.effective() : "light");

  const apply = (s = st.settings) => { for (const [k, v] of Object.entries(toCssVars(s, appTheme()))) root.style.setProperty(k, v); };
  apply();
  const unsubTheme = themeManager ? themeManager.subscribe(() => apply()) : () => {};
  let ratio = 0, resizing = false, resizeTimer = null;
  const onScroll = () => { if (resizing) return; const h = scrollEl.scrollHeight - scrollEl.clientHeight; ratio = h > 0 ? scrollEl.scrollTop / h : 0; };
  const onResize = () => {
    resizing = true;
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => { const h = scrollEl.scrollHeight - scrollEl.clientHeight; scrollEl.scrollTop = ratio * h; setTimeout(() => { resizing = false; }, 60); }, 150);
  };
  scrollEl.addEventListener("scroll", onScroll, { passive: true });
  window.addEventListener("resize", onResize);
  const api = { destroy: () => destroy(), closeSheet: () => { sheet.hidden = true; sheet.innerHTML = ""; }, sheetOpen: () => !sheet.hidden };

  const destroy = () => {
    if (st.destroyed) return;
    st.destroyed = true;
    clearTimeout(st.saveTimer);
    clearTimeout(resizeTimer);
    unsubTheme();
    window.removeEventListener("resize", onResize);
    if (st.reader) { progressStore.save(id, st.index, st.reader.total); st.reader.close(); }
    document.body.classList.remove("reading");
    try { if (document.fullscreenElement) document.exitFullscreen(); } catch (_) { /* لا شيء */ }
    try { screen.orientation.unlock(); } catch (_) { /* لا شيء */ }
  };

  try {
    st.reader = await openReader({ id, dl, catalog });
  } catch (e) {
    const msg = e && e.name === "ConnectorError" ? e.message : t("err.generic", { message: (e && e.message) || String(e) });
    pageEl.innerHTML = `<p class="r-msg bad">${esc(msg)}</p>`;
    root.addEventListener("click", (ev) => { if (ev.target.closest('[data-r="back"]')) history.back(); });
    return api;
  }

  const saveSoon = () => {
    clearTimeout(st.saveTimer);
    st.saveTimer = setTimeout(() => progressStore.save(id, st.index, st.reader.total), 500);
  };

  function show(index, anchor) {
    const p = st.reader.getPage(index);
    st.index = p.index;
    const r = renderPage(p, { showNotes: st.settings.showNotes });
    st.entries = r.entries;
    pageEl.innerHTML = V.pageHtml(p, r);
    scrollEl.scrollTop = 0;
    if (anchor) { const el = pageEl.querySelector("#toc-" + anchor); if (el) el.scrollIntoView({ block: "start" }); }
    slider.max = String(st.reader.total - 1);
    slider.value = String(st.index);
    pos.textContent = t("reader.position", { i: st.index + 1, n: st.reader.total });
    saveSoon();
  }
  const go = (delta) => { const i = clampIndex(st.index + delta, st.reader.total); if (i !== st.index) show(i); };

  const closeSheet = () => { sheet.hidden = true; sheet.innerHTML = ""; };
  const openSheet = (title, inner) => { sheet.innerHTML = V.sheetHtml(title, inner); sheet.hidden = false; };
  const openSettings = async () => { await fontsReady; openSheet(t("reader.settings"), V.settingsHtml(st.settings, st.fonts)); };

  function scrollToRef(n) {
    const el = pageEl.querySelector("#fnref-" + n);
    if (!el) return;
    el.scrollIntoView({ block: "center" });
    el.classList.add("flash");
    setTimeout(() => el.classList.remove("flash"), 1400);
  }

  async function applyOrientation() {
    const note = $("#r-note");
    try {
      if (st.settings.orientation === "auto") screen.orientation.unlock();
      else await screen.orientation.lock(st.settings.orientation);
      if (note) note.textContent = "";
    } catch (_) { if (note) note.textContent = t("reader.set.orientationFail"); }
  }

  async function toggleFullscreen() {
    try {
      if (document.fullscreenElement) await document.exitFullscreen();
      else await root.requestFullscreen();
    } catch (_) {
      root.classList.add("bars-hidden");
      const note = $("#r-note");
      if (note) note.textContent = t("reader.set.fullscreenFail");
    }
  }

  async function change(name, value, checked) {
    const patch = patchFromControl(name, value, checked);
    if (!patch) return;
    st.settings = await settingsStore.update(patch);
    apply();
    if (name === "showNotes") show(st.index);
    if (name === "orientation") { await openSettings(); await applyOrientation(); }
    else if (name === "theme" || name === "weight") await openSettings();
  }

  root.addEventListener("click", async (e) => {
    const r = e.target.closest("[data-r]");
    if (r) {
      const a = r.dataset.r;
      if (a === "back") history.back();
      else if (a === "toc") openSheet(t("reader.toc"), V.tocHtml(st.reader.toc));
      else if (a === "settings") await openSettings();
      else if (a === "prev") go(-1);
      else if (a === "next") go(1);
      else if (a === "close-sheet") closeSheet();
      else if (a === "to-text") { const n = r.dataset.fn; closeSheet(); scrollToRef(n); }
      else if (a === "fullscreen") await toggleFullscreen();
      else if (a === "reset") { st.settings = await settingsStore.reset(); apply(); show(st.index); await openSettings(); }
      return;
    }
    const toc = e.target.closest("[data-toc]");
    if (toc) { closeSheet(); show(st.reader.indexOfPageId(Number(toc.dataset.page)), toc.dataset.toc); return; }
    const seg = e.target.closest("[data-seg]");
    if (seg) { await change(seg.dataset.seg, seg.dataset.value); return; }
    const fn = e.target.closest(".fnref");
    if (fn) {
      const entry = st.entries.find((x) => String(x.n) === String(fn.dataset.fn));
      if (entry) openSheet("(" + fn.dataset.fn + ")", V.footnoteHtml(fn.dataset.fn, entry.text));
      return;
    }
    const jump = e.target.closest("[data-fnjump]");
    if (jump) { scrollToRef(jump.dataset.fnjump); return; }
    if (e.target === sheet) { closeSheet(); return; }
    if (scrollEl.contains(e.target) && String(window.getSelection()) === "") root.classList.toggle("bars-hidden");
  });

  // المعاينة أثناء سحب المنزلق، والحفظ عند الإفلات (change)
  root.addEventListener("input", (e) => {
    const c = e.target.closest("[data-set]");
    if (c && c.type === "range") {
      const out = c.parentElement.querySelector("output");
      if (out) out.textContent = c.value;
      const patch = patchFromControl(c.dataset.set, c.value, false);
      if (patch) apply(sanitizeSettings({ ...st.settings, ...patch }));
    } else if (e.target === slider) {
      pos.textContent = t("reader.position", { i: Number(slider.value) + 1, n: st.reader.total });
    }
  });
  root.addEventListener("change", (e) => {
    if (e.target === slider) { show(Number(slider.value)); return; }
    const c = e.target.closest("[data-set]");
    if (c) change(c.dataset.set, c.value, c.checked);
  });

  let tx = 0, ty = 0;
  scrollEl.addEventListener("touchstart", (e) => { tx = e.changedTouches[0].clientX; ty = e.changedTouches[0].clientY; }, { passive: true });
  scrollEl.addEventListener("touchend", (e) => {
    const dir = swipeDirection(e.changedTouches[0].clientX - tx, e.changedTouches[0].clientY - ty);
    if (dir === "next") go(1); else if (dir === "prev") go(-1);
  }, { passive: true });

  const saved = await progressStore.load(id);
  show(saved && saved.index < st.reader.total ? saved.index : 0);
  if (st.settings.orientation !== "auto") applyOrientation();
  return api;
}
