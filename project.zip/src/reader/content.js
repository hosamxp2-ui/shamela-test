// معالجة نص الصفحة: تنظيف HTML (قائمة بيضاء)، تقسيم الفقرات، وربط إشارات الهوامش (١) بنصوصها.
// تنسيق الشاملة (من فحص كتاب حقيقي): body نص مع وسم span للعناوين فقط، وfoot نص فيه (١) (٢)...
const ALLOWED = new Set(["span", "b", "strong", "i", "em", "u", "sup", "sub", "br", "small", "mark"]);
const VOID = new Set(["br"]);

export const esc = (s) =>
  String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

export function toWestern(s) {
  return String(s).replace(/[٠-٩۰-۹]/g, (ch) => {
    const c = ch.charCodeAt(0);
    return String(c - (c >= 0x6f0 ? 0x6f0 : 0x660));
  });
}
const toArabicDigits = (s) => String(s).replace(/[0-9]/g, (d) => "٠١٢٣٤٥٦٧٨٩"[Number(d)]);

function cleanAttrs(raw) {
  const out = [];
  for (const m of String(raw).matchAll(/([\w:-]+)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'>]+))/g)) {
    const name = m[1].toLowerCase();
    const val = m[2] != null ? m[2] : m[3] != null ? m[3] : m[4];
    if (name === "data-type" && /^[\w-]{1,30}$/.test(val)) out.push(`data-type="${val}"`);
    else if (name === "id" && /^[\w-]{1,40}$/.test(val)) out.push(`id="${val}"`);
    else if (name === "class" && /^[\w\s-]{1,60}$/.test(val)) out.push(`class="${val}"`);
  }
  return out.length ? " " + out.join(" ") : "";
}

// يترك الأوسمة المسموحة فقط ويهرّب كل ما عداها. يعيد HTML متوازن الأوسمة.
export function sanitize(html) {
  let src = String(html == null ? "" : html)
    .replace(/<!--[\s\S]*?-->/g, "")
    .replace(/<(script|style)[^>]*>[\s\S]*?<\/\1\s*>/gi, "");
  const stack = [];
  let out = "";
  const re = /<(\/?)([a-zA-Z][\w-]*)([^>]*)>|([^<]+)|</g;
  let m;
  while ((m = re.exec(src))) {
    if (m[4] != null) { out += esc(m[4]); continue; }
    if (m[0] === "<") { out += "&lt;"; continue; }
    const closing = m[1] === "/";
    const tag = m[2].toLowerCase();
    if (!ALLOWED.has(tag)) continue;
    if (closing) {
      const i = stack.lastIndexOf(tag);
      if (i >= 0) { while (stack.length > i) out += `</${stack.pop()}>`; }
    } else if (VOID.has(tag)) {
      out += "<br>";
    } else {
      out += `<${tag}${cleanAttrs(m[3])}>`;
      stack.push(tag);
    }
  }
  while (stack.length) out += `</${stack.pop()}>`;
  return out;
}

// يغلق الأوسمة المفتوحة ويتجاهل الإغلاق الشارد في مقطع واحد (سطر)
function balance(piece) {
  const stack = [];
  let out = "";
  for (const m of piece.matchAll(/<(\/?)([a-z]+)([^>]*)>|([^<]+)/g)) {
    if (m[4] != null) { out += m[4]; continue; }
    const tag = m[2];
    if (m[1] === "/") { const i = stack.lastIndexOf(tag); if (i >= 0) { while (stack.length > i) out += `</${stack.pop()}>`; } }
    else if (tag === "br") out += "<br>";
    else { out += m[0]; stack.push(tag); }
  }
  while (stack.length) out += `</${stack.pop()}>`;
  return out;
}

export function toParagraphs(cleanHtml) {
  const parts = String(cleanHtml).split(/\r?\n+/).map((p) => p.trim()).filter(Boolean);
  return parts.map((p) => balance(p));
}

// يستخرج مدخلات الهوامش من نص foot. الرقم يُقبل فقط إن كان تاليًا للسابق (يتجاهل أرقامًا شاردة داخل النص).
export function parseFootnotes(foot) {
  const text = String(foot == null ? "" : foot);
  if (!text.trim()) return [];
  const re = /\(\s*([٠-٩۰-۹0-9]{1,3})\s*\)/g;
  const marks = [];
  let expect = null, m;
  while ((m = re.exec(text))) {
    const n = Number(toWestern(m[1]));
    if (expect === null || n === expect) { marks.push({ n, start: m.index, end: m.index + m[0].length }); expect = n + 1; }
  }
  const entries = [];
  const lead = text.slice(0, marks.length ? marks[0].start : text.length).trim();
  if (lead) entries.push({ n: null, text: lead });
  marks.forEach((mk, i) => {
    entries.push({ n: mk.n, text: text.slice(mk.end, i + 1 < marks.length ? marks[i + 1].start : text.length).trim() });
  });
  return entries;
}

// يستبدل أول (N) في المتن لكل هامش موجود بإشارة قابلة للنقر. يعيد { html, linked: Set }
export function linkFootnotes(paragraphs, entries) {
  const known = new Set(entries.filter((e) => e.n != null).map((e) => e.n));
  const used = new Set();
  const html = paragraphs.map((p) =>
    p.replace(/\(\s*([٠-٩۰-۹0-9]{1,3})\s*\)/g, (whole, digits) => {
      const n = Number(toWestern(digits));
      if (!known.has(n) || used.has(n)) return whole;
      used.add(n);
      return `<sup class="fnref" id="fnref-${n}" data-fn="${n}">(${toArabicDigits(n)})</sup>`;
    }));
  return { html, linked: used };
}

export function renderPage(row, { showNotes = true } = {}) {
  const paragraphs = toParagraphs(sanitize(row.body));
  const entries = parseFootnotes(row.foot);
  const { html, linked } = linkFootnotes(paragraphs, entries);
  const body = html.map((p) => `<p>${p}</p>`).join("");
  const notes = entries.length
    ? entries.map((e) => `<li id="fn-${e.n == null ? "x" : e.n}" data-fn="${e.n == null ? "" : e.n}">${e.n != null ? `<a class="fnnum" data-fnjump="${e.n}">(${toArabicDigits(e.n)})</a> ` : ""}${esc(e.text)}</li>`).join("")
    : "";
  return {
    bodyHtml: body || "<p></p>",
    notesHtml: showNotes && notes ? `<ol class="notes">${notes}</ol>` : "",
    entries,
    linked
  };
}
