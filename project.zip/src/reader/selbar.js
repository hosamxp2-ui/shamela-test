// موضع شريط «تظليل / ملاحظة» العائم قرب النص المحدد. rect: DOMRect للتحديد، (vw, vh): أبعاد الشاشة.
// الافتراضي تحت التحديد بمسافة تتّسع لمقبضَي التحديد الأصليين؛ وإن ضاق المكان فوق الشريط السفلي يُنقل فوق التحديد.
// left يمثّل مركز الشريط (يُطبَّق مع translateX(-50%))، ويُقيَّد كي لا يخرج من الشاشة.
export function selBarPosition(rect, vw, vh, { barW = 200, below = 48, above = 100, bottomReserve = 190, topMin = 120 } = {}) {
  const half = barW / 2;
  const left = Math.min(Math.max((rect.left + rect.right) / 2, half + 8), Math.max(half + 8, vw - half - 8));
  let top = rect.bottom + below;
  if (top > vh - bottomReserve) top = rect.top - above;
  top = Math.min(Math.max(top, topMin), vh - bottomReserve);
  return { left: Math.round(left), top: Math.round(top) };
}
