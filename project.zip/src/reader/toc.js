// فهرس العناوين كشجرة قابلة للطي (دوال نقية).
import { normalizeArabic } from "../modules/arabic.js";

export function buildTree(toc) {
  const byId = new Map(toc.map((x) => [x.id, { ...x, children: [] }]));
  const roots = [];
  for (const n of byId.values()) {
    const p = byId.get(n.parent);
    if (p && p !== n) p.children.push(n); else roots.push(n);
  }
  // عناصر عالقة في دورة (أب يشير لابنه) تُعرض كجذور بدل أن تضيع
  const seen = new Set();
  const mark = (n, d) => { if (seen.has(n.id) || d > 30) return; seen.add(n.id); n.children.forEach((c) => mark(c, d + 1)); };
  roots.forEach((r) => mark(r, 0));
  for (const n of byId.values()) if (!seen.has(n.id)) { roots.push(n); mark(n, 0); }
  return { roots, byId };
}

// يرتّب الصفوف الظاهرة: شجرة حسب المفتوح، أو قائمة مسطّحة إن وُجد نص بحث
export function visibleRows(tree, expanded, filter = "") {
  const words = normalizeArabic(filter).split(" ").filter(Boolean);
  const rows = [];
  if (words.length) {
    const walk = (n, depth, guard) => {
      if (guard.has(n.id) || depth > 12) return;
      guard.add(n.id);
      const norm = normalizeArabic(n.text);
      if (words.every((w) => norm.includes(w))) rows.push({ id: n.id, page: n.page, text: n.text, depth, hasChildren: false, expanded: false });
      n.children.forEach((c) => walk(c, depth + 1, guard));
    };
    const guard = new Set();
    tree.roots.forEach((r) => walk(r, 0, guard));
    return rows;
  }
  const walk = (n, depth, guard) => {
    if (guard.has(n.id) || depth > 12) return;
    guard.add(n.id);
    const open = expanded.has(n.id);
    rows.push({ id: n.id, page: n.page, text: n.text, depth, hasChildren: n.children.length > 0, expanded: open });
    if (open) n.children.forEach((c) => walk(c, depth + 1, guard));
  };
  const guard = new Set();
  tree.roots.forEach((r) => walk(r, 0, guard));
  return rows;
}

// العنوان الحالي: آخر عنوان تبدأ صفحته عند الصفحة الحالية أو قبلها
export function currentTitleId(toc, pageId) {
  let best = null;
  for (const x of toc) {
    if (x.page <= pageId && (!best || x.page > best.page || (x.page === best.page && x.id > best.id))) best = x;
  }
  return best ? best.id : null;
}

export function ancestorIds(tree, id) {
  const out = [];
  let n = tree.byId.get(id);
  const seen = new Set();
  while (n && n.parent && !seen.has(n.id)) {
    seen.add(n.id);
    const p = tree.byId.get(n.parent);
    if (!p || p === n) break;
    out.push(p.id);
    n = p;
  }
  return out;
}

// يفتح الكل إن كان الفهرس صغيرًا، وإلا يفتح مسار العنوان الحالي فقط
export function initialExpanded(tree, currentId, smallLimit = 40) {
  if (tree.byId.size <= smallLimit) return new Set([...tree.byId.keys()]);
  return new Set(currentId == null ? [] : ancestorIds(tree, currentId));
}

export const allWithChildren = (tree) => new Set([...tree.byId.values()].filter((n) => n.children.length).map((n) => n.id));
