// محوّل مصدر البيانات (Data Adapter). لتغيير المصدر مستقبلًا اكتب محوّلًا بنفس الواجهة:
//   manifest()            -> كائن البيانات الوصفية
//   master(manifest)      -> بايتات master.db بعد فك الضغط
//   index(manifest)       -> كائن index.json
//   bookBytes(manifest, entry) -> بايتات قاعدة الكتاب بعد التحقق وفك الضغط
import { SOURCE } from "../config.js";
import { getBytes, getRange, gunzip, sha256Hex, ConnectorError } from "./data-connector.js";
import { request } from "./data-connector.js";
import { t } from "../strings.js";

const utf8 = (u8) => new TextDecoder("utf-8").decode(u8);

export const source = {
  id: SOURCE.id,

  async manifest() {
    const res = await request(SOURCE.manifestUrl);
    return JSON.parse(utf8(res.body));
  },

  async master(manifest) {
    const m = manifest.data.master;
    return gunzip(await getBytes(m.url, { sha256: m.sha256 }));
  },

  async index(manifest) {
    const i = manifest.data.index;
    return JSON.parse(utf8(await getBytes(i.url, { sha256: i.sha256 })));
  },

  async bookBytes(manifest, entry) {
    const pack = manifest.data.packs[entry.pack];
    const stored = await getRange(pack.url, entry.offset, entry.length, { expectedSize: pack.size });
    // sha256 في الفهرس محسوب على البايتات المخزّنة (المضغوطة)
    if ((await sha256Hex(stored)) !== entry.sha256) throw new ConnectorError("SHA", t("err.sha"));
    return gunzip(stored);
  }
};
