// الاتصال بالخادم عبر CapacitorHttp الأصلي (المتصفح لا يستطيع بسبب CORS).
// قاعدة مثبتة بالاختبار: أول طلب لكل رابط على Synology يعيد صفحة HTML ثم ينجح الثاني،
// لذلك نعيد المحاولة تلقائيًا عند وصول text/html بدل الملف.
import { t } from "../strings.js";

export class ConnectorError extends Error {
  constructor(code, message) { super(message); this.name = "ConnectorError"; this.code = code; }
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function plugin() {
  const P = globalThis.Capacitor && globalThis.Capacitor.Plugins && globalThis.Capacitor.Plugins.CapacitorHttp;
  if (!P) throw new ConnectorError("NOT_NATIVE", t("err.notNative"));
  return P;
}

export function headerGet(headers, name) {
  const key = Object.keys(headers || {}).find((k) => k.toLowerCase() === name.toLowerCase());
  return key ? String(headers[key]) : "";
}

function b64ToU8(b64) {
  const bin = atob(b64);
  const u8 = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
  return u8;
}

async function once(url, method, headers) {
  let res;
  try {
    res = await plugin().request({
      url, method, headers: headers || {},
      responseType: method === "HEAD" ? "text" : "blob",
      connectTimeout: 30000, readTimeout: 120000
    });
  } catch (e) {
    if (e instanceof ConnectorError) throw e;
    throw new ConnectorError("NETWORK", t("err.network"));
  }
  return {
    status: res.status,
    headers: res.headers || {},
    body: method === "HEAD" ? new Uint8Array(0) : b64ToU8(res.data || "")
  };
}

export async function request(url, { method = "GET", headers = {}, retries = 2, retryDelay = 800 } = {}) {
  for (let attempt = 0; attempt <= retries; attempt++) {
    const last = attempt === retries;
    let res;
    try {
      res = await once(url, method, headers);
    } catch (e) {
      if (e.code === "NETWORK" && !last) { await sleep(retryDelay + 400); continue; }
      throw e;
    }
    if (/text\/html/i.test(headerGet(res.headers, "content-type"))) {
      if (!last) { await sleep(retryDelay); continue; }
      throw new ConnectorError("SERVER_PAGE", t("err.serverPage"));
    }
    if (res.status >= 400) throw new ConnectorError("HTTP", t("err.http", { status: res.status }));
    return res;
  }
  throw new ConnectorError("SERVER_PAGE", t("err.serverPage"));
}

export async function sha256Hex(u8) {
  const digest = await crypto.subtle.digest("SHA-256", u8);
  return Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

export async function gunzip(u8) {
  const stream = new Blob([u8]).stream().pipeThrough(new DecompressionStream("gzip"));
  return new Uint8Array(await new Response(stream).arrayBuffer());
}

// يفك بداية ملف gzip مقطوع: يعيد ما أمكن فكّه قبل نهاية البيانات (للفحص فقط، لا للتخزين)
export async function gunzipPartial(u8) {
  // DecompressionStream في Chrome يتوقف عند نهاية أول "عضو" gzip؛ ملفات services/tashkeel متعددة الأعضاء، فنفضّل fflate
  const ff = globalThis.fflate;
  if (ff && ff.Gunzip) {
    const parts = [];
    let n = 0;
    try {
      const gz = new ff.Gunzip((c) => { parts.push(new Uint8Array(c)); n += c.length; });
      try { gz.push(u8, true); } catch (_) { /* نهاية مقطوعة: متوقع */ }
    } catch (_) { /* نعود للطريقة الأصلية */ }
    if (n > 0) {
      const out = new Uint8Array(n);
      let p = 0;
      for (const c of parts) { out.set(c, p); p += c.length; }
      return out;
    }
  }
  const ds = new DecompressionStream("gzip");
  const writer = ds.writable.getWriter();
  const reader = ds.readable.getReader();
  writer.write(u8).catch(() => {});
  writer.close().catch(() => {});
  const chunks = [];
  let total = 0;
  try {
    for (;;) {
      const { value, done } = await reader.read();
      if (done) break;
      chunks.push(value);
      total += value.length;
    }
  } catch (_) { /* انتهاء البيانات قبل اكتمال التيار: متوقع */ }
  const out = new Uint8Array(total);
  let pos = 0;
  for (const c of chunks) { out.set(c, pos); pos += c.length; }
  return out;
}

export async function getBytes(url, { sha256 } = {}) {
  const res = await request(url);
  if (sha256 && (await sha256Hex(res.body)) !== sha256) throw new ConnectorError("SHA", t("err.sha"));
  return res.body;
}

// بوابة أمان: لا نطلب جزءًا من ملف ضخم قبل التأكد من دعم Range وحجمه المتوقع.
const rangeChecked = new Map();
export async function assertRangeSupport(url, expectedSize) {
  if (rangeChecked.get(url) === expectedSize) return;
  const res = await request(url, { method: "HEAD", retries: 3 });
  const ranges = headerGet(res.headers, "accept-ranges").toLowerCase().includes("bytes");
  const size = Number(headerGet(res.headers, "content-length"));
  if (!ranges || size !== expectedSize) throw new ConnectorError("NO_RANGE", t("err.noRange"));
  rangeChecked.set(url, expectedSize);
}

export async function getRange(url, offset, length, { expectedSize }) {
  await assertRangeSupport(url, expectedSize);
  const res = await request(url, { headers: { Range: `bytes=${offset}-${offset + length - 1}` } });
  if (res.status !== 206 || res.body.length !== length) throw new ConnectorError("RANGE", t("err.range"));
  return res.body;
}
