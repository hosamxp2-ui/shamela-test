// يقرأ بنية ملف SQLite أثناء تدفقه صفحةً صفحة (بلا تحميله كله في الذاكرة): يحصي صفوف كل جدول
// وأحجام الجداول والفهارس، ويلتقط عينة من أول صف في كل جدول. للاستكشاف قبل تصميم الاستيراد.
// ما لا يغطيه: صفحات التجاوز (overflow) لا تُحصى ضمن أحجام الجداول، وقيم النصوص الطويلة تُقتطع.

export function readVarint(b, pos) {
  let v = 0;
  for (let i = 0; i < 8; i++) {
    const c = b[pos + i];
    if (c === undefined) return { value: NaN, len: i };
    v = v * 128 + (c & 0x7f);
    if (!(c & 0x80)) return { value: v, len: i + 1 };
  }
  const c9 = b[pos + 8];
  return { value: v * 256 + (c9 === undefined ? 0 : c9), len: 9 };
}

const SHORT = 60;
const dec = new TextDecoder("utf-8", { fatal: false });

// يفك سجلًا (record) من b[pos..end). القيم الممتدة خارج end (تجاوز) تُوسَم "…"
export function decodeRecord(b, pos, end) {
  const h = readVarint(b, pos);
  if (!Number.isFinite(h.value)) return [];
  const hdrEnd = pos + h.value;
  let p = pos + h.len;
  const types = [];
  while (p < hdrEnd && p < end) { const t = readVarint(b, p); if (!Number.isFinite(t.value)) break; types.push(t.value); p += t.len; }
  const out = [];
  let d = hdrEnd;
  for (const t of types) {
    let len = 0;
    if (t === 0 || t === 8 || t === 9) len = 0; else if (t <= 4) len = t; else if (t === 5) len = 6; else if (t === 6 || t === 7) len = 8; else len = (t - (t % 2 ? 13 : 12)) / 2;
    if (d + len > end) { out.push("…"); break; }
    if (t === 0) out.push(null);
    else if (t === 8) out.push(0);
    else if (t === 9) out.push(1);
    else if (t >= 1 && t <= 6) {
      let v = 0n;
      for (let i = 0; i < len; i++) v = (v << 8n) | BigInt(b[d + i]);
      const bits = BigInt(len * 8);
      if (v >= 1n << (bits - 1n)) v -= 1n << bits;
      out.push(Number(v));
    } else if (t === 7) out.push(new DataView(b.buffer, b.byteOffset + d, 8).getFloat64(0));
    else if (t >= 12 && t % 2 === 0) out.push(new Uint8Array(b.subarray(d, d + len)));
    else out.push(dec.decode(b.subarray(d, d + len)));
    d += len;
  }
  return out;
}

const show = (v) => {
  if (v === null) return "NULL";
  if (v instanceof Uint8Array) return "<blob " + v.length + ">";
  const s = String(v).replace(/\s+/g, " ");
  return s.length > SHORT ? s.slice(0, SHORT) + "…" : s;
};

export function createScanner({ keepPages = 1500 } = {}) {
  let pageSize = 0, usable = 0, carry = new Uint8Array(0), count = 0;
  const types = [], cells = [], children = new Map(), samples = new Map(), kept = new Map();

  function localLen(payload, maxLocal, minLocal) {
    if (payload <= maxLocal) return payload;
    let l = minLocal + ((payload - minLocal) % (usable - 4));
    if (l > maxLocal) l = minLocal;
    return l;
  }

  function handlePage(n, page) {
    if (n <= keepPages) kept.set(n, new Uint8Array(page));
    const off = n === 1 ? 100 : 0;
    const type = page[off];
    const u16 = (o) => (page[o] << 8) | page[o + 1];
    const u32 = (o) => page[o] * 16777216 + (page[o + 1] << 16) + (page[o + 2] << 8) + page[o + 3];
    if (type !== 0x0d && type !== 0x0a && type !== 0x05 && type !== 0x02) return; // تجاوز/قائمة حرة/غيرها
    types[n] = type;
    const cellCount = u16(off + 3);
    cells[n] = cellCount;
    if (type === 0x05 || type === 0x02) {
      const list = [];
      for (let i = 0; i < cellCount; i++) list.push(u32(u16(off + 12 + i * 2)));
      list.push(u32(off + 8));
      children.set(n, list);
    } else if (type === 0x0d && cellCount > 0) {
      try {
        const c = u16(off + 8);
        const ps = readVarint(page, c);
        const rid = readVarint(page, c + ps.len);
        const start = c + ps.len + rid.len;
        const maxLocal = usable - 35, minLocal = Math.floor(((usable - 12) * 32) / 255) - 23;
        const local = localLen(ps.value, maxLocal, minLocal);
        samples.set(n, decodeRecord(page, start, Math.min(start + local, page.length)).map(show).join(" | "));
      } catch (_) { /* لا عينة */ }
    }
  }

  function push(chunk) {
    let data = chunk;
    if (carry.length) { const m = new Uint8Array(carry.length + data.length); m.set(carry); m.set(data, carry.length); data = m; carry = new Uint8Array(0); }
    if (!pageSize) {
      if (data.length < 100) { carry = data; return; }
      pageSize = (data[16] << 8) | data[17];
      if (pageSize === 1) pageSize = 65536;
      usable = pageSize - data[20];
    }
    let pos = 0;
    while (pos + pageSize <= data.length) { count++; handlePage(count, data.subarray(pos, pos + pageSize)); pos += pageSize; }
    if (pos < data.length) carry = new Uint8Array(data.subarray(pos));
  }

  // يستخرج صفوف sqlite_master من الصفحات المحفوظة (الصفحة 1 وأبناؤها)
  function readMaster() {
    const rows = [], notes = [];
    const visit = (n, depth) => {
      if (depth > 6) return;
      const page = kept.get(n);
      if (!page) { notes.push("صفحة التعريفات " + n + " خارج الصفحات المحفوظة"); return; }
      const off = n === 1 ? 100 : 0;
      const type = page[off];
      const cc = (page[off + 3] << 8) | page[off + 4];
      if (type === 0x05) {
        for (let i = 0; i < cc; i++) { const p = (page[off + 12 + i * 2] << 8) | page[off + 13 + i * 2]; visit(page[p] * 16777216 + (page[p + 1] << 16) + (page[p + 2] << 8) + page[p + 3], depth + 1); }
        visit(page[off + 8] * 16777216 + (page[off + 9] << 16) + (page[off + 10] << 8) + page[off + 11], depth + 1);
      } else if (type === 0x0d) {
        for (let i = 0; i < cc; i++) {
          const c = (page[off + 8 + i * 2] << 8) | page[off + 9 + i * 2];
          const ps = readVarint(page, c), rid = readVarint(page, c + ps.len), start = c + ps.len + rid.len;
          const local = localLen(ps.value, usable - 35, Math.floor(((usable - 12) * 32) / 255) - 23);
          const r = decodeRecord(page, start, Math.min(start + local, page.length));
          if (r.length >= 4) rows.push({ type: r[0], name: r[1], tbl: r[2], root: r[3], sql: typeof r[4] === "string" ? r[4] : "" });
        }
      }
    };
    visit(1, 0);
    return { rows, notes };
  }

  function walk(root) {
    const out = { pages: 0, leaf: 0, rows: 0, sample: "" };
    if (!root || !types[root]) return out;
    const seen = new Set();
    const stack = [root];
    while (stack.length) {
      const p = stack.pop();
      if (!p || seen.has(p) || !types[p]) continue;
      seen.add(p);
      out.pages++;
      const t = types[p];
      if (t === 0x05 || t === 0x02) {
        if (t === 0x02) out.rows += cells[p] || 0; // في أشجار الفهارس تحمل العقد الداخلية مدخلات فعلية أيضًا
        const ch = children.get(p) || [];
        for (let i = ch.length - 1; i >= 0; i--) stack.push(ch[i]);
      }
      else { out.leaf++; out.rows += cells[p] || 0; if (!out.sample && samples.has(p)) out.sample = samples.get(p); }
    }
    return out;
  }

  function finish() {
    const { rows, notes } = readMaster();
    const objects = rows.map((r) => ({ ...r, ...(r.root > 0 ? walk(r.root) : { pages: 0, leaf: 0, rows: 0, sample: "" }) }));
    return { pageSize, pagesRead: count, partialBytes: carry.length, objects, notes };
  }

  return { push, finish, get pageSize() { return pageSize; }, get pagesRead() { return count; } };
}

export function reportLines(rep, { topIndexes = 12 } = {}) {
  const mb = (p) => ((p * rep.pageSize) / 1048576).toFixed(1);
  const lines = [];
  lines.push("حجم الصفحة " + rep.pageSize + " | الصفحات المقروءة " + rep.pagesRead + " (~" + mb(rep.pagesRead) + " MB)");
  for (const n of rep.notes) lines.push("ملاحظة: " + n);
  const tables = rep.objects.filter((o) => o.type === "table" && o.root > 0).sort((a, b) => b.pages - a.pages);
  lines.push("");
  lines.push("## الجداول (مرتبة بالحجم)");
  for (const o of tables) {
    lines.push("- " + o.name + ": " + o.rows + " صف، ~" + mb(o.pages) + " MB (" + o.pages + " صفحة)");
    lines.push("    " + o.sql.replace(/\s+/g, " ").slice(0, 200));
    if (o.sample) lines.push("    عينة: " + o.sample);
  }
  const idx = rep.objects.filter((o) => o.type === "index" && o.root > 0).sort((a, b) => b.pages - a.pages).slice(0, topIndexes);
  if (idx.length) { lines.push(""); lines.push("## أكبر الفهارس"); for (const o of idx) lines.push("- " + o.name + " (على " + o.tbl + "): ~" + mb(o.pages) + " MB"); }
  const virt = rep.objects.filter((o) => o.type === "table" && o.root === 0);
  if (virt.length) { lines.push(""); lines.push("## جداول افتراضية: " + virt.map((o) => o.name).join(", ")); }
  return lines;
}
