// غلاف رفيع على sql.js (يُحمَّل من vendor/sql-wasm.js ويعرّف initSqlJs عامًا).
import { t } from "../strings.js";

let sqlPromise = null;
function ready() {
  if (!sqlPromise) {
    if (typeof globalThis.initSqlJs !== "function") throw new Error(t("err.sqlNotLoaded"));
    sqlPromise = globalThis.initSqlJs({ locateFile: (f) => "./vendor/" + f });
  }
  return sqlPromise;
}

export async function openDatabase(bytes) {
  const SQL = await ready();
  const db = new SQL.Database(bytes);
  return {
    all(sql) {
      const res = db.exec(sql);
      if (!res.length) return [];
      const { columns, values } = res[0];
      return values.map((row) => Object.fromEntries(columns.map((c, i) => [c, row[i]])));
    },
    close() { db.close(); }
  };
}
