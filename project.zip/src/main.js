import { t } from "./strings.js";
import { LIMITS } from "./config.js";
import { createCatalog } from "./modules/catalog.js";
import { loadSaved, downloadCatalog, checkForUpdate } from "./modules/sync.js";
import { inspectBook } from "./modules/book-inspector.js";
import { createDownloadManager } from "./modules/download-manager.js";
import { idbStore } from "./database/downloads-store.js";
import { source } from "./services/shamela-nas-source.js";
import * as V from "./components/views.js";

const $ = (sel, root = document) => root.querySelector(sel);
const view = $("#view");
const app = { catalog: null, raw: null, dl: null, unsub: null };

function errorMessage(e) {
  if (e && e.name === "ConnectorError") return e.message;
  return t("err.generic", { message: (e && e.message) || String(e) });
}

function banner(text, kind) {
  const el = $("#banner");
  el.textContent = text || "";
  el.className = "banner" + (text ? " show " + (kind || "") : "");
}

function parseHash() {
  const raw = location.hash.replace(/^#\/?/, "") || "categories";
  const [path, qs] = raw.split("?");
  const [route, param] = path.split("/");
  return { route, param, query: new URLSearchParams(qs || "") };
}

function setNav(route) {
  const active = route === "book" ? "books" : route;
  document.querySelectorAll("nav a").forEach((a) => a.classList.toggle("on", a.dataset.route === active));
}

function debounce(fn, ms) {
  let id;
  return (...args) => { clearTimeout(id); id = setTimeout(() => fn(...args), ms); };
}

function throttle(fn, ms) {
  let last = 0, timer = null;
  return () => {
    const now = Date.now();
    if (now - last >= ms) { last = now; fn(); }
    else if (!timer) timer = setTimeout(() => { timer = null; last = Date.now(); fn(); }, ms - (now - last));
  };
}

function confirmDialog({ title, body, ok = t("dl.yes"), cancel = t("dl.no") }) {
  return new Promise((resolve) => {
    const m = $("#modal");
    m.innerHTML = V.modalHtml({ title, body, ok, cancel });
    m.hidden = false;
    const done = (v) => { m.hidden = true; m.innerHTML = ""; m.onclick = null; resolve(v); };
    m.onclick = (e) => {
      const b = e.target.closest("[data-modal]");
      if (b) done(b.dataset.modal === "ok");
      else if (e.target === m) done(false);
    };
  });
}

async function setCatalog(raw) {
  if (app.dl) { await app.dl.pauseAll(); await app.dl.whenIdle(); }
  if (app.unsub) app.unsub();
  app.raw = raw;
  app.catalog = createCatalog(raw);
  app.dl = createDownloadManager({ store: idbStore, source, catalog: app.catalog });
  await app.dl.init();
  app.unsub = app.dl.subscribe(throttle(onDlChange, 250));
}

// ---------- التنزيلات ----------
async function startDownload(ids, label) {
  const est = app.dl.estimate(ids);
  if (!est.count) { await confirmDialog({ title: t("dl.confirmTitle"), body: t("dl.nothing"), ok: t("dl.ok"), cancel: "" }); return; }
  const info = await idbStore.storageInfo();
  const free = info && info.quota ? info.quota - info.usage : null;
  const extra = free != null && est.bytes > free * 0.9 ? t("dl.lowSpace", { free: V.fmtBytes(free) }) : "";
  const yes = await confirmDialog({ title: t("dl.confirmTitle"), body: t("dl.confirmBody", { n: est.count, size: V.fmtBytes(est.bytes), extra }) });
  if (!yes) return;
  await idbStore.requestPersistence();
  await app.dl.enqueue(ids);
}

async function handleDl(el) {
  const act = el.dataset.dl;
  const id = Number(el.dataset.id);
  if (act === "pause") return app.dl.pause(id);
  if (act === "resume") return app.dl.resume(id);
  if (act === "retry") return app.dl.retry(id);
  if (act === "cancel") return app.dl.cancel(id);
  if (act === "remove") {
    if (await confirmDialog({ title: t("dl.removeTitle"), body: t("dl.removeBody") })) return app.dl.remove(id);
  }
}

async function refreshDownloads() {
  const root = $("#dl-root");
  if (!root) return;
  const storage = await idbStore.storageInfo();
  root.innerHTML = V.downloadsHtml(app.catalog, app.dl.list(), app.dl.totals(), storage);
}

function renderDownloads() {
  view.innerHTML = '<div id="dl-root"></div>';
  refreshDownloads();
  view.onclick = async (e) => {
    const d = e.target.closest("[data-dl]");
    if (d) return handleDl(d);
    const a = e.target.closest("[data-act]");
    if (!a) return;
    if (a.dataset.act === "pause-all") await app.dl.pauseAll();
    if (a.dataset.act === "resume-all") await app.dl.resumeAll();
    if (a.dataset.act === "remove-all") {
      if (await confirmDialog({ title: t("dl.removeTitle"), body: t("dl.removeAllBody") })) await app.dl.removeAll();
    }
  };
}

function refreshBookDl(id) {
  const area = $("#dl-area");
  if (!area) return;
  area.innerHTML = V.bookDownloadHtml(app.dl.status(id), !!app.catalog.fileInfo(id));
}

function onDlChange() {
  if (!app.catalog) return;
  const { route, param } = parseHash();
  if (route === "downloads") refreshDownloads();
  else if (route === "book") refreshBookDl(Number(param));
}

// ---------- الشاشات ----------
function showFirstRun() {
  setNav("");
  view.innerHTML = V.firstRunHtml();
  $('[data-act="first-sync"]').onclick = async (ev) => {
    const btn = ev.currentTarget;
    const log = $("#progress");
    btn.disabled = true;
    log.hidden = false;
    log.textContent = "";
    try {
      const raw = await downloadCatalog((msg) => { log.textContent += msg + "\n"; });
      await setCatalog(raw);
      location.hash = "#/categories";
      render();
    } catch (e) {
      log.textContent += errorMessage(e) + "\n";
      btn.disabled = false;
    }
  };
}

function renderCategories() {
  view.innerHTML = V.categoriesHtml(app.catalog);
}

function renderAuthors() {
  view.innerHTML = V.authorsControlsHtml();
  const list = $("#list");
  const st = { q: "", limit: LIMITS.pageSize };
  const draw = () => { list.innerHTML = V.authorsListHtml(app.catalog.authors({ q: st.q }), st.limit); };
  $("#q").oninput = debounce((e) => { st.q = e.target.value; st.limit = LIMITS.pageSize; draw(); }, 150);
  list.onclick = (e) => { if (e.target.closest("[data-more]")) { st.limit += LIMITS.pageSize; draw(); } };
  draw();
}

function renderBooks(query) {
  const num = (k) => (query.get(k) != null && query.get(k) !== "" ? Number(query.get(k)) : null);
  const author = num("author");
  const st = { q: "", fields: "all", exact: false, cat: num("cat"), sort: "name", dir: "asc", manualSort: false, limit: LIMITS.pageSize };
  const chips = [];
  if (author != null) { const a = app.catalog.getAuthor(author); if (a) chips.push(t("books.filterAuthor", { name: a.name })); }
  view.innerHTML = V.booksControlsHtml({ chips, sort: st.sort, dir: st.dir, categories: app.catalog.categories(), cat: st.cat });
  const list = $("#list");
  let results = [];
  const draw = () => {
    results = app.catalog.searchBooks({ q: st.q, cat: st.cat, author, fields: st.fields, exact: st.exact, sort: st.sort, dir: st.dir });
    list.innerHTML = V.booksListHtml(app.catalog, results, st.limit);
    // زر تنزيل النتائج يظهر فقط مع بحث أو تصفية؛ لا يُعرض لمكتبة كاملة دون تحديد
    const filtered = st.q.trim() !== "" || st.cat != null || author != null;
    const est = filtered ? app.dl.estimate(results.map((b) => b.id)) : { count: 0 };
    $("#dl-all").innerHTML = est.count > 0 ? V.resultsDownloadButtonHtml(est.count) : "";
  };
  const redraw = () => { st.limit = LIMITS.pageSize; draw(); };
  $("#q").oninput = debounce((e) => {
    st.q = e.target.value;
    if (!st.manualSort) { st.sort = st.q.trim() ? "relevance" : "name"; $("#sort").value = st.sort; }
    redraw();
  }, 150);
  $("#fields").onchange = (e) => { st.fields = e.target.value; redraw(); };
  $("#cat").onchange = (e) => { st.cat = e.target.value === "" ? null : Number(e.target.value); redraw(); };
  $("#exact").onchange = (e) => { st.exact = e.target.checked; redraw(); };
  $("#sort").onchange = (e) => { st.sort = e.target.value; st.manualSort = true; redraw(); };
  $("#dir").onclick = (e) => { st.dir = st.dir === "asc" ? "desc" : "asc"; e.currentTarget.textContent = t("books." + st.dir); redraw(); };
  list.onclick = (e) => { if (e.target.closest("[data-more]")) { st.limit += LIMITS.pageSize; draw(); } };
  $("#dl-all").onclick = (e) => { if (e.target.closest('[data-act="dl-results"]')) startDownload(results.map((b) => b.id)); };
  draw();
}

function renderBook(param) {
  const id = Number(param);
  view.innerHTML = V.bookDetailHtml(app.catalog, id, app.dl.status(id));
  view.onclick = async (e) => {
    const el = e.target.closest("[data-dl]");
    if (!el) return;
    if (el.dataset.dl === "download") {
      const entry = app.catalog.fileInfo(id);
      if (!entry) return;
      if (entry.length > 50 * 1048576) {
        const yes = await confirmDialog({ title: t("dl.confirmTitle"), body: t("dl.big", { size: V.fmtBytes(entry.length) }) });
        if (!yes) return;
      }
      await idbStore.requestPersistence();
      await app.dl.enqueue([id]);
    } else {
      el.dataset.id = String(id);
      await handleDl(el);
    }
  };
}

function renderTools(query) {
  view.innerHTML = V.toolsHtml(app.catalog, query.get("inspect"));
  const out = $("#out");
  const run = async () => {
    const id = Number($("#bid").value);
    if (!Number.isInteger(id) || !app.catalog.getBook(id)) { out.value = t("tools.inspectBadId"); return; }
    out.value = t("tools.inspectStart", { id }) + "\n";
    try {
      const lines = await inspectBook(app.catalog, id, { onProgress: (m) => { out.value = m + "\n"; } });
      out.value = lines.join("\n");
    } catch (e) { out.value = errorMessage(e); }
  };
  view.onclick = async (e) => {
    const act = e.target.closest("[data-act]");
    const quick = e.target.closest("[data-quick]");
    if (quick) { $("#bid").value = quick.dataset.quick; run(); return; }
    if (!act) return;
    if (act.dataset.act === "inspect") run();
    if (act.dataset.act === "copy") {
      try { await navigator.clipboard.writeText(out.value); } catch (_) { out.select(); document.execCommand("copy"); }
    }
    if (act.dataset.act === "refresh") {
      act.disabled = true;
      out.value = t("tools.refreshing") + "\n";
      try {
        const raw = await downloadCatalog((m) => { out.value += m + "\n"; });
        await setCatalog(raw);
        banner("");
        renderTools(new URLSearchParams());
      } catch (err) { out.value += errorMessage(err); act.disabled = false; }
    }
  };
  if (query.get("inspect")) $("#bid").value = query.get("inspect");
}

function render() {
  if (!app.catalog) return showFirstRun();
  const { route, param, query } = parseHash();
  view.onclick = null;
  setNav(route);
  window.scrollTo(0, 0);
  if (route === "authors") renderAuthors();
  else if (route === "books") renderBooks(query);
  else if (route === "book") renderBook(param);
  else if (route === "downloads") renderDownloads();
  else if (route === "tools") renderTools(query);
  else renderCategories();
}

// ---------- الإقلاع ----------
async function boot() {
  document.title = t("appName");
  $("#appname").textContent = t("appName");
  document.querySelectorAll("nav a").forEach((a) => { a.textContent = t("nav." + a.dataset.route); });
  const syncOnline = () => { if (!navigator.onLine) banner(t("online.offline"), "warn"); else if ($("#banner").className.includes("warn")) banner(""); };
  window.addEventListener("online", syncOnline);
  window.addEventListener("offline", syncOnline);
  window.addEventListener("hashchange", render);

  let saved = null;
  try {
    saved = await loadSaved();
  } catch (e) {
    banner(errorMessage(e), "bad");
  }
  if (saved) {
    await setCatalog(saved);
    render();
    syncOnline();
    if (navigator.onLine) {
      try {
        const u = await checkForUpdate(saved);
        if (u.available) banner(t("update.available", { version: u.version }), "info");
      } catch (_) { /* الفحص اختياري، نتجاهل فشله */ }
    }
  } else {
    showFirstRun();
    syncOnline();
  }
}

boot();
