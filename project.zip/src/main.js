import { t } from "./strings.js";
import { LIMITS } from "./config.js";
import { createCatalog } from "./modules/catalog.js";
import { loadSaved, downloadCatalog, checkForUpdate } from "./modules/sync.js";
import { inspectBook } from "./modules/book-inspector.js";
import * as V from "./components/views.js";

const $ = (sel, root = document) => root.querySelector(sel);
const view = $("#view");
const app = { catalog: null, raw: null };

function errorMessage(e) {
  if (e && e.name === "ConnectorError") return e.message;
  return t("err.generic", { message: (e && e.message) || String(e) });
}

function banner(text, kind) {
  const el = $("#banner");
  el.textContent = text || "";
  el.className = "banner" + (text ? " show " + (kind || "") : "");
}

function parseHash() {
  const raw = location.hash.replace(/^#\/?/, "") || "categories";
  const [path, qs] = raw.split("?");
  const [route, param] = path.split("/");
  return { route, param, query: new URLSearchParams(qs || "") };
}

function setNav(route) {
  const active = route === "book" ? "books" : route;
  document.querySelectorAll("nav a").forEach((a) => a.classList.toggle("on", a.dataset.route === active));
}

function debounce(fn, ms) {
  let id;
  return (...args) => { clearTimeout(id); id = setTimeout(() => fn(...args), ms); };
}

// ---------- الشاشات ----------
function showFirstRun() {
  setNav("");
  view.innerHTML = V.firstRunHtml();
  $('[data-act="first-sync"]').onclick = async (ev) => {
    const btn = ev.currentTarget;
    const log = $("#progress");
    btn.disabled = true;
    log.hidden = false;
    log.textContent = "";
    try {
      const raw = await downloadCatalog((msg) => { log.textContent += msg + "\n"; });
      app.raw = raw;
      app.catalog = createCatalog(raw);
      location.hash = "#/categories";
      render();
    } catch (e) {
      log.textContent += errorMessage(e) + "\n";
      btn.disabled = false;
    }
  };
}

function renderCategories() {
  view.innerHTML = V.categoriesHtml(app.catalog);
}

function renderAuthors() {
  view.innerHTML = V.authorsControlsHtml();
  const list = $("#list");
  const st = { q: "", limit: LIMITS.pageSize };
  const draw = () => { list.innerHTML = V.authorsListHtml(app.catalog.authors({ q: st.q }), st.limit); };
  $("#q").oninput = debounce((e) => { st.q = e.target.value; st.limit = LIMITS.pageSize; draw(); }, 150);
  list.onclick = (e) => { if (e.target.closest("[data-more]")) { st.limit += LIMITS.pageSize; draw(); } };
  draw();
}

function renderBooks(query) {
  const num = (k) => (query.get(k) != null && query.get(k) !== "" ? Number(query.get(k)) : null);
  const cat = num("cat");
  const author = num("author");
  const chips = [];
  if (cat != null) { const c = app.catalog.getCategory(cat); if (c) chips.push(t("books.filterCat", { name: c.name })); }
  if (author != null) { const a = app.catalog.getAuthor(author); if (a) chips.push(t("books.filterAuthor", { name: a.name })); }
  const st = { q: "", sort: "name", dir: "asc", limit: LIMITS.pageSize };
  view.innerHTML = V.booksControlsHtml({ chips, sort: st.sort, dir: st.dir });
  const list = $("#list");
  const draw = () => {
    const res = app.catalog.searchBooks({ q: st.q, cat, author, sort: st.sort, dir: st.dir });
    list.innerHTML = V.booksListHtml(app.catalog, res, st.limit);
  };
  $("#q").oninput = debounce((e) => { st.q = e.target.value; st.limit = LIMITS.pageSize; draw(); }, 150);
  $("#sort").onchange = (e) => { st.sort = e.target.value; st.limit = LIMITS.pageSize; draw(); };
  $("#dir").onclick = (e) => { st.dir = st.dir === "asc" ? "desc" : "asc"; e.currentTarget.textContent = t("books." + st.dir); draw(); };
  list.onclick = (e) => { if (e.target.closest("[data-more]")) { st.limit += LIMITS.pageSize; draw(); } };
  draw();
}

function renderBook(param) {
  view.innerHTML = V.bookDetailHtml(app.catalog, Number(param));
}

function renderTools(query) {
  view.innerHTML = V.toolsHtml(app.catalog, query.get("inspect"));
  const out = $("#out");
  const run = async () => {
    const id = Number($("#bid").value);
    if (!Number.isInteger(id) || !app.catalog.getBook(id)) { out.value = t("tools.inspectBadId"); return; }
    out.value = t("tools.inspectStart", { id }) + "\n";
    try {
      const lines = await inspectBook(app.catalog, id, { onProgress: (m) => { out.value = m + "\n"; } });
      out.value = lines.join("\n");
    } catch (e) { out.value = errorMessage(e); }
  };
  view.onclick = async (e) => {
    const act = e.target.closest("[data-act]");
    const quick = e.target.closest("[data-quick]");
    if (quick) { $("#bid").value = quick.dataset.quick; run(); return; }
    if (!act) return;
    if (act.dataset.act === "inspect") run();
    if (act.dataset.act === "copy") {
      try { await navigator.clipboard.writeText(out.value); } catch (_) { out.select(); document.execCommand("copy"); }
    }
    if (act.dataset.act === "refresh") {
      act.disabled = true;
      out.value = t("tools.refreshing") + "\n";
      try {
        const raw = await downloadCatalog((m) => { out.value += m + "\n"; });
        app.raw = raw;
        app.catalog = createCatalog(raw);
        banner("");
        renderTools(new URLSearchParams());
      } catch (err) { out.value += errorMessage(err); act.disabled = false; }
    }
  };
  if (query.get("inspect")) $("#bid").value = query.get("inspect");
}

function render() {
  if (!app.catalog) return showFirstRun();
  const { route, param, query } = parseHash();
  view.onclick = null;
  setNav(route);
  window.scrollTo(0, 0);
  if (route === "authors") renderAuthors();
  else if (route === "books") renderBooks(query);
  else if (route === "book") renderBook(param);
  else if (route === "tools") renderTools(query);
  else renderCategories();
}

// ---------- الإقلاع ----------
async function boot() {
  document.title = t("appName");
  $("#appname").textContent = t("appName");
  document.querySelectorAll("nav a").forEach((a) => { a.textContent = t("nav." + a.dataset.route); });
  const syncOnline = () => { if (!navigator.onLine) banner(t("online.offline"), "warn"); else if ($("#banner").className.includes("warn")) banner(""); };
  window.addEventListener("online", syncOnline);
  window.addEventListener("offline", syncOnline);
  window.addEventListener("hashchange", render);

  try {
    app.raw = await loadSaved();
  } catch (e) {
    banner(errorMessage(e), "bad");
  }
  if (app.raw) {
    app.catalog = createCatalog(app.raw);
    render();
    syncOnline();
    if (navigator.onLine) {
      try {
        const u = await checkForUpdate(app.raw);
        if (u.available) banner(t("update.available", { version: u.version }), "info");
      } catch (_) { /* الفحص اختياري، نتجاهل فشله */ }
    }
  } else {
    showFirstRun();
    syncOnline();
  }
}

boot();
