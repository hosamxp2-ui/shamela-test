import { t } from "./strings.js";
import { LIMITS } from "./config.js";
import { createCatalog } from "./modules/catalog.js";
import { loadSaved, downloadCatalog, checkForUpdate } from "./modules/sync.js";
import { inspectBook } from "./modules/book-inspector.js";
import { inspectDbPrefix } from "./modules/db-inspector.js";
import { scanDb } from "./modules/services-scan.js";
import { createDownloadManager } from "./modules/download-manager.js";
import { idbStore } from "./database/downloads-store.js";
import { source } from "./services/shamela-nas-source.js";
import { mountReader } from "./reader/reader-controller.js";
import { createSettingsStore, toCssVars, patchFromControl } from "./modules/settings.js";
import { createThemeManager } from "./modules/theme.js";
import { decideBack } from "./modules/back-handler.js";
import { detectFonts } from "./modules/fonts.js";
import { settingsPageHtml } from "./components/settings-view.js";
import { searchPageHtml, resultsHtml, statusHtml } from "./components/search-view.js";
import { scopeIds, searchLibrary, sortResults } from "./search/library-search.js";
import { createProgressStore } from "./modules/progress.js";
import { createNotesStore } from "./modules/notes.js";
import { createLibraryStore } from "./modules/library.js";
import { createStatsStore } from "./modules/stats.js";
import { statsPageHtml, fmtDuration } from "./components/stats-view.js";
import { isFinished } from "./modules/progress.js";
import * as V from "./components/views.js";

const $ = (sel, root = document) => root.querySelector(sel);
const view = $("#view");
const app = { catalog: null, raw: null, dl: null, unsub: null, modalDismiss: null, ui: { books: null, booksScroll: null, lastRoute: null } };
const themeManager = createThemeManager();
const settingsStore = createSettingsStore();
const progressStore = createProgressStore();
const notesStore = createNotesStore();
const library = createLibraryStore();
const statsStore = createStatsStore();
let reader = null;
let mountToken = 0;

function errorMessage(e) {
  if (e && e.name === "ConnectorError") return e.message;
  return t("err.generic", { message: (e && e.message) || String(e) });
}

function banner(text, kind) {
  const el = $("#banner");
  el.textContent = text || "";
  el.className = "banner" + (text ? " show " + (kind || "") : "");
}

function parseHash() {
  const raw = location.hash.replace(/^#\/?/, "") || "categories";
  const [path, qs] = raw.split("?");
  const [route, param] = path.split("/");
  return { route, param, query: new URLSearchParams(qs || "") };
}

function setNav(route) {
  const active = route === "book" ? "books" : route === "author" ? "authors" : route === "category" ? "categories" : route === "search" ? "books" : route === "tools" || route === "notes" || route === "stats" ? "settings" : route;
  document.querySelectorAll("nav a").forEach((a) => a.classList.toggle("on", a.dataset.route === active));
}

function debounce(fn, ms) {
  let id;
  return (...args) => { clearTimeout(id); id = setTimeout(() => fn(...args), ms); };
}

function throttle(fn, ms) {
  let last = 0, timer = null;
  return () => {
    const now = Date.now();
    if (now - last >= ms) { last = now; fn(); }
    else if (!timer) timer = setTimeout(() => { timer = null; last = Date.now(); fn(); }, ms - (now - last));
  };
}

let toastTimer = null;
function showToast(text, ms = 2000) {
  const el = $("#toast");
  el.textContent = text;
  el.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { el.hidden = true; }, ms);
}

function confirmDialog({ title, body, ok = t("dl.yes"), cancel = t("dl.no") }) {
  return new Promise((resolve) => {
    const m = $("#modal");
    m.innerHTML = V.modalHtml({ title, body, ok, cancel });
    m.hidden = false;
    const done = (v) => { m.hidden = true; m.innerHTML = ""; m.onclick = null; app.modalDismiss = null; resolve(v); };
    app.modalDismiss = () => done(false);
    m.onclick = (e) => {
      const b = e.target.closest("[data-modal]");
      if (b) done(b.dataset.modal === "ok");
      else if (e.target === m) done(false);
    };
  });
}

async function setCatalog(raw) {
  if (app.dl) { await app.dl.pauseAll(); await app.dl.whenIdle(); }
  if (app.unsub) app.unsub();
  app.raw = raw;
  app.catalog = createCatalog(raw);
  app.dl = createDownloadManager({ store: idbStore, source, catalog: app.catalog });
  await app.dl.init();
  app.unsub = app.dl.subscribe(throttle(onDlChange, 250));
}

// ---------- التنزيلات ----------
async function startDownload(ids, label) {
  const est = app.dl.estimate(ids);
  if (!est.count) { await confirmDialog({ title: t("dl.confirmTitle"), body: t("dl.nothing"), ok: t("dl.ok"), cancel: "" }); return; }
  const info = await idbStore.storageInfo();
  const free = info && info.quota ? info.quota - info.usage : null;
  const extra = free != null && est.bytes > free * 0.9 ? t("dl.lowSpace", { free: V.fmtBytes(free) }) : "";
  const yes = await confirmDialog({ title: t("dl.confirmTitle"), body: t("dl.confirmBody", { n: est.count, size: V.fmtBytes(est.bytes), extra }) });
  if (!yes) return;
  await idbStore.requestPersistence();
  await app.dl.enqueue(ids);
}

async function handleDl(el) {
  const act = el.dataset.dl;
  const id = Number(el.dataset.id);
  if (act === "pause") return app.dl.pause(id);
  if (act === "resume") return app.dl.resume(id);
  if (act === "retry") return app.dl.retry(id);
  if (act === "cancel") return app.dl.cancel(id);
  if (act === "remove") {
    if (await confirmDialog({ title: t("dl.removeTitle"), body: t("dl.removeBody") })) return app.dl.remove(id);
  }
}

async function refreshDownloads() {
  const root = $("#dl-root");
  if (!root) return;
  const storage = await idbStore.storageInfo();
  root.innerHTML = V.downloadsHtml(app.catalog, app.dl.list(), app.dl.totals(), storage);
}

function renderDownloads() {
  view.innerHTML = '<div id="dl-root"></div>';
  refreshDownloads();
  view.onclick = async (e) => {
    const d = e.target.closest("[data-dl]");
    if (d) return handleDl(d);
    const a = e.target.closest("[data-act]");
    if (!a) return;
    if (a.dataset.act === "pause-all") await app.dl.pauseAll();
    if (a.dataset.act === "resume-all") await app.dl.resumeAll();
    if (a.dataset.act === "remove-all") {
      if (await confirmDialog({ title: t("dl.removeTitle"), body: t("dl.removeAllBody") })) await app.dl.removeAll();
    }
  };
}

function refreshBookDl(id) {
  const area = $("#dl-area");
  if (!area) return;
  area.innerHTML = V.bookDownloadHtml(app.dl.status(id), !!app.catalog.fileInfo(id));
}

function onDlChange() {
  if (!app.catalog) return;
  const { route, param } = parseHash();
  if (route === "downloads") refreshDownloads();
  else if (route === "book") refreshBookDl(Number(param));
}

// ---------- الشاشات ----------
function showFirstRun() {
  setNav("");
  view.innerHTML = V.firstRunHtml();
  $('[data-act="first-sync"]').onclick = async (ev) => {
    const btn = ev.currentTarget;
    const log = $("#progress");
    btn.disabled = true;
    log.hidden = false;
    log.textContent = "";
    try {
      const raw = await downloadCatalog((msg) => { log.textContent += msg + "\n"; });
      await setCatalog(raw);
      location.hash = "#/categories";
      render();
    } catch (e) {
      log.textContent += errorMessage(e) + "\n";
      btn.disabled = false;
    }
  };
}

async function renderCategories() {
  const raw = await progressStore.recent(12);
  const recent = raw.map((r) => ({ book: app.catalog.getBook(r.id), index: r.index, total: r.total }))
    .filter((r) => r.book && app.catalog.fileInfo(r.book.id));
  const hero = recent.find((r) => !isFinished({ index: r.index, total: r.total }) && app.dl.isDownloaded(r.book.id)) || null;
  const shelf = recent.filter((r) => !hero || r.book.id !== hero.book.id);
  const favorites = library.favoriteIds().map((id) => app.catalog.getBook(id)).filter(Boolean).slice(0, 12);
  if (parseHash().route !== "categories") return;
  const tot = statsStore.totals();
  const td = statsStore.todayStats();
  const statsLine = tot.pages > 0 || tot.seconds > 0 ? t("stats.today") + ": " + t("stats.pagesN", { n: td.pages }) + " • " + fmtDuration(td.seconds) : "";
  view.innerHTML = V.homeHtml({ catalog: app.catalog, hero, recent: shelf, favorites, statsLine });
}

function renderAuthors() {
  view.innerHTML = V.authorsControlsHtml();
  const list = $("#list");
  const st = { q: "", limit: LIMITS.pageSize };
  const draw = () => { list.innerHTML = V.authorsListHtml(app.catalog.authors({ q: st.q }), st.limit); };
  $("#q").oninput = debounce((e) => { st.q = e.target.value; st.limit = LIMITS.pageSize; draw(); }, 150);
  list.onclick = (e) => { if (e.target.closest("[data-more]")) { st.limit += LIMITS.pageSize; draw(); } };
  draw();
}

function renderBooks(query, preset = null) {
  const num = (k) => (query.get(k) != null && query.get(k) !== "" ? Number(query.get(k)) : null);
  const author = preset && preset.author != null ? preset.author : num("author");
  const presetCat = preset && preset.cat != null ? preset.cat : num("cat");
  const key = preset ? preset.key : (query.get("cat") || "") + "|" + (query.get("author") || "");
  const fresh = { key, q: "", fields: "all", exact: false, cat: presetCat, sort: "name", dir: "asc", manualSort: false, limit: LIMITS.pageSize };
  const extras = { isDownloaded: (bid) => app.dl.isDownloaded(bid), rating: (bid) => library.rating(bid) };
  const restored = app.ui.books && app.ui.books.key === key;
  const st = restored ? { ...app.ui.books } : fresh;
  const remember = () => { app.ui.books = { ...st }; };
  const chips = [];
  if (!preset && author != null) { const a = app.catalog.getAuthor(author); if (a) chips.push(t("books.filterAuthor", { name: a.name })); }
  view.innerHTML = (preset && preset.headerHtml ? preset.headerHtml : "") + V.booksControlsHtml({ chips, q: st.q, fields: st.fields, exact: st.exact, sort: st.sort, dir: st.dir, categories: app.catalog.categories(), cat: st.cat });
  const list = $("#list");
  let results = [];
  const draw = () => {
    results = app.catalog.searchBooks({ q: st.q, cat: st.cat, author, fields: st.fields, exact: st.exact, sort: st.sort, dir: st.dir });
    list.innerHTML = V.booksListHtml(app.catalog, results, st.limit, extras);
    // زر تنزيل النتائج يظهر فقط مع بحث أو تصفية؛ لا يُعرض لمكتبة كاملة دون تحديد
    const filtered = st.q.trim() !== "" || st.cat != null || author != null;
    const est = filtered ? app.dl.estimate(results.map((b) => b.id)) : { count: 0 };
    $("#dl-all").innerHTML = est.count > 0 ? V.resultsDownloadButtonHtml(est.count) : "";
    remember();
  };
  const redraw = () => { st.limit = LIMITS.pageSize; draw(); };
  $("#dir").textContent = t("books." + st.dir);
  $("#q").oninput = debounce((e) => {
    st.q = e.target.value;
    if (!st.manualSort) { st.sort = st.q.trim() ? "relevance" : "name"; $("#sort").value = st.sort; }
    redraw();
  }, 150);
  $("#fields").onchange = (e) => { st.fields = e.target.value; redraw(); };
  $("#cat").onchange = (e) => { st.cat = e.target.value === "" ? null : Number(e.target.value); redraw(); };
  $("#exact").onchange = (e) => { st.exact = e.target.checked; redraw(); };
  $("#sort").onchange = (e) => { st.sort = e.target.value; st.manualSort = true; redraw(); };
  $("#dir").onclick = (e) => { st.dir = st.dir === "asc" ? "desc" : "asc"; e.currentTarget.textContent = t("books." + st.dir); redraw(); };
  list.onclick = (e) => { if (e.target.closest("[data-more]")) { st.limit += LIMITS.pageSize; draw(); } };
  $("#dl-all").onclick = (e) => { if (e.target.closest('[data-act="dl-results"]')) startDownload(results.map((b) => b.id)); };
  draw();
  if (query.get("focus")) $("#q").focus();
  if (restored && app.ui.booksScroll != null) { const y = app.ui.booksScroll; requestAnimationFrame(() => window.scrollTo(0, y)); }
}

function renderAuthorPage(param) {
  const id = Number(param);
  const a = app.catalog.getAuthor(id);
  if (!a) { view.innerHTML = `<p class="empty">${t("err.notAvailable")}</p>`; return; }
  const count = app.catalog.searchBooks({ author: id }).length;
  renderBooks(new URLSearchParams(), { author: id, key: "author:" + id, headerHtml: V.authorHeaderHtml(a, count) });
}

function renderCategoryPage(param) {
  const id = Number(param);
  const c = app.catalog.getCategory(id);
  if (!c) { view.innerHTML = `<p class="empty">${t("err.notAvailable")}</p>`; return; }
  const count = app.catalog.searchBooks({ cat: id }).length;
  renderBooks(new URLSearchParams(), { cat: id, key: "cat:" + id, headerHtml: V.categoryHeaderHtml(c, count) });
}

function renderBook(param) {
  const id = Number(param);
  const extras = () => ({ rating: library.rating(id), favorite: library.isFavorite(id) });
  view.innerHTML = V.bookDetailHtml(app.catalog, id, app.dl.status(id), extras());
  view.onclick = async (e) => {
    const rate = e.target.closest("[data-rate]");
    if (rate) { await library.setRating(id, Number(rate.dataset.rate)); $("#rate-area").innerHTML = V.ratingHtml(extras()); return; }
    if (e.target.closest("[data-fav]")) { await library.toggleFavorite(id); $("#rate-area").innerHTML = V.ratingHtml(extras()); return; }
    const el = e.target.closest("[data-dl]");
    if (!el) return;
    if (el.dataset.dl === "download") {
      const entry = app.catalog.fileInfo(id);
      if (!entry) return;
      if (entry.length > 50 * 1048576) {
        const yes = await confirmDialog({ title: t("dl.confirmTitle"), body: t("dl.big", { size: V.fmtBytes(entry.length) }) });
        if (!yes) return;
      }
      await idbStore.requestPersistence();
      await app.dl.enqueue([id]);
    } else {
      el.dataset.id = String(id);
      await handleDl(el);
    }
  };
}

function renderSearch(query) {
  const st = app.ui.search || (app.ui.search = {
    q: "", scope: "all", cat: null, author: null, book: null, exact: false, sort: "relevance", dir: "asc",
    results: [], skipped: [], truncated: false, searched: 0, cancelled: false, running: false, progress: null, token: null, key: ""
  });
  const key = query.toString();
  if (key && key !== st.key) {
    st.key = key;
    const num = (k) => (query.get(k) != null && query.get(k) !== "" ? Number(query.get(k)) : null);
    st.scope = ["all", "cat", "author", "book"].includes(query.get("scope")) ? query.get("scope") : "all";
    st.cat = num("cat"); st.author = num("author"); st.book = num("book");
    if (query.get("q") != null) st.q = query.get("q");
    st.results = []; st.skipped = []; st.truncated = false; st.searched = 0; st.cancelled = false;
  }
  const downloaded = () => app.dl.list().filter((r) => r.status === "done").map((r) => r.id);
  const sorted = () => sortResults(st.results, st.sort, st.dir, app.catalog);
  const booksIn = () => new Set(st.results.map((r) => r.bookId)).size;
  const draw = () => {
    if (parseHash().route !== "search") return;
    view.innerHTML = searchPageHtml({ st, catalog: app.catalog, categories: app.catalog.categories(), downloadedCount: downloaded().length, sorted: sorted() });
  };
  const drawParts = () => {
    if (parseHash().route !== "search") return;
    const s = $("#s-status"), r = $("#s-results");
    if (s) s.textContent = statusHtml(st, st.results.length, booksIn()).replace(/&amp;/g, "&");
    if (r) r.innerHTML = resultsHtml(sorted(), app.catalog, st.q, st.exact);
  };
  async function run() {
    if (st.running) return;
    st.q = ($("#sq") ? $("#sq").value : st.q).trim();
    if (!st.q) return;
    const ids = scopeIds({ scope: st.scope, cat: st.cat, author: st.author, book: st.book }, { catalog: app.catalog, downloadedIds: downloaded() });
    st.running = true; st.token = { cancelled: false }; st.results = []; st.skipped = []; st.truncated = false; st.cancelled = false; st.searched = 0;
    st.progress = { done: 0, total: ids.length };
    draw();
    const out = await searchLibrary({
      ids, q: st.q, exact: st.exact, dl: app.dl, catalog: app.catalog, token: st.token,
      onProgress: (p) => { st.progress = p; drawParts(); },
      onResults: (r) => { st.results = r; drawParts(); }
    });
    st.running = false; st.results = out.results; st.skipped = out.skipped; st.truncated = out.truncated; st.searched = out.searched; st.cancelled = out.cancelled;
    draw();
  }
  draw();
  view.onclick = (e) => {
    const a = e.target.closest("[data-act]");
    if (a && a.dataset.act === "s-run") run();
    else if (a && a.dataset.act === "s-cancel") { if (st.token) st.token.cancelled = true; }
    else if (e.target.closest("#s-dir")) { st.dir = st.dir === "asc" ? "desc" : "asc"; draw(); }
  };
  view.onchange = (e) => {
    if (e.target.id === "s-scope") { st.scope = e.target.value; if (st.scope === "all") { st.author = null; st.book = null; } draw(); }
    else if (e.target.id === "s-cat") st.cat = e.target.value === "" ? null : Number(e.target.value);
    else if (e.target.id === "s-sort") { st.sort = e.target.value; drawParts(); }
    else if (e.target.id === "s-exact") st.exact = e.target.checked;
  };
  view.onkeydown = (e) => { if (e.key === "Enter" && e.target.id === "sq") { e.preventDefault(); run(); } };
}

function dayLabel(d) {
  try { return d.toLocaleDateString("ar", { weekday: "long", day: "numeric", month: "long" }); } catch (_) { return d.toDateString(); }
}

async function renderStats() {
  const draw = async () => {
    const lists = { reading: [], finished: [], notStarted: [] };
    for (const r of app.dl.list().filter((x) => x.status === "done")) {
      const p = await progressStore.load(r.id);
      if (!p) { lists.notStarted.push({ id: r.id }); continue; }
      const e = { id: r.id, at: p.at || 0, pct: Math.round(((p.index + 1) / Math.max(1, p.total)) * 100) };
      (isFinished(p) ? lists.finished : lists.reading).push(e);
    }
    lists.reading.sort((a, b) => b.at - a.at);
    lists.finished.sort((a, b) => b.at - a.at);
    const series = statsStore.series(14);
    const log = series.slice().reverse().filter((d) => d.pages > 0 || d.seconds >= 30).slice(0, 14)
      .map((d) => ({ label: dayLabel(d.date), pages: d.pages, seconds: d.seconds, books: d.books }));
    if (parseHash().route !== "stats") return;
    view.innerHTML = statsPageHtml({
      catalog: app.catalog, summary: statsStore.summary(), today: statsStore.todayStats(), totals: statsStore.totals(),
      series, metric: app.ui.statsMetric || "pages", lists, log
    });
  };
  await draw();
  view.onclick = (e) => {
    const m = e.target.closest("[data-metric]");
    if (m) { app.ui.statsMetric = m.dataset.metric; draw(); }
  };
}

async function renderNotesPage() {
  const draw = async () => {
    const groups = [];
    for (const bid of await notesStore.allBooks()) {
      const items = await notesStore.load(bid);
      if (!items.length) continue;
      const bk = app.catalog.getBook(bid);
      groups.push({ bookId: bid, name: bk ? bk.name : String(bid), items });
    }
    if (parseHash().route !== "notes") return;
    view.innerHTML = V.notesPageHtml(groups, (bid) => app.dl.isDownloaded(bid));
  };
  await draw();
  view.onclick = async (e) => {
    const del = e.target.closest('[data-nact="del"]');
    if (!del) return;
    await notesStore.remove(Number(del.dataset.book), del.dataset.id);
    await draw();
  };
}

async function renderSettings() {
  const root = view;
  const fonts = await detectFonts();
  const storage = await idbStore.storageInfo();
  if (parseHash().route !== "settings") return;
  const totals = app.dl.totals();
  const big = app.dl.list().filter((r) => r.status === "done").sort((x, y) => y.total - x.total).slice(0, 8)
    .map((r) => { const b = app.catalog.getBook(r.id); return { id: r.id, name: b ? b.name : String(r.id), total: r.total }; });
  const sampleStyle = (s) => Object.entries(toCssVars(s, themeManager.effective())).map(([k, v]) => k + ":" + v).join(";");
  const draw = () => {
    root.innerHTML = settingsPageHtml({
      app: themeManager.get(), reader: settingsStore.get(), fonts, storage, totals: app.dl.totals(), big, sampleStyle: sampleStyle(settingsStore.get())
    });
  };
  await settingsStore.load();
  draw();
  const refresh = async () => { await renderSettings(); };
  root.onclick = async (e) => {
    const seg = e.target.closest("[data-app]");
    if (seg) { await themeManager.update({ [seg.dataset.app]: seg.dataset.value }); draw(); return; }
    const rs = e.target.closest("[data-seg]");
    if (rs) { const p = patchFromControl(rs.dataset.seg, rs.dataset.value); if (p) { await settingsStore.update(p); draw(); } return; }
    const d = e.target.closest("[data-dl]");
    if (d) { await handleDl(d); await refresh(); return; }
    const a = e.target.closest("[data-act]");
    if (!a) return;
    if (a.dataset.act === "reset-reading") { await settingsStore.reset(); draw(); }
    if (a.dataset.act === "remove-all") {
      if (await confirmDialog({ title: t("dl.removeTitle"), body: t("dl.removeAllBody") })) { await app.dl.removeAll(); await refresh(); }
    }
  };
  root.oninput = (e) => {
    const c = e.target.closest("[data-set]");
    if (!c || c.type !== "range") return;
    const out = c.parentElement.querySelector("output");
    if (out) out.textContent = c.value;
    const p = patchFromControl(c.dataset.set, c.value);
    const sample = $("#r-sample");
    if (p && sample) sample.setAttribute("style", sampleStyle({ ...settingsStore.get(), ...p }));
  };
  root.onchange = async (e) => {
    const time = e.target.closest("[data-app-time]");
    if (time) { await themeManager.update({ [time.dataset.appTime]: time.value }); draw(); return; }
    const c = e.target.closest("[data-set]");
    if (!c) return;
    const p = patchFromControl(c.dataset.set, c.value, c.checked);
    if (p) { await settingsStore.update(p); draw(); }
  };
}

function renderTools(query) {
  view.innerHTML = V.toolsHtml(app.catalog, query.get("inspect"));
  const out = $("#out");
  const run = async () => {
    const id = Number($("#bid").value);
    if (!Number.isInteger(id) || !app.catalog.getBook(id)) { out.value = t("tools.inspectBadId"); return; }
    out.value = t("tools.inspectStart", { id }) + "\n";
    try {
      const lines = await inspectBook(app.catalog, id, { onProgress: (m) => { out.value = m + "\n"; } });
      out.value = lines.join("\n");
    } catch (e) { out.value = errorMessage(e); }
  };
  view.onclick = async (e) => {
    const act = e.target.closest("[data-act]");
    const quick = e.target.closest("[data-quick]");
    if (quick) { $("#bid").value = quick.dataset.quick; run(); return; }
    if (!act) return;
    if (act.dataset.act === "inspect") run();
    if (act.dataset.act === "scan-cancel") { if (app.scanToken) app.scanToken.cancelled = true; }
    if (act.dataset.act === "scan-db") {
      if (app.scanToken && !app.scanToken.cancelled && app.scanning) return;
      const yes = await confirmDialog({ title: t("tools.scanTitle"), body: t("tools.scanConfirm", { mb: act.dataset.mb }) });
      if (!yes) return;
      app.scanToken = { cancelled: false };
      app.scanning = true;
      out.value = "";
      try {
        const res = await scanDb(act.dataset.db, {
          token: app.scanToken,
          onProgress: (p) => { out.value = t("tools.scanProgress", { pct: Math.floor((p.done / p.total) * 100), done: Math.round(p.done / 1048576), total: Math.round(p.total / 1048576), out: Math.round(p.produced / 1048576) }); }
        });
        out.value = res.lines.join("\n");
      } catch (err) { out.value += errorMessage(err); }
      app.scanning = false;
    }
    if (act.dataset.act === "inspect-db") {
      act.disabled = true;
      out.value = "";
      try {
        const lines = await inspectDbPrefix(act.dataset.db, { onProgress: (msg) => { out.value += msg + "\n"; } });
        out.value = lines.join("\n");
      } catch (err) { out.value += errorMessage(err); }
      act.disabled = false;
    }
    if (act.dataset.act === "copy") {
      try { await navigator.clipboard.writeText(out.value); } catch (_) { out.select(); document.execCommand("copy"); }
    }
    if (act.dataset.act === "refresh") {
      act.disabled = true;
      out.value = t("tools.refreshing") + "\n";
      try {
        const raw = await downloadCatalog((m) => { out.value += m + "\n"; });
        await setCatalog(raw);
        banner("");
        renderTools(new URLSearchParams());
      } catch (err) { out.value += errorMessage(err); act.disabled = false; }
    }
  };
  if (query.get("inspect")) $("#bid").value = query.get("inspect");
}

function unmountReader() {
  mountToken++;
  if (reader) { reader.destroy(); reader = null; }
  document.body.classList.remove("reading");
}

async function renderRead(param, query) {
  const id = Number(param);
  if (!app.dl.isDownloaded(id)) {
    view.innerHTML = `<p class="empty">${t("reader.notDownloaded")}</p><a class="btn" href="#/book/${id}">${t("nav.books")}</a>`;
    return;
  }
  const token = ++mountToken;
  try {
    const startIndex = query && query.get("page") != null && query.get("page") !== "" ? Number(query.get("page")) : null;
    const highlight = query && query.get("hl") ? { q: query.get("hl"), exact: query.get("x") === "1" } : null;
    const r = await mountReader({ container: view, id, catalog: app.catalog, dl: app.dl, settingsStore, progressStore, themeManager, notesStore, statsStore, toast: showToast, startIndex, highlight });
    if (token !== mountToken) r.destroy(); else reader = r;
  } catch (e) {
    document.body.classList.remove("reading");
    view.innerHTML = `<p class="empty">${errorMessage(e)}</p>`;
  }
}

function render() {
  unmountReader();
  if (!app.catalog) return showFirstRun();
  const { route, param, query } = parseHash();
  if (app.ui.lastRoute === "books") app.ui.booksScroll = window.scrollY;
  app.ui.lastRoute = route;
  view.onclick = null;
  view.oninput = null;
  view.onchange = null;
  view.onkeydown = null;
  if (route !== "search" && app.ui.search && app.ui.search.token) app.ui.search.token.cancelled = true;
  setNav(route);
  window.scrollTo(0, 0);
  if (route === "authors") renderAuthors();
  else if (route === "books") renderBooks(query);
  else if (route === "book") renderBook(param);
  else if (route === "author") renderAuthorPage(param);
  else if (route === "category") renderCategoryPage(param);
  else if (route === "downloads") renderDownloads();
  else if (route === "read") renderRead(param, query);
  else if (route === "notes") renderNotesPage();
  else if (route === "stats") renderStats();
  else if (route === "search") renderSearch(query);
  else if (route === "settings") renderSettings();
  else if (route === "tools") renderTools(query);
  else renderCategories();
}

// ---------- زر الرجوع (أندرويد) ----------
async function registerBackButton() {
  const App = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.App;
  if (!App || typeof App.addListener !== "function") return;
  let last = null;
  await App.addListener("backButton", () => {
    const { route } = parseHash();
    const d = decideBack({
      modalOpen: !$("#modal").hidden,
      sheetOpen: !!(reader && reader.sheetOpen && reader.sheetOpen()),
      fullscreen: !!document.fullscreenElement,
      route, lastBackAt: last, now: Date.now()
    });
    last = d.lastBackAt;
    if (d.action === "close-modal") { if (app.modalDismiss) app.modalDismiss(); }
    else if (d.action === "close-sheet") reader.closeSheet();
    else if (d.action === "exit-fullscreen") document.exitFullscreen();
    else if (d.action === "go-home") location.replace("#/categories");
    else if (d.action === "history-back") history.back();
    else if (d.action === "toast-exit") showToast(t("back.again"));
    else if (d.action === "exit") App.exitApp();
  });
}

// ---------- الإقلاع ----------
async function boot() {
  document.title = t("appName");
  $("#appname").textContent = t("appName");
  document.querySelectorAll("nav a").forEach((a) => { const sp = a.querySelector("span"); if (sp) sp.textContent = t("nav." + a.dataset.route); });
  const syncOnline = () => { if (!navigator.onLine) banner(t("online.offline"), "warn"); else if ($("#banner").className.includes("warn")) banner(""); };
  window.addEventListener("online", syncOnline);
  window.addEventListener("offline", syncOnline);
  window.addEventListener("hashchange", render);
  await themeManager.load();
  themeManager.start();
  await settingsStore.load();
  await library.load();
  await statsStore.load();
  try { await registerBackButton(); } catch (_) { /* بدون الإضافة يعمل الرجوع الافتراضي */ }

  let saved = null;
  try {
    saved = await loadSaved();
  } catch (e) {
    banner(errorMessage(e), "bad");
  }
  if (saved) {
    await setCatalog(saved);
    render();
    syncOnline();
    if (navigator.onLine) {
      try {
        const u = await checkForUpdate(saved);
        if (u.available) banner(t("update.available", { version: u.version }), "info");
      } catch (_) { /* الفحص اختياري، نتجاهل فشله */ }
    }
  } else {
    showFirstRun();
    syncOnline();
  }
}

boot();
