import assert from "node:assert/strict";
import { buildReport } from "../src/modules/links-import.js";
const d = { checks: { tafsir_link: { rows: 1, expected: 1 }, hadith_link: { rows: 1, expected: 1 }, aya: { rows: 1, expected: 1 }, sura: { rows: 1, expected: 1 }, rawi: { rows: 1, expected: 1 }, esnad: { rows: 1, expected: 1 } }, orphans: 0, tafsirBooks: [86], hadithBooks: [711, 627], tafsirLinks: new Int32Array(), hadithLinks: new Int32Array(), sura: [], aya: [], rawi: { ids: [], names: [], death: [], jarhSamples: [] }, esnad: { byBook: new Map(), samples: new Map() } };
const names = { 711: "صحيح مسلم - ط التركية", 735: "صحيح البخاري - ت البغا", 42: "تفسير السعدي" };
const txt = buildReport(d, { nameOf: (b) => names[b] || "؟" }).join("\n");
assert.match(txt, /- صحيح مسلم - ط التركية \(711\)/); assert.match(txt, /^صحيح البخاري - ت البغا \(735\): في tafsir_book/m);
assert.match(buildReport(d).join("\n"), /كتب الحديث \(2\): 711 627/);
console.log("names OK");
