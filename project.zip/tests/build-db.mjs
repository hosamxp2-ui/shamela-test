import { DatabaseSync } from "node:sqlite";
import fs from "node:fs";
export function build(path) {
  try { fs.unlinkSync(path); } catch {}
  const db = new DatabaseSync(path);
  db.exec(`
  CREATE TABLE roots(token TEXT, root TEXT);
  CREATE TABLE rawi(id INTEGER PRIMARY KEY, name TEXT, full TEXT, death INTEGER, jarh TEXT, details TEXT);
  CREATE TABLE rawi_page(rawi_id INTEGER, book_id INTEGER, page_id INTEGER, hadith INTEGER);
  CREATE TABLE aya(id INTEGER PRIMARY KEY, sura INTEGER, aya INTEGER, text TEXT, uthmani TEXT);
  CREATE TABLE esnad(book_id INTEGER, page_id INTEGER, hadith INTEGER, chain TEXT);
  CREATE TABLE tafsir_link(aya_id INTEGER, book_id INTEGER, page_id INTEGER);
  CREATE TABLE hadith_link(key_id INTEGER, book_id INTEGER, page_id INTEGER);
  CREATE TABLE meta(key TEXT PRIMARY KEY, value TEXT);
  CREATE TABLE hadith_book(book_id INTEGER PRIMARY KEY);
  CREATE TABLE sura(id INTEGER PRIMARY KEY, name TEXT, ayat INTEGER, first_aya INTEGER);
  CREATE TABLE tafsir_book(book_id INTEGER PRIMARY KEY);
  CREATE INDEX ix_roots_tok ON roots(token);
  CREATE INDEX ix_tl_aya ON tafsir_link(aya_id);
  CREATE INDEX ix_hl_key ON hadith_link(key_id);
  CREATE INDEX ix_rp_rawi ON rawi_page(rawi_id);
  `);
  const ins = (sql, rows) => { const st = db.prepare(sql); db.exec("BEGIN"); for (const r of rows) st.run(...r); db.exec("COMMIT"); };
  const R = (n) => Array.from({ length: n }, (_, i) => i);
  ins("INSERT INTO meta VALUES(?,?)", [["version", "1"], ["x", "y"]]);
  ins("INSERT INTO sura VALUES(?,?,?,?)", [[1, "الفاتحة", 7, 1], [2, "البقرة", 286, 8], ...R(112).map((i) => [i + 3, "سورة" + i, 5, 300 + i * 5])]);
  ins("INSERT INTO aya VALUES(?,?,?,?,?)", R(6236).map((i) => [i + 1, 1, i + 1, "نص الآية " + i + " " + "ك".repeat(i % 50), "عثماني" + i]));
  ins("INSERT INTO tafsir_book VALUES(?)", [86, 639, 910, 42, 8473, 1, 2, 3, 4, 5, 6, 7, 8, 9].map((x) => [x]));
  ins("INSERT INTO hadith_book VALUES(?)", [627, 642, 654, 711, 735, 10, 11, 12, 13, 14].map((x) => [x]));
  // tafsir_link: 84430 صفًا مبعثرة، ومنها الكتاب 42 للفاتحة
  const tl = []; for (let i = 0; i < 84430; i++) tl.push([1 + ((i * 7919) % 6236), [86, 639, 910, 8473, 5][i % 5], 100 + (i % 2000)]);
  for (let a = 1; a <= 7; a++) tl.splice(a * 1000, 0, [a, 42, 30 + (a > 4 ? 1 : 0)]);
  ins("INSERT INTO tafsir_link VALUES(?,?,?)", tl);
  const hl = []; for (let i = 0; i < 37076; i++) hl.push([1 + ((i * 104729) % 7000), [627, 642, 654, 735][i % 4], 50 + (i % 3000)]);
  hl.splice(500, 0, [2464, 711, 8], [2464, 627, 421], [89, 711, 11], [91, 711, 12], [91, 642, 77]);
  ins("INSERT INTO hadith_link VALUES(?,?,?)", hl);
  const es = []; for (let i = 0; i < 45220; i++) es.push([[711, 627, 642][i % 3], i, i % 9000, "0" + i + " s " + "2651 3234 1580 2779 6792 3889 6116 ".repeat(1 + (i % 4))]);
  es.splice(0, 0, [711, 8, 2464, "02464 s 2651 3234 1580 2779 6792 3889 6116"]);
  ins("INSERT INTO esnad VALUES(?,?,?,?)", es);
  const rw = []; for (let i = 1; i <= 18989; i++) {
    const long = i % 97 === 0 ? "ج".repeat(6000) : "[]";
    rw.push([i, "راوٍ " + i, "الراوي الكامل " + i, i % 5 === 0 ? null : 100 + (i % 300), i === 3000 ? '[{"k":"ثقة"}]' : long, i % 11 === 0 ? "d".repeat(3000) : "[]"]);
  }
  rw[1650][1] = "ابن عمر"; // id 1651? نضبط أسماء السلسلة أدناه
  ins("INSERT INTO rawi VALUES(?,?,?,?,?,?)", rw);
  db.exec("UPDATE rawi SET name='أبو هريرة', death=57 WHERE id=1580; UPDATE rawi SET name='مالك' , death=179 WHERE id=2651");
  const rp = []; for (let i = 0; i < 100000; i++) rp.push([1 + (i % 18000), 711, i % 9000, i]);
  ins("INSERT INTO rawi_page VALUES(?,?,?,?)", rp);
  const rt = []; for (let i = 0; i < 150000; i++) rt.push(["كلمة" + i, "جذر" + (i % 5000)]);
  ins("INSERT INTO roots VALUES(?,?)", rt);
  db.exec("VACUUM");
  db.close();
}
