import assert from "node:assert/strict";
import { selBarPosition } from "../src/reader/selbar.js";
import * as V from "../src/components/reader-view.js";
import { t } from "../src/strings.js";
const VW = 393, VH = 852, R = (l, t_, r, b) => ({ left: l, top: t_, right: r, bottom: b });
// تحت التحديد في الوضع العادي، ومركزه مركز التحديد
let p = selBarPosition(R(100, 300, 200, 330), VW, VH); assert.deepEqual(p, { left: 150, top: 378 });
// قرب حافة اليمين/اليسار: يُقيَّد داخل الشاشة (نصف عرض الشريط + هامش)
assert.equal(selBarPosition(R(350, 300, 390, 330), VW, VH).left, VW - 100 - 8);
assert.equal(selBarPosition(R(0, 300, 20, 330), VW, VH).left, 108);
// تحديد قرب الشريط السفلي: ينتقل فوق التحديد
p = selBarPosition(R(100, 640, 200, 670), VW, VH); assert.equal(p.top, 540);
// تحديد في أعلى الشاشة: لا يصعد فوق الحد الأدنى
assert.equal(selBarPosition(R(100, 20, 200, 40), VW, VH).top >= 120, true);
// تحديد يغطي الشاشة كلها: يبقى ضمن النطاق المسموح
p = selBarPosition(R(0, 100, 393, 800), VW, VH); assert.ok(p.top >= 120 && p.top <= VH - 190);
// شاشة ضيقة جدًا: لا قيم سالبة
assert.ok(selBarPosition(R(10, 300, 30, 320), 180, 600).left >= 108 - 1);
// القالب: مخفي افتراضيًا، فيه الزران، وضمن قالب القارئ بعد الشرائح وقبل الشريط السفلي
const bar = V.selBarHtml(); assert.match(bar, /id="r-selbar" hidden/); assert.match(bar, /data-r="sel-hl"[^>]*>.*تظليل/s); assert.match(bar, /data-r="sel-note"[^>]*>.*ملاحظة/s);
const shell = V.readerShellHtml({ title: "ك" }); assert.ok(shell.indexOf('id="r-float"') < shell.indexOf('id="r-selbar"') && shell.indexOf('id="r-selbar"') < shell.indexOf('id="r-bottom"'));
for (const k of ["reader.sel.hl", "reader.sel.note"]) assert.notEqual(t(k), k);
console.log("selbar OK");
