import assert from "node:assert/strict";
import { DatabaseSync } from "node:sqlite";
import { parseServices, parseEsnad, indexLinks, buildHadithView, loadLinks, resetLinksCache } from "../src/modules/hadith-links.js";
import { hadithSheetInner, floatHtml } from "../src/components/reader-view.js";
import { openReader } from "../src/reader/reader-engine.js";

// عينات حقيقية من فحص 711 على الهاتف
const s8 = '{"hadeeth": [2464], "esnad": ["02464 s 2651 3234 1580 2779 6792 3889 6116"]}';
const s11 = '{"hadeeth": [89], "esnad": ["089 s 4500 1943 6361 2779 5532 3889 6116", "089 s 4500 1943 6361 2779 5532 5509 6116", "089 s 4500 1943 6361 2779 5532 5898 6116"]}';
const s9 = '{"hadeeth": [2465]}';
assert.deepEqual(parseEsnad("089 s 4500 1943"), { key: 89, ids: [4500, 1943] });
assert.equal(parseEsnad("x"), null); assert.equal(parseEsnad("abc s 1"), null);
assert.equal(parseServices(null), null); assert.equal(parseServices("{bad"), null); assert.equal(parseServices("[]") .keys.length, 0);
const sv8 = parseServices(s8); assert.deepEqual(sv8.keys, [2464]); assert.equal(sv8.esnad[0].ids.length, 7);
assert.equal(parseServices(s11).esnad.length, 3);

// روابط مصطنعة بأسماء السلسلة الحقيقية
const names = { 2651: ["سمرة بن جندب الفزاري", 58], 3234: ["عبد الرحمن بن أبي ليلى", 82], 1580: ["الحكم بن عتيبة", 113], 2779: ["شعبة بن الحجاج", 160], 6792: ["وكيع بن الجراح", 196], 3889: ["عبد الله بن محمد بن أبي شيبة", 235], 6116: ["مسلم بن الحجاج", 261] };
const ids = Object.keys(names).map(Number);
const raw = { version: 1, hadithLinks: Int32Array.from([2464, 1456, 989, 2464, 711, 8, 89, 711, 11, 89, 627, 1291, 89, 627, 1291, 89, 7895, 4635]), rawiIds: Int32Array.from(ids), rawiDeath: Int32Array.from(ids.map((i) => names[i][1])), rawiNames: ids.map((i) => names[i][0]), hadithBooks: [711, 1456] };
const links = indexLinks(raw);
const v = buildHadithView(sv8, links, 711, 8);
assert.equal(v.length, 1);
assert.equal(v[0].chains[0].steps[0].name, "مسلم بن الحجاج"); // صاحب الكتاب أولًا
assert.equal(v[0].chains[0].steps[6].name, "سمرة بن جندب الفزاري");
assert.deepEqual(v[0].groups, [{ book: 1456, pages: [989] }]); // لا يعيد الموضع الحالي
const v11 = buildHadithView(parseServices(s11), links, 711, 11, { maxChains: 2 });
assert.equal(v11[0].chains.length, 2); assert.equal(v11[0].moreChains, 1);
assert.deepEqual(v11[0].groups, [{ book: 627, pages: [1291] }, { book: 7895, pages: [4635] }]); // بلا تكرار
assert.equal(v11[0].chains[0].steps[6].name, null); assert.equal(v11[0].chains[0].steps[6].id, 4500);
// بلا استيراد
const vn = buildHadithView(sv8, null, 711, 8); assert.equal(vn[0].hasLinks, false);
// القالب
const fx = { bookName: (b) => (b === 1456 ? "كتاب <تجربة>" : "#" + b), downloaded: (b) => b === 1456 };
const html = hadithSheetInner(v, fx);
assert.match(html, /مسلم بن الحجاج.*\(ت 261\)/s); assert.match(html, /href="#\/read\/1456\?pid=989"/); assert.ok(!html.includes("<تجربة>")); assert.match(html, /&lt;تجربة&gt;/);
const htmlNd = hadithSheetInner(v11, fx);
assert.match(htmlNd, /راوٍ غير معروف \(4500\)/); assert.match(htmlNd, /href="#\/book\/627"/); assert.match(htmlNd, /غير منزّل/);
assert.match(hadithSheetInner(vn, fx), /استيراد الربط/); assert.ok(!hadithSheetInner(vn, fx).includes("isnad"));
assert.ok(floatHtml({ hadith: true }).includes('data-r="hadith"')); assert.ok(!floatHtml({}).includes('data-r="hadith"'));
// loadLinks: مخزن فارغ/إصدار خاطئ/ناجح + ذاكرة مؤقتة
resetLinksCache(); assert.equal(await loadLinks(async () => null), null);
assert.equal(await loadLinks(async () => ({ version: 9 })), null);
assert.ok(await loadLinks(async () => raw)); let calls = 0; assert.ok(await loadLinks(async () => { calls++; return raw; })); assert.equal(calls, 0);

// المحرك يعيد services ويمكن الانتقال بمعرّف الصفحة
const db = new DatabaseSync(":memory:");
db.exec("CREATE TABLE page(id INTEGER PRIMARY KEY, part TEXT, page INTEGER, number INTEGER, body TEXT, foot TEXT, services TEXT); CREATE TABLE title(id INTEGER PRIMARY KEY, page INTEGER, parent INTEGER, text TEXT);");
db.prepare("INSERT INTO page VALUES(?,?,?,?,?,?,?)").run(8, "1", 10, null, "نص", null, s8);
db.prepare("INSERT INTO page VALUES(?,?,?,?,?,?,?)").run(9, "1", 11, null, "نص2", null, null);
const dbw = { all: (q) => db.prepare(q).all(), close() {} };
const r = await openReader({ id: 711, dl: { getBookBytes: async () => new Uint8Array() }, catalog: { fileInfo: () => null }, open: async () => dbw });
const idx = r.indexOfPageId(8); assert.equal(r.getPage(idx).id, 8); assert.equal(r.getPage(idx).services, s8);
assert.equal(r.getPage(r.indexOfPageId(9)).services, null);
console.log("hadith tests OK");
