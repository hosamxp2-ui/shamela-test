import assert from "node:assert/strict";
import { buildQuranIndex, qnorm } from "../src/modules/quran-index.js";
import { renderPage } from "../src/reader/content.js";
import { indexLinks, tafsirFor } from "../src/modules/hadith-links.js";
import { ayahSheetInner, ayahCandidatesInner } from "../src/components/reader-view.js";

// الفاتحة (نص حقيقي) ثم آيات اختبارية؛ الأنعام تبدأ عند 100 وفيها ١٦٣ آية
const ayaText = [];
ayaText[1] = "بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ";
ayaText[2] = "الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ";
ayaText[3] = "الرَّحْمَنِ الرَّحِيمِ";
ayaText[4] = "مَالِكِ يَوْمِ الدِّينِ";
ayaText[5] = "إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ";
ayaText[6] = "اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ";
ayaText[7] = "صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ";
for (let i = 8; i < 100; i++) ayaText[i] = "كلمة" + String.fromCharCode(0x0627 + (i % 20)) + " اختبار" + String.fromCharCode(0x0628 + (i % 17)) + " نص";
ayaText[50] = "فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ"; ayaText[60] = "فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ";
ayaText[99] = "رب خاتمة"; 
for (let i = 100; i < 263; i++) ayaText[i] = "آية أنعام رقم" + " " + String.fromCharCode(0x0627 + (i % 25)) + String.fromCharCode(0x0628 + (i % 23));
ayaText[262] = "وَأَنَا أَوَّلُ الْمُسْلِمِينَ";
const sura = [{ id: 1, name: "الفاتحة", ayat: 7, first: 1 }, { id: 2, name: "الاختبار", ayat: 92, first: 8 }, { id: 6, name: "الأنعام", ayat: 163, first: 100 }];
const q = buildQuranIndex({ ayaText, sura });

assert.equal(qnorm("ٱلرَّحۡمَٰنِ ٱلرَّحِيمِ"), "الرحمن الرحيم"); // رسم عثماني
assert.deepEqual(q.find("الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ"), { conf: "exact", from: 2, to: 2 });
assert.deepEqual(q.find("رب العالمين"), { conf: "exact", from: 2, to: 2 });          // جزء من آية
assert.equal(q.find("الرب العالمين"), null);                                            // حدود الكلمات
assert.deepEqual(q.find("مالك يوم الدين إياك نعبد"), { conf: "exact", from: 4, to: 5 }); // يعبر آيتين
assert.equal(q.find("الحمد"), null);                                                    // كلمة واحدة
const m = q.find("فبأي آلاء ربكما تكذبان"); assert.equal(m.conf, "many"); assert.deepEqual(m.cands, [50, 60]); assert.equal(m.total, 2);
// المرجع
assert.deepEqual(q.parseRef(" /الأنعام: ١٦٣/ تتمة"), { from: 262, to: 262 });
assert.deepEqual(q.parseRef("[سورة الأنعام: 163]"), { from: 262, to: 262 });
assert.equal(q.parseRef(" /الأنعام: ٥٠٠/"), null);   // آية خارج السورة
assert.equal(q.parseRef(" /سورة مجهولة: ٣/"), null);
assert.deepEqual(q.find("وأنا أول المسلمين", " /الأنعام: ١٦٣/"), { conf: "sure", from: 262, to: 262 });
assert.deepEqual(q.find("وأنا أول المسلمين", " /الفاتحة: ٣/"), { conf: "ref", from: 3, to: 3 });  // مرجع لا يطابق النص
assert.deepEqual(q.find("فبأي آلاء ربكما تكذبان", " (الاختبار: ٤٣)"), { conf: "sure", from: 50, to: 50 }); // يحسم التكرار: 8+43-1=50
assert.deepEqual(q.label(262), { sura: 6, name: "الأنعام", aya: 163 }); assert.equal(q.label(5000), null);

// التغليف داخل HTML
const html = q.wrapVerses('<p>قال تعالى ﴿وأنا أول المسلمين﴾ /الأنعام: ١٦٣/ وقال <span data-type="title">﴿الحمد لله رب العالمين﴾</span> و﴿نص ليس في القرآن أبدا﴾ و﴿فبأي آلاء ربكما تكذبان﴾</p>');
assert.match(html, /<span class="ayah" data-conf="sure" data-a="262" data-b="262">﴿وأنا أول المسلمين﴾<\/span> \/الأنعام/);
assert.match(html, /data-conf="exact" data-a="2" data-b="2">﴿الحمد لله رب العالمين﴾/);
assert.match(html, /data-conf="many" data-cands="50,60" data-total="2"/);
assert.ok(html.includes("﴿نص ليس في القرآن أبدا﴾</p>") === false && html.includes("و﴿نص ليس في القرآن أبدا﴾ و"));   // غير مطابق: بلا تغليف
// داخل renderPage
const r = renderPage({ body: "ثم ﴿صراط الذين أنعمت عليهم﴾ (¬١)", foot: "(¬١) هامش" }, { quran: q });
assert.match(r.bodyHtml, /class="ayah" data-conf="exact" data-a="7" data-b="7"/); assert.match(r.bodyHtml, /fnref/);
assert.equal(renderPage({ body: "﴿صراط الذين أنعمت عليهم﴾", foot: "" }).bodyHtml.includes("ayah"), false); // بلا فهرس لا تغليف

// التفاسير من tafsir_link
const idx = indexLinks({ version: 1, tafsirLinks: Int32Array.from([2, 86, 20, 2, 86, 21, 2, 639, 77, 3, 86, 22]), tafsirBooks: [86, 639], ayaText: ayaText.map((x) => x || ""), sura, hadithLinks: [], rawiIds: [] });
assert.deepEqual(tafsirFor(idx, 2), [{ book: 86, pages: [20, 21] }, { book: 639, pages: [77] }]);
assert.deepEqual(tafsirFor(idx, 999), []); assert.deepEqual(tafsirFor(null, 2), []);
assert.equal(idx.quran.find("رب العالمين").from, 2);
const fx = { bookName: (b) => "كتاب " + b, downloaded: (b) => b === 86 };
const sheet = ayahSheetInner({ loc: "سورة الفاتحة • آية 2", text: ayaText[2], conf: "exact", hasLinks: true, groups: tafsirFor(idx, 2), note: "" }, fx);
assert.match(sheet, /href="#\/read\/86\?pid=20"/); assert.match(sheet, /href="#\/book\/639"/); assert.match(sheet, /مرجّح/);
assert.match(ayahSheetInner({ loc: "", text: "", conf: "exact", hasLinks: false, groups: [] }, fx), /استيراد الربط/);
assert.match(ayahCandidatesInner(31, [{ id: 50, loc: "x", text: "y" }]), /data-ayah="50"/);
console.log("quran tests OK");
