import assert from "node:assert/strict";
import { readerErrorHtml } from "../src/components/reader-view.js";
import { openReader } from "../src/reader/reader-engine.js";
// الرسالة وحدها لما لا يُسمح بالقوة (أكبر من الحد الأقصى أو خطأ آخر)
const plain = readerErrorHtml("كبير جدًا", 25794, false);
assert.match(plain, /كبير جدًا/); assert.ok(!plain.includes("force=1"));
// فوق الحد التلقائي: تحذير وزر برابط force للكتاب نفسه
const big = readerErrorHtml("هذا الكتاب كبير جدًا (107 ميغابايت)", 25794, true);
assert.match(big, /href="#\/read\/25794\?force=1"/); assert.match(big, /فتحه رغم ذلك/); assert.match(big, /ذاكرة/);
assert.ok(readerErrorHtml("<b>x</b>", 1, false).includes("&lt;b&gt;"));      // تهريب
// الخطأ الذي يُلتقط في القارئ يحمل code ليظهر الزر
const mk = (mb) => ({ catalog: { fileInfo: () => ({ size: mb * 1048576 }) }, dl: { getBookBytes: async () => new Uint8Array() }, id: 25794 });
await assert.rejects(openReader({ ...mk(107), open: async () => ({ all: () => [], close() {} }) }), (e) => e.code === "TOO_BIG_READ" && e.name === "ConnectorError");
console.log("bigbook OK");
