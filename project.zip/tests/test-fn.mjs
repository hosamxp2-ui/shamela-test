import assert from "node:assert/strict";
import { parseFootnotes, renderPage } from "../src/reader/content.js";
// 711: (¬١)
const e = parseFootnotes("(¬١) قوله: كذا. (¬٢) في نسخة: كذا.");
assert.deepEqual(e.map((x) => x.n), [1, 2]);
const r = renderPage({ body: "والعاقبة للمتقين (¬١)، وصلى (¬٢)", foot: "(¬١) قوله: كذا. (¬٢) في نسخة." });
assert.match(r.bodyHtml, /data-fn="1"/); assert.match(r.bodyHtml, /data-fn="2"/); assert.equal(r.linked.size, 2);
// الصيغة القديمة (١) لا تتأثر
const r2 = renderPage({ body: "نص (١) ونص", foot: "(١) هامش" });
assert.match(r2.bodyHtml, /data-fn="1"/);
// عدم الخلط: رقم شارد غير متتابع يُتجاهل كما قبل
assert.deepEqual(parseFootnotes("(١) أ (٥) ب (٢) ج").map((x) => x.n), [1, 2]);
console.log("footnote ¬ OK");
