import { DatabaseSync } from "node:sqlite";
import fs from "node:fs";
import zlib from "node:zlib";
import assert from "node:assert/strict";
import { build } from "./build-db.mjs";
import { createScanner } from "../src/services/sqlite-scan.js";
import { createCollector, buildReport, importLinks } from "../src/modules/links-import.js";

build("/tmp/svc-test.db");
const bytes = new Uint8Array(fs.readFileSync("/tmp/svc-test.db"));
console.log("db bytes", bytes.length);
const db = new DatabaseSync("/tmp/svc-test.db");
const one = (q) => db.prepare(q).get();

// 1) المسح مباشرة بقطع عشوائية الحجم
function run() {
  const col = createCollector();
  const sc = createScanner({ onLeaf: col.onLeaf });
  let off = 0, seed = 7;
  while (off < bytes.length) { seed = (seed * 1103515245 + 12345) & 0x7fffffff; const n = 1 + (seed % 20000); sc.push(bytes.subarray(off, off + n)); off += n; }
  const rep = sc.finish();
  return { d: col.resolve(sc, rep), rep };
}
const { d, rep } = run();
const cnt = (t) => one(`SELECT count(*) c FROM ${t}`).c;
for (const t of ["tafsir_link", "hadith_link", "aya", "sura", "rawi", "esnad"]) { assert.equal(d.checks[t].rows, cnt(t), t + " rows"); assert.equal(d.checks[t].expected, cnt(t), t + " expected"); }
assert.equal(d.orphans, 0);
assert.deepEqual(d.tafsirBooks, db.prepare("SELECT book_id FROM tafsir_book ORDER BY 1").all().map((r) => r.book_id));
assert.deepEqual(d.hadithBooks, db.prepare("SELECT book_id FROM hadith_book ORDER BY 1").all().map((r) => r.book_id));
// محتوى tafsir_link/hadith_link مطابق كمجموعة وبالترتيب
const flat = (rows, k) => rows.flatMap((r) => [r[k[0]], r[k[1]], r[k[2]]]);
assert.deepEqual(Array.from(d.tafsirLinks), flat(db.prepare("SELECT aya_id,book_id,page_id FROM tafsir_link ORDER BY rowid").all(), ["aya_id", "book_id", "page_id"]));
assert.deepEqual(Array.from(d.hadithLinks), flat(db.prepare("SELECT key_id,book_id,page_id FROM hadith_link ORDER BY rowid").all(), ["key_id", "book_id", "page_id"]));
// aya, sura, rawi
assert.equal(d.aya[7], one("SELECT text FROM aya WHERE id=7").text);
assert.equal(d.aya[6236], one("SELECT text FROM aya WHERE id=6236").text);
assert.deepEqual(d.sura.slice(0, 2), [{ id: 1, name: "الفاتحة", ayat: 7, first: 1 }, { id: 2, name: "البقرة", ayat: 286, first: 8 }]);
const i1580 = d.rawi.ids.indexOf(1580); assert.equal(d.rawi.names[i1580], "أبو هريرة"); assert.equal(d.rawi.death[i1580], 57);
assert.equal(d.rawi.death[d.rawi.ids.indexOf(5)], -1); // death NULL
assert.equal(d.rawi.jarhSamples.length >= 1, true);
assert.equal(d.esnad.byBook.get(711), cnt("esnad WHERE book_id=711") );
console.log("scanner+collector OK; overflow rawi rows:", cnt("rawi WHERE length(jarh)>3000"));

// 2) التقرير
const lines = buildReport(d, { complete: true, bytes: 1234567 });
console.log(lines.join("\n"));
const txt = lines.join("\n");
assert.match(txt, /الكتاب 42، آيات الفاتحة 1–7 \(آية:صفحة\): 1:30 2:30 3:30 4:30 5:31 6:31 7:31/);
assert.match(txt, /المفتاح 2464 ← .*711:8.*ضمنها؟ نعم/);
assert.match(txt, /أبو هريرة \(ت 57\)/);

// 3) المسار الكامل importLinks عبر مصدر مزيّف وفك gzip
const gz = zlib.gzipSync(Buffer.from(bytes));
const source = { manifest: async () => ({ data: { services: { size: gz.length, raw_size: bytes.length } } }), dbRange: async (m, w, from, len) => new Uint8Array(gz.subarray(from, from + len)) };
class Gunzip { constructor(cb) { this.cb = cb; this.parts = []; } push(b, last) { this.parts.push(Buffer.from(b)); if (last) { const raw = zlib.gunzipSync(Buffer.concat(this.parts)); for (let o = 0; o < raw.length; o += 300000) this.cb(new Uint8Array(raw.subarray(o, o + 300000))); } } }
let saved = null;
const res = await importLinks({ source, fflate: { Gunzip }, chunk: 100000, store: async (k, v) => { saved = { k, v }; }, dataVersion: "1448-2" });
assert.equal(res.complete, true);
assert.equal(saved.k, "services-links");
assert.equal(saved.v.tafsirLinks.length, 84430 * 3 + 21);
assert.equal(saved.v.hadithLinks.length, (37076 + 5) * 3);
assert.equal(saved.v.rawiIds.length, 18989);
structuredClone(saved.v); // قابل للتخزين في IndexedDB
console.log("importLinks OK, payload keys:", Object.keys(saved.v).join(","));

// 4) إيقاف المسح: لا حفظ
let saved2 = null;
const tok = { cancelled: false };
const src2 = { ...source, dbRange: async (m, w, f, l) => { tok.cancelled = true; return source.dbRange(m, w, f, l); } };
const r2 = await importLinks({ source: src2, fflate: { Gunzip }, token: tok, store: async () => { saved2 = 1; } });
assert.equal(r2.complete, false); assert.equal(saved2, null);
console.log("cancel OK");
