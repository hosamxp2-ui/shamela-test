import assert from "node:assert/strict";
import { renderPage } from "../src/reader/content.js";
const r = renderPage({ body: "قال (¬٨) فلان (¬٨) وغيره (¬٩) ثم (¬١٥) وآخر (٣٠)", foot: "(¬٨) أ (¬٩) ب" });
assert.ok(!r.bodyHtml.includes("¬"), r.bodyHtml);
assert.equal((r.bodyHtml.match(/data-fn="8"/g) || []).length, 1); // الأول فقط قابل للنقر
assert.equal((r.bodyHtml.match(/class="fnref off"/g) || []).length, 2); // المكرر والمجهول
assert.match(r.bodyHtml, /\(٣٠\)/); // بلا ¬: نص عادي لا يُمسّ
assert.match(r.notesHtml, /<bdi dir="ltr">\(٨\)<\/bdi>/);
assert.equal(r.linked.size, 2);
// تمييز البحث لا يكسر الوسوم
const h = renderPage({ body: "فلان (¬١) قال", foot: "(¬١) هامش" }, { highlightTerms: ["فلان"] });
assert.match(h.bodyHtml, /<mark class="hl">فلان<\/mark>/); assert.match(h.bodyHtml, /<bdi dir="ltr">\(١\)<\/bdi>/);
// الصيغة العادية (١) كما كانت
const o = renderPage({ body: "نص (١) ونص (١)", foot: "(١) هامش" });
assert.equal((o.bodyHtml.match(/data-fn="1"/g) || []).length, 1); assert.match(o.bodyHtml, /ونص \(١\)<\/p>/);
console.log("fn bidi OK");
