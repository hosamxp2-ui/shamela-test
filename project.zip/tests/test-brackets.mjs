import assert from "node:assert/strict";
import { buildQuranIndex, scanSegments } from "../src/modules/quran-index.js";
const ayaText = []; ayaText[1] = "بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ"; ayaText[2] = "الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ"; ayaText[3] = "الرَّحْمَنِ الرَّحِيمِ"; ayaText[4] = "مَالِكِ يَوْمِ الدِّينِ"; ayaText[5] = "فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ"; ayaText[6] = "فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ";
const q = buildQuranIndex({ ayaText, sura: [{ id: 1, name: "الفاتحة", ayat: 6, first: 1 }] });
const segs = scanSegments("أ (قال ﴿الحمد لله رب العالمين﴾ هنا) ثم (مالك يوم الدين) و{الرحمن الرحيم} و«x» و[٣]");
assert.deepEqual(segs.map((s) => s.kind), ["fancy", "paren", "curly"].concat(segs.length > 3 ? segs.slice(3).map((s) => s.kind) : []));
assert.ok(!segs.some((s) => s.kind === "paren" && s.inner.includes("﴿")));   // القوس الحاوي لـ﴿﴾ لا يبتلعها
const h = q.wrapVerses("<p>أ (قال ﴿الحمد لله رب العالمين﴾ هنا) ثم (مالك يوم الدين) و{الرحمن الرحيم} و(الرحمن الرحيم) و(بسم الله) و(فبأي آلاء ربكما تكذبان)</p>");
assert.match(h, /<span class="ayah" data-conf="exact" data-a="2" data-b="2">﴿الحمد لله رب العالمين﴾<\/span> هنا\)/);   // ﴿﴾ داخل ( )
assert.match(h, /data-a="4" data-b="4">\(مالك يوم الدين\)<\/span>/);       // ( ) بثلاث كلمات
assert.ok(!h.includes('>{الرحمن الرحيم}<'));                               // كلمتان فقط في قوس غير ﴿﴾ → لا
assert.ok(!h.includes('>(بسم الله)<'));                                    // كلمتان
assert.ok(!/data-conf="many"[^>]*>\(فبأي/.test(h));                         // الملتبس لا يُغلَّف في الأقواس الأخرى
assert.match(q.wrapVerses("﴿فبأي آلاء ربكما تكذبان﴾"), /data-conf="many"/);  // ﴿﴾ يبقى كما كان
console.log("brackets OK");
