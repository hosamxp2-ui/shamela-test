import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
const css = readFileSync(new URL("../src/styles/reader.css", import.meta.url), "utf8");
// حارس: لا قاعدة تخفي كل <header> أثناء القراءة (كانت تخفي شريط القارئ العلوي نفسه)
assert.ok(!/body\.reading\s+header/.test(css), "قاعدة body.reading header تخفي شريط القارئ");
assert.match(css, /body\.reading\s*>\s*header/);
assert.match(css, /\.reader\s*\{\s*padding-top:\s*max\(env\(safe-area-inset-top/);
// الشريط العلوي في قالب القارئ عنصر header داخل .reader (لا ابن مباشر للـ body)
const html = readFileSync(new URL("../index.html", import.meta.url), "utf8");
assert.match(html, /<body>\s*<header class="appbar">/);   // شريط التطبيق ابن مباشر للـ body فيُخفى بالقاعدة المحدّدة
console.log("css OK");
