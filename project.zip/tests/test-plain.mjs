import assert from "node:assert/strict";
import { buildQuranIndex } from "../src/modules/quran-index.js";
import { renderPage } from "../src/reader/content.js";
const ayaText = []; ayaText[1] = "بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ"; ayaText[2] = "الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ"; ayaText[3] = "الرَّحْمَنِ الرَّحِيمِ"; ayaText[4] = "مَالِكِ يَوْمِ الدِّينِ"; ayaText[5] = "إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ"; ayaText[6] = "اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ";
ayaText[7] = "فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ"; ayaText[8] = "فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ"; ayaText[9] = "وَأَنَا أَوَّلُ الْمُسْلِمِينَ وَقَالَ الرَّسُولُ يَا رَبِّ";
const q = buildQuranIndex({ ayaText, sura: [{ id: 1, name: "الفاتحة", ayat: 9, first: 1 }] });
// 1) مقطع متصل عبر آيات بتشكيل وبلا أقواس
const t1 = "قال الله تعالى في سورة الفاتحة الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ الرَّحْمَنِ الرَّحِيمِ مَالِكِ يَوْمِ الدِّينِ ثم قال المفسر كذا";
const runs = q.plainRuns(t1);
assert.equal(runs.length, 1); assert.deepEqual([runs[0].from, runs[0].to], [2, 4]);
assert.equal(t1.slice(runs[0].start, runs[0].end), "الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ الرَّحْمَنِ الرَّحِيمِ مَالِكِ يَوْمِ الدِّينِ");  // حدود المقطع دقيقة بتشكيله
// 2) أقل من خمس كلمات، أو ملتبس بين موضعين، أو كلام عادي: لا شيء
assert.deepEqual(q.plainRuns("الحمد لله رب العالمين فقط"), []);                   // 4 كلمات
assert.deepEqual(q.plainRuns("وقال فبأي آلاء ربكما تكذبان يا قوم"), []);              // موضعان (7 و8)
assert.deepEqual(q.plainRuns("هذا كلام عادي لا علاقة له بالقرآن أبدا ولا بغيره من الكتب"), []);
// 3) لا يبتلع ما بين الأقواس ولا يتداخل معه
const h = q.wrapVerses("<p>قال ﴿الحمد لله رب العالمين﴾ ثم شرح فقال الرحمن الرحيم مالك يوم الدين إياك نعبد وإياك نستعين وانتهى</p>");
const spans = [...h.matchAll(/<span class="ayah" data-conf="(\w+)" data-a="(\d+)" data-b="(\d+)">([^<]*)<\/span>/g)].map((m) => [m[1], +m[2], +m[3], m[4]]);
assert.deepEqual(spans.map((x) => x.slice(0, 3)), [["exact", 2, 2], ["plain", 3, 5]]);
assert.equal(spans[1][3], "الرحمن الرحيم مالك يوم الدين إياك نعبد وإياك نستعين");
// 4) داخل renderPage + الأوسمة لا تُمسّ + الهوامش تعمل مع النص
const r = renderPage({ body: "<span data-type='title'>باب</span> قال الرحمن الرحيم مالك يوم الدين إياك نعبد وإياك نستعين (¬١)", foot: "(¬١) هامش" }, { quran: q });
assert.match(r.bodyHtml, /data-conf="plain" data-a="3" data-b="5"/); assert.match(r.bodyHtml, /fnref/); assert.ok(!r.bodyHtml.includes("<span class=\"ayah\" data-conf=\"plain\" data-a=\"3\" data-b=\"5\"><span"));
// 5) أداء: صفحة طويلة
const long = ("كلام عادي كثير عن مسائل الفقه والأصول والتفسير ").repeat(400) + "الرحمن الرحيم مالك يوم الدين إياك نعبد";
let t0 = performance.now(); const hh = q.wrapVerses("<p>" + long + "</p>"); const ms = performance.now() - t0;
assert.match(hh, /data-conf="plain"/); assert.ok(ms < 200, "slow: " + ms);
console.log("plain OK", ms.toFixed(1) + "ms");
