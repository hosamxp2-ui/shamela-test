import assert from "node:assert/strict";
import { shingles, buildIndex, prepareIndex, matchPage, matchHashes, evaluate, buildMatchView, loadTextIndex, resetTextIndexCache, PARAMS } from "../src/modules/hadith-text.js";
import { buildHadithTextIndex } from "../src/modules/hadith-text-build.js";
import { hadithMatchInner, floatHtml } from "../src/components/reader-view.js";
import { indexLinks } from "../src/modules/hadith-links.js";

let seed = 12345; const rnd = () => (seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296;
const letters = "ابتثجحخدذرزسشصضطظعغفقكلمنهوي";
const vocab = Array.from({ length: 3000 }, () => Array.from({ length: 2 + Math.floor(rnd() * 5) }, () => letters[Math.floor(rnd() * letters.length)]).join(""));
const matn = () => Array.from({ length: 35 + Math.floor(rnd() * 45) }, () => vocab[Math.floor(rnd() * vocab.length)]);
const common = "قال رسول الله صلى الله عليه وسلم".split(" ");
const N = 600; const hadiths = Array.from({ length: N }, (_, i) => ({ key: 1000 + i, words: [...common, ...matn()] }));
const variant = (ws) => ws.map((w, i) => (i % 17 === 5 ? vocab[(i * 31) % vocab.length] : w)); // تغيير كلمة كل 17
const isnad = () => "حدثنا " + Array.from({ length: 12 }, () => vocab[Math.floor(rnd() * vocab.length)]).join(" ");
const mkBook = (variantOn) => hadiths.map((h, i) => ({ id: i + 1, body: `<span>${isnad()}</span> ` + (variantOn ? variant(h.words) : h.words).join(" ") + " (¬١)", services: JSON.stringify({ hadeeth: [h.key] }) }));
const books = { 711: mkBook(false), 1456: mkBook(true), 627: mkBook(true).slice(0, 400) };
// كتاب غير مرتبط (طبعة أخرى): صفحاته نصوص الأحاديث نفسها بلا services، منها صفحات عناوين قصيرة
books[999] = hadiths.slice(0, 300).flatMap((h, i) => [{ id: i * 2 + 1, body: "باب كذا", services: null }, { id: i * 2 + 2, body: variant(h.words).join(" "), services: null }]);
import { DatabaseSync } from "node:sqlite";
const mkDb = (rows) => { const d = new DatabaseSync(":memory:"); d.exec("CREATE TABLE page(id INTEGER PRIMARY KEY, body TEXT, services TEXT)"); const st = d.prepare("INSERT INTO page VALUES(?,?,?)"); for (const r of rows) st.run(r.id, r.body, r.services); return { all: (q) => d.prepare(q).all(), close() {} }; };
let stored = null;
const res = await buildHadithTextIndex({ books: [711, 1456, 627], openBook: async (b) => mkDb(books[b]), store: async (k, v) => { stored = v; }, evalPerBook: 100, chunk: 150, statusLines: ['✓ كتاب تجريبي'], coverageBooks: [999], locate: (k) => 'موضع ' + k });
console.log(res.lines.join("\n"));
assert.equal(res.idx.keys, N);
assert.ok(res.idx.droppedCommon > 0);
const covLine = res.lines.find((l) => l.startsWith("#999:")); console.log(covLine);
assert.match(covLine, /صفحات نصية 300 \| مغطّاة (\d+)/); assert.ok(Number(/مغطّاة (\d+)/.exec(covLine)[1]) >= 285); // الصفحات القصيرة لا تُحسب
assert.ok(res.lines.some((l) => /عينة: صفحة معرّفها \d+ ← حديث مفتاح \d+ بنسبة \d+٪ ← موضع \d+/.test(l))); // عبارة «قال رسول الله…» حُذفت لشيوعها
const idx = prepareIndex(stored);

// صفحة من كتاب غير مرتبط: متن حديث 1100 بلفظ مغاير قليلًا + شرح لا علاقة له + حديث آخر 1200
const target = hadiths[100].words, other = hadiths[200].words;
const comment = Array.from({ length: 80 }, () => vocab[Math.floor(rnd() * vocab.length)]).join(" ");
const page = "<p>باب كذا</p> " + variant(target).join(" ") + " " + comment + " " + other.join(" ");
const c = matchPage(idx, page);
const keys = c.map((x) => x.key);
console.log("candidates", c.map((x) => x.key + ":" + Math.round(x.score * 100) + "%/" + x.shared).join(" "));
assert.ok(keys.includes(1100) && keys.includes(1200)); assert.equal(c.length >= 2 && c.length <= 4, true);
assert.ok(c.every((x) => x.key === 1100 || x.key === 1200 || x.score < 0.6));
// صفحة لا علاقة لها: بلا مرشحين
const noise = Array.from({ length: 200 }, () => vocab[Math.floor(rnd() * vocab.length)]).join(" ");
assert.equal(matchPage(idx, noise).length, 0);
// صفحة فيها العبارة الشائعة فقط: لا مرشحين
assert.equal(matchPage(idx, "قال رسول الله صلى الله عليه وسلم " + noise.slice(0, 40)).length, 0);
// نص فارغ
assert.equal(matchPage(idx, "").length, 0); assert.equal(matchPage(idx, null).length, 0);

// التقييم الذاتي: نريد إصابة عالية وترشيحًا خاطئًا قليلًا بالعتبة الافتراضية
const text = res.lines.join("\n");
const rowsEval = text.split("\n").filter((l) => /^#\d+ \| 4\/0\.4/.test(l) || /^.* \| 4\/0\.4 \|/.test(l));
assert.ok(rowsEval.length >= 3);
for (const l of rowsEval) { const f = l.split(" | "); const pages = +f[2], any = +f[3], wrong = +f[6]; assert.ok(pages > 50); assert.ok(any / pages > 0.9, l); assert.ok(wrong / pages < 0.05, l); }

// العرض
const links = indexLinks({ version: 1, hadithLinks: Int32Array.from([1100, 711, 101, 1100, 1456, 101, 1200, 711, 201]), rawiIds: [] });
const mv = buildMatchView(c, links, 735, 55);
const v1100 = mv.find((x) => x.key === 1100); assert.deepEqual(v1100.groups.map((g) => g.book), [711, 1456]); assert.ok(v1100.pct >= 40);
const fx = { bookName: (b) => "كتاب " + b, downloaded: (b) => b === 711 };
const html = hadithMatchInner(mv, fx); assert.match(html, /href="#\/read\/711\?pid=101"/); assert.match(html, /href="#\/book\/1456"/); assert.match(html, /تطابق \d+٪/); assert.match(html, /مطابقة نصية لا معرّف رسمي/);
assert.match(floatHtml({ hadith: "guess" }), /حديث؟/); assert.match(floatHtml({ hadith: true }), /❝ حديث</);
// التحميل
resetTextIndexCache(); assert.equal(await loadTextIndex(async () => null), null);
resetTextIndexCache(); assert.ok((await loadTextIndex(async () => stored)).keys === N); resetTextIndexCache(); assert.equal(await loadTextIndex(async () => ({ version: 1 })), null);
structuredClone(stored);
// حد القيم: مفتاح خارج النطاق يُتجاهل بلا انهيار
const big = [{ key: 3000000, hashes: new Set([5, 6]) }, { key: 7, hashes: new Set([5]) }]; assert.equal(buildIndex(big).keys, 1);
console.log("hadith text tests OK");

// حدود فتح الكتب الكبيرة
import { openReader } from "../src/reader/reader-engine.js";
const mk = (mb) => ({ catalog: { fileInfo: () => ({ size: mb * 1048576 }) }, dl: { getBookBytes: async () => new Uint8Array() }, id: 1 });
const dbw = { all: (q) => q.includes("SELECT id FROM page") ? [{ id: 1 }] : [], close() {} };
await assert.rejects(openReader({ ...mk(107), open: async () => dbw }), (e) => e.code === "TOO_BIG_READ");
assert.ok(await openReader({ ...mk(107), open: async () => dbw, force: true }));
await assert.rejects(openReader({ ...mk(300), open: async () => dbw, force: true }), (e) => e.code === "TOO_BIG_HARD");
assert.ok(await openReader({ ...mk(50), open: async () => dbw }));
console.log("limits OK");
