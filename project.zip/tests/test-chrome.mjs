import assert from "node:assert/strict";
import { sanitize, toParagraphs, applyHighlights, renderPage } from "../src/reader/content.js";
import { createNotesStore } from "../src/modules/notes.js";
import * as V from "../src/components/reader-view.js";
import { t } from "../src/strings.js";

// ---- 1) فواصل الأسطر: كان النص يلتصق في كتب فواصلها غير \n ----
const paras = (b) => toParagraphs(sanitize(b));
const expect3 = ["- ... ﴿بسم الله﴾ .", "من سورة البقرة:", "- ... ﴿الم﴾ ."];
assert.deepEqual(paras("- ... ﴿بسم الله﴾ .\nمن سورة البقرة:\n- ... ﴿الم﴾ ."), expect3);               // \n (كما كان)
assert.deepEqual(paras("- ... ﴿بسم الله﴾ .\r\nمن سورة البقرة:\r\n- ... ﴿الم﴾ ."), expect3);          // \r\n
assert.deepEqual(paras("- ... ﴿بسم الله﴾ .\rمن سورة البقرة:\r- ... ﴿الم﴾ ."), expect3);             // \r وحده
assert.deepEqual(paras("- ... ﴿بسم الله﴾ .\u2028من سورة البقرة:\u2029- ... ﴿الم﴾ ."), expect3);     // LS/PS
assert.deepEqual(paras("- ... ﴿بسم الله﴾ .\u000bمن سورة البقرة:\u000c- ... ﴿الم﴾ ."), expect3);     // VT/FF
assert.deepEqual(paras("<p>- ... ﴿بسم الله﴾ .</p><p>من سورة البقرة:</p><div>- ... ﴿الم﴾ .</div>"), expect3);  // وسوم كتلية بلا أسطر
assert.deepEqual(paras("<ul><li>أ</li><li>ب</li></ul>"), ["أ", "ب"]);
assert.deepEqual(paras("سطر<br>داخل فقرة"), ["سطر<br>داخل فقرة"]);                                   // <br> يبقى داخل الفقرة
assert.deepEqual(paras("<script>x()</script>نص<span data-type='title'>عنوان</span>"), ["نص<span data-type=\"title\">عنوان</span>"]);   // لا انكسار الأوسمة المسموحة
assert.ok(!paras("<div onclick=\"x()\">آمن</div>").join("").includes("onclick"));
const rp = renderPage({ body: "الأول\rالثاني\u2028الثالث", foot: "" });
assert.equal((rp.bodyHtml.match(/<p/g) || []).length, 3);

// ---- 2) التظليل ----
const html = "<p>قال تعالى ﴿ذلك الكتاب لا ريب فيه﴾ والله أعلم</p><p>فقرة ثانية فيها كلام</p>";
const h1 = applyHighlights(html, [{ id: "a", quote: "لا ريب فيه" }]);
assert.match(h1, /<mark class="hlt" data-hl="a">لا ريب فيه<\/mark>/);
assert.equal(applyHighlights(html, [{ id: "b", quote: "غير موجود" }]), html);
assert.equal(applyHighlights(html, []), html); assert.equal(applyHighlights(html, [{ id: "c", quote: "   " }]), html);
// مقتطف يعبر فقرتين: يُظلَّل أطول سطر فيه
const h2 = applyHighlights(html, [{ id: "d", quote: "والله أعلم\nفقرة ثانية فيها كلام" }]);
assert.match(h2, /<mark class="hlt" data-hl="d">فقرة ثانية فيها كلام<\/mark>/);
// لا يدخل الأوسمة ولا يكرّر: أول ظهور فقط، وتهريب HTML
const h3 = applyHighlights("<p>a &amp; b a</p>", [{ id: "e", quote: "a &" }]); assert.match(h3, /<mark class="hlt" data-hl="e">a &amp;<\/mark> b a/);
assert.equal((applyHighlights("<p>كلمة كلمة</p>", [{ id: "f", quote: "كلمة" }]).match(/<mark/g) || []).length, 1);
assert.ok(!applyHighlights('<p data-x="كلمة">نص</p>', [{ id: "g", quote: "كلمة" }]).includes("<mark"));   // لا داخل الخصائص
assert.ok(applyHighlights("<p>x</p>", [{ id: '"><b>', quote: "x" }]).includes("&quot;&gt;&lt;b&gt;"));    // تهريب المعرّف

// ---- 3) مخزن الملاحظات: التظليلات ----
const kv = new Map(); const store = createNotesStore({ get: async (k) => kv.get(k) ?? null, set: async (k, v) => { kv.set(k, structuredClone(v)); }, now: () => 1, id: (() => { let n = 0; return () => "id" + ++n; })() });
await store.load(711);
const a = await store.addHighlight(711, { pageIndex: 3, pageId: 4, label: "ص3", quote: "  نص مظلل  " });
assert.equal(a.kind, "highlight"); assert.equal(a.quote, "نص مظلل"); assert.equal(await store.addHighlight(711, { pageIndex: 3, pageId: 4, label: "x", quote: "   " }), null);
assert.equal((await store.addHighlight(711, { pageIndex: 3, pageId: 4, label: "ص3", quote: "نص مظلل" })).id, a.id);   // لا تكرار
assert.equal(store.highlightsOn(711, 3).length, 1); assert.equal(store.highlightsOn(711, 4).length, 0);
assert.deepEqual(store.pageMarks(711, 3), { bookmark: false, notes: 0 });                  // التظليل ليس ملاحظة
assert.equal(kv.get("notes:711").length, 1); assert.deepEqual(kv.get("notes:index"), [711]);
assert.equal(await store.remove(711, a.id), true); assert.equal(store.highlightsOn(711, 3).length, 0);

// ---- 4) القوالب ----
const shell = V.readerShellHtml({ title: "تفسير <الطبري>" });
for (const id of ['id="r-top"', 'id="r-sub"', 'id="r-bm"', 'id="r-slider"', 'id="r-pos"', 'id="r-float"', 'id="r-sheet"', 'id="r-scroll"', 'id="r-page"', 'id="r-dim"']) assert.ok(shell.includes(id), id);
for (const act of ["back", "search", "settings", "bookmark", "toc", "more", "prev", "next"]) assert.ok(shell.includes(`data-r="${act}"`), act);
assert.ok(shell.includes("&lt;الطبري&gt;") && !shell.includes("<الطبري>"));
assert.ok(shell.indexOf('data-r="back"') < shell.indexOf('class="r-ttl"') && shell.indexOf('class="r-ttl"') < shell.indexOf('data-r="search"') && shell.indexOf('data-r="toc"') < shell.indexOf('data-r="more"'));   // الترتيب كما في الصورة (RTL)
assert.ok(!shell.includes("float-toggle"));
assert.match(V.bookmarkBtnHtml(true), /data-on="1"/); assert.match(V.bookmarkBtnHtml(true), /fill="currentColor"/); assert.ok(!V.bookmarkBtnHtml(false).includes("data-on"));
assert.match(V.posHtml("ج1 • ص165", 163, 16700), /<span class="pl">ج1 • ص165<\/span><bdi class="pn" dir="ltr">163\/16700<\/bdi>/);
const tabs = V.tabsBoxHtml("hl", "<p>x</p>");
assert.match(tabs, /data-tab="toc"[^>]*>الفهرس/); assert.match(tabs, /data-tab="marks"[^>]*>العلامات/); assert.match(tabs, /class="on" data-tab="hl">التظليلات/); assert.match(tabs, /data-tab="notes"[^>]*>الملاحظات/); assert.match(tabs, /data-r="close-sheet"/);
const items = [{ id: "1", kind: "bookmark", pageIndex: 2, label: "ص3" }, { id: "2", kind: "highlight", pageIndex: 4, label: "ص5", quote: "مظلل" }, { id: "3", kind: "note", pageIndex: 6, label: "ص7", quote: "اقتباس", text: "ملاحظتي" }];
const m = V.listTabInner("marks", items), h = V.listTabInner("hl", items), n = V.listTabInner("notes", items);
assert.ok(m.includes('data-id="1"') && !m.includes('data-id="2"') && !m.includes('data-id="3"') && !m.includes('data-n="add"'));
assert.ok(h.includes('data-id="2"') && h.includes('data-n="hl-add"') && !h.includes('data-id="3"'));
assert.ok(n.includes('data-id="3"') && n.includes('data-n="add"') && n.includes('data-n="edit"') && !n.includes('data-id="1"'));
assert.match(V.listTabInner("marks", []), /لا علامات/); assert.match(V.listTabInner("hl", []), /لا تظليلات/); assert.match(V.listTabInner("notes", []), /empty|لا /);
const more = V.moreInner(); for (const act of ["info", "size-down", "size-up", "bright", "night", "hl-sel", "fonts"]) assert.ok(more.includes(`data-r="${act}"`), act);
assert.match(V.floatHtml({ hadith: "guess" }), /حديث؟/); assert.equal(V.floatHtml({}).includes("r-chip"), false);

// ---- 5) كل مفتاح نصي يُستعمل في القوالب الجديدة يجد ترجمة (لا تظهر أسماء المفاتيح للمستخدم) ----
for (const k of ["reader.back", "reader.settings", "reader.prev", "reader.next", "reader.close", "reader.tb.search", "reader.tb.toc", "reader.tb.more", "reader.tb.bookmark", "reader.tb.info", "reader.tb.sizeDown", "reader.tb.sizeUp", "reader.tb.bright", "reader.tb.night", "reader.tb.fonts", "reader.tabs.toc", "reader.tabs.marks", "reader.tabs.hl", "reader.tabs.notes", "reader.marksEmpty", "reader.hl.add", "reader.hl.hint", "reader.hl.empty", "reader.hl.need", "reader.hl.saved", "reader.notes.add", "reader.notes.hint", "reader.notes.empty", "reader.notes.go", "reader.notes.del", "reader.notes.edit"]) {
  const v = t(k); assert.ok(typeof v === "string" && v && v !== k && !/^reader\./.test(v), "ترجمة ناقصة: " + k);
}
console.log("chrome OK");
