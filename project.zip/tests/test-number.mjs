import assert from "node:assert/strict";
import { DatabaseSync } from "node:sqlite";
import { openReader } from "../src/reader/reader-engine.js";
import { numberHitHtml } from "../src/components/search-view.js";
const d = new DatabaseSync(":memory:");
d.exec("CREATE TABLE page(id INTEGER PRIMARY KEY, part TEXT, page INTEGER, number INTEGER, body TEXT, foot TEXT, services TEXT); CREATE TABLE title(id INTEGER PRIMARY KEY, page INTEGER, parent INTEGER, text TEXT)");
const st = d.prepare("INSERT INTO page VALUES(?,?,?,?,?,?,?)");
st.run(1, "المقدمة", 1, null, "", "مقدمة", null);
st.run(13, "1", 10, 1, "١ - حَدَّثَنَا الْحُمَيْدِيُّ", null, null);
st.run(14, "1", 11, 2, "٢ - حَدَّثَنَا عَبْدُ اللَّهِ", null, null);
st.run(15, "1", 12, 2, "تكملة الحديث الثاني", null, null);   // الرقم نفسه في صفحتين: نأخذ أولاهما
st.run(16, "1", 13, 3, "٣ - ...", null, null);
const dbw = { all: (q) => d.prepare(q).all(), close() {} };
const r = await openReader({ id: 735, dl: { getBookBytes: async () => new Uint8Array() }, catalog: { fileInfo: () => null }, open: async () => dbw });
assert.equal(r.getPage(r.findByNumber(1)).id, 13);
assert.equal(r.getPage(r.findByNumber(2)).id, 14);   // أول صفحة تحمل الرقم 2
assert.equal(r.getPage(r.findByNumber(3)).id, 16);
assert.equal(r.findByNumber(99), -1); assert.equal(r.findByNumber(0), -1);
assert.equal(r.findByNumber(-1), -1); assert.equal(r.findByNumber(1.5), -1); assert.equal(r.findByNumber("1; DROP TABLE page"), -1);   // لا حقن
assert.equal(d.prepare("SELECT COUNT(*) c FROM page").get().c, 5);
const h = numberHitHtml({ n: 1782, index: 7, label: "الجزء 1 • ص <3>" });
assert.match(h, /data-hit="7"/); assert.match(h, /حديث رقم 1782/); assert.ok(h.includes("&lt;3&gt;"));
console.log("number OK");
