import assert from "node:assert/strict";
import { DatabaseSync } from "node:sqlite";
import { buildQuranIndex } from "../src/modules/quran-index.js";
import { indexTafsirBook, prepareLocal, localTafsirFor, saveLocalBook, loadLocalTafsir, bookReport } from "../src/modules/tafsir-local.js";
import { ayahSheetInner } from "../src/components/reader-view.js";

const ayaText = [];
ayaText[1] = "بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ"; ayaText[2] = "الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ"; ayaText[3] = "الرَّحْمَنِ الرَّحِيمِ"; ayaText[4] = "مَالِكِ يَوْمِ الدِّينِ"; ayaText[5] = "إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ"; ayaText[6] = "اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ"; ayaText[7] = "صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ";
for (let i = 8; i < 100; i++) ayaText[i] = "كلمة" + String.fromCharCode(0x0627 + (i % 20)) + " اختبار" + String.fromCharCode(0x0628 + (i % 17)) + " نص";
ayaText[50] = ayaText[60] = "فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ";
for (let i = 100; i < 263; i++) ayaText[i] = "آية أنعام رقم " + String.fromCharCode(0x0627 + (i % 25)) + String.fromCharCode(0x0628 + (i % 23));
const sura = [{ id: 1, name: "الفاتحة", ayat: 7, first: 1 }, { id: 2, name: "الاختبار", ayat: 92, first: 8 }, { id: 6, name: "الأنعام", ayat: 163, first: 100 }];
const q = buildQuranIndex({ ayaText, sura });
const V = (i) => "﴿" + ayaText[i] + "﴾";

const db = new DatabaseSync(":memory:");
db.exec("CREATE TABLE page(id INTEGER PRIMARY KEY, body TEXT); CREATE TABLE title(id INTEGER PRIMARY KEY, page INTEGER, parent INTEGER, text TEXT)");
const P = db.prepare("INSERT INTO page VALUES(?,?)"), T = db.prepare("INSERT INTO title VALUES(?,?,?,?)");
const pages = {
  1: "مقدمة", 2: "تمهيد", 3: "تفسير الآية الأولى", 5: "تفسير ٣ و٤", 6: "قال " + V(2) + " استشهاد بسورة أخرى وكذلك " + V(12),
  9: "نص", 12: "نص " + V(20), 13: "ثم " + V(25) + " وبعدها", 14: "رجوع " + V(9), 15: "نص " + V(55), 16: "مكرر " + V(50) + " أو " + V(60) + " مرة",
  20: "أنعام", 21: "بداية " + V(100) + " ثم", 22: "استشهاد بآية في الأولى " + V(30), 23: "نهاية " + V(200), 24: "قفزة كبيرة " + V(250) + " (قال فلان كذا وكذا)", 25: "أقواس أخرى {" + ayaText[255] + "} و «" + ayaText[256] + "»", 30: "x"
};
for (const [id, b] of Object.entries(pages)) P.run(Number(id), b);
const titles = [[1, 1, 0, "الاختبار"], [2, 3, 1, "١"], [3, 5, 1, "٣ - ٤"], [4, 9, 1, "الآية ١٠"], [5, 12, 1, "قوله تعالى " + V(20)], [6, 14, 1, "٩٩٩"], [7, 20, 0, "سورة الأنعام"], [8, 30, 0, "فضائل متفرقة"]];
for (const t of titles) T.run(...t);
const dbw = { all: (s) => db.prepare(s).all(), close() {} };
const res = await indexTafsirBook({ db: dbw, quran: q, chunk: 5, yieldFn: async () => {} });
const A = []; for (let i = 0; i < res.anchors.length; i += 4) A.push([...res.anchors.slice(i, i + 4)].join(","));
console.log(A.join(" | ")); console.log(JSON.stringify(res.stats));
const has = (from, to, page, src) => A.includes([from, to, page, src].join(","));
assert.ok(has(8, 8, 3, 3 - 3)); // رقم آية ١ في الاختبار: from=8 (src 0) في صفحة 3
assert.ok(has(10, 11, 5, 0)); assert.ok(has(17, 17, 9, 0));
assert.ok(has(20, 20, 12, 1) && has(20, 20, 12, 2));    // عنوان بآية + متن
assert.ok(!A.some((a) => a.startsWith("2,2,6")));         // آية من سورة أخرى رُفضت
assert.ok(has(12, 12, 6, 2));                             // 12 ≥ آخر آية (11) فتُقبل
assert.ok(has(25, 25, 13, 2));                            // تقدّم رتيب
assert.ok(!A.some((a) => a.startsWith("9,9,14")));        // رجوع للخلف رُفض
assert.ok(has(55, 55, 15, 2));                            // آية 55 مقبولة
assert.equal(A.filter((a) => a === "60,60,16,2").length, 1);   // المكرر 50/60 بعد 55: يبقى 60 فقط وبلا تكرار // 50 < 55 مستبعدة
assert.ok(has(100, 100, 20, 3));                          // عنوان سورة الأنعام (مرساة سورة src 3)
assert.ok(has(100, 100, 21, 2)); assert.ok(has(200, 200, 23, 2));
assert.ok(has(250, 250, 24, 2));                           // قفزة أكبر من 120 تُقبل الآن (لا ركود)
assert.ok(has(255, 255, 25, 2) && has(256, 256, 25, 2));    // { } و« »
assert.ok(res.stats.bracketHits.curly >= 1 && res.stats.bracketHits.guil >= 1 && res.stats.brackets.paren >= 1 && res.stats.bracketHits.paren === 0);
assert.ok(!A.some((a) => a.startsWith("30,30,22")));      // آية في سورة أخرى (الاختبار) أثناء الأنعام رُفضت
assert.equal(res.stats.suraTitles, 2); assert.equal(res.stats.numTitles, 3); // "٩٩٩" خارج السورة تُهمل
assert.equal(res.stats.bodyRejected >= 3, true);

// الاستعلام
await saveLocalBook(777, res, { get: async () => null, set: async (k, v) => { global.__s = v; } });
await saveLocalBook(888, { anchors: Int32Array.from([8, 20, 40, 0]), stats: {} }, { get: async () => global.__s, set: async (k, v) => { global.__s = v; } });
structuredClone(global.__s);
const idx = await loadLocalTafsir(async () => global.__s);
assert.deepEqual([...idx.books.keys()].sort(), [777, 888]);
const at = (id) => Object.fromEntries(localTafsirFor(idx, id).map((x) => [x.book, x]));
assert.deepEqual(at(10)[777], { book: 777, pages: [5], approx: false });              // ضمن «٣ - ٤»
assert.deepEqual(at(11)[777].pages, [5]);
assert.deepEqual(at(9)[777], { book: 777, pages: [3], approx: true });                // بين مرساتين: تقريبي من أقرب سابقة
assert.deepEqual(at(15)[888], { book: 888, pages: [40], approx: false });
assert.deepEqual(localTafsirFor(idx, 3), []);                                         // قبل أول مرساة
assert.deepEqual(localTafsirFor(null, 3), []);
assert.equal(prepareLocal({ version: 9 }), null);
const rep = bookReport("كتاب تجريبي", 777, res, q, idx).join("\n"); console.log(rep);
assert.match(rep, /تجربة 1:1 ← لا شيء/); assert.match(rep, /أقواس مطابقة للقرآن\/كل الأقواس: ﴿﴾ \d+\/\d+ \| \{\} 1\/1/);
// القالب
const html = ayahSheetInner({ loc: "x", text: "y", conf: "exact", hasLinks: true, groups: [], local: localTafsirFor(idx, 9) }, { bookName: (b) => "كتاب " + b, downloaded: (b) => b === 777 });
assert.match(html, /مفهرسة محليًا/); assert.match(html, /href="#\/read\/777\?pid=3"/); assert.match(html, /تقريبي/);
console.log("tafsir local tests OK");
// عنوان السورة وحده يعطي موضعًا تقريبيًا لآياتها الأولى (مثل الفاتحة)
const idx2 = prepareLocal({ version: 1, books: { 5: { anchors: Int32Array.from([1, 1, 8, 3, 8, 8, 49, 0]), stats: {} } } });
assert.deepEqual(localTafsirFor(idx2, 1), [{ book: 5, pages: [8], approx: true }]);
assert.deepEqual(localTafsirFor(idx2, 7), [{ book: 5, pages: [8], approx: true }]);
assert.deepEqual(localTafsirFor(idx2, 8), [{ book: 5, pages: [49], approx: false }]);
console.log("sura fallback OK");
