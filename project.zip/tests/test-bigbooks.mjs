import assert from "node:assert/strict";
import { decideForce, finishBigOpen, forgetBigBooks, BIG_KEY, PENDING_KEY } from "../src/modules/bigbooks.js";
const mk = () => { const m = new Map(); return { m, get: async (k) => (m.has(k) ? m.get(k) : null), set: async (k, v) => { m.set(k, structuredClone(v)); } }; };
const MB = 1048576, LIM = 100 * MB, ID = 25794;
const d = (kv, o) => decideForce({ id: ID, sizeBytes: 107 * MB, limitBytes: LIM, get: kv.get, set: kv.set, ...o });
// كتاب صغير: لا شيء يُسجَّل
const k0 = mk(); assert.deepEqual(await decideForce({ id: 1, sizeBytes: 50 * MB, limitBytes: LIM, get: k0.get, set: k0.set }), { force: false, track: false }); assert.equal(k0.m.size, 0);
// أول مرة بلا ضغط: لا قوة (يظهر الزر)
const k = mk(); assert.deepEqual(await d(k), { force: false, track: false });
// ضغط المستخدم: يُسمح ويُسجَّل معلّقًا
assert.deepEqual(await d(k, { forceParam: true }), { force: true, track: true });
assert.deepEqual(k.m.get(BIG_KEY), [ID]); assert.equal(k.m.get(PENDING_KEY), ID);
await finishBigOpen({ set: k.set }); assert.equal(k.m.get(PENDING_KEY), null);
// المرات التالية بلا ضغط: تلقائي
assert.deepEqual(await d(k), { force: true, track: true }); await finishBigOpen({ set: k.set });
// انهيار: بقي معلّقًا → تُسحب الموافقة ويُطلب الضغط من جديد
assert.equal(k.m.get(PENDING_KEY), null); await d(k); assert.equal(k.m.get(PENDING_KEY), ID);   // فتح بدأ ولم يكتمل
const r = await d(k); assert.deepEqual(r, { force: false, track: false, retracted: true }); assert.deepEqual(k.m.get(BIG_KEY), []);
// وإن ضغط صراحةً بعد الانهيار فيُعاد المحاولة
await d(k, { forceParam: true }); await finishBigOpen({ set: k.set });
// نسيان الموافقة
await forgetBigBooks({ set: k.set }); assert.deepEqual(await d(k), { force: false, track: false });
// حاجز: بيانات تالفة لا تُسقط
const bad = mk(); bad.m.set(BIG_KEY, "x"); assert.deepEqual(await d(bad), { force: false, track: false });
console.log("bigbooks OK");
