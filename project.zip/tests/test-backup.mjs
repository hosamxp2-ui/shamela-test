import assert from "node:assert/strict";
import { collectBackup, parseBackup, restoreBackup, isUserKey, FORMAT } from "../src/modules/backup.js";
const mk = (init) => { const m = new Map(Object.entries(init)); return { m, keys: async () => [...m.keys()], get: async (k) => (m.has(k) ? m.get(k) : null), set: async (k, v) => { m.set(k, structuredClone(v)); } }; };
const src = mk({ settings: { theme: "dark" }, favorites: [{ id: 1, at: 5 }], "notes:711": [{ id: "a", pageIndex: 3, text: "ملاحظة" }], "notes:index": [711], "progress:711": { index: 9, total: 100, at: 1 }, "stats:days": { "2026-11-26": 3 }, "readpages:711": [[1, 4]], catalog: { big: 1 }, "services-links": { x: 1 }, "hadith-text-index": { y: 1 }, "tafsir-local": { z: 1 } });
const b = await collectBackup({ keys: src.keys, get: src.get, appVersion: "0.19.0", downloaded: [{ id: 711, name: "صحيح مسلم" }], now: () => "T" });
assert.equal(b.format, FORMAT); assert.deepEqual(Object.keys(b.data).sort(), ["favorites", "notes:711", "notes:index", "progress:711", "readpages:711", "settings", "stats:days"]);
assert.ok(!("catalog" in b.data) && !("services-links" in b.data) && !("tafsir-local" in b.data));
const text = JSON.stringify(b);
// استعادة على جهاز جديد
const dst = mk({});
const r = await restoreBackup(text, { get: dst.get, set: dst.set });
assert.deepEqual([r.ok, r.restored, r.skipped], [true, 7, 0]); assert.deepEqual(r.downloaded, [{ id: 711, name: "صحيح مسلم" }]);
assert.deepEqual(dst.m.get("notes:711"), [{ id: "a", pageIndex: 3, text: "ملاحظة" }]);
// دمج فوق بيانات قائمة: الملاحظات والمفضلات اتحاد، والتقدّم يُستبدل
const dst2 = mk({ "notes:711": [{ id: "b", pageIndex: 5, text: "قديمة" }], favorites: [{ id: 2, at: 1 }], "notes:index": [42], "progress:711": { index: 1, total: 100, at: 0 } });
await restoreBackup(text, { get: dst2.get, set: dst2.set });
assert.deepEqual(dst2.m.get("notes:711").map((n) => n.id), ["b", "a"]); assert.deepEqual(dst2.m.get("favorites").map((f) => f.id), [2, 1]);
assert.deepEqual(dst2.m.get("notes:index").sort(), [42, 711]); assert.equal(dst2.m.get("progress:711").index, 9);
// أمان: مفاتيح غير مسموحة ونصوص فاسدة
assert.equal(isUserKey("catalog"), false); assert.equal(isUserKey("services-links"), false); assert.equal(isUserKey("notes:7"), true); assert.equal(isUserKey("__proto__"), false);
const evil = JSON.stringify({ format: FORMAT, version: 1, data: { catalog: 1, "hadith-text-index": 1, settings: { ok: 1 }, "notes:x": null } });
const d3 = mk({}); const r3 = await restoreBackup(evil, { get: d3.get, set: d3.set });
assert.equal(r3.restored, 1); assert.equal(r3.skipped, 3); assert.deepEqual([...d3.m.keys()], ["settings"]);
for (const bad of ["", "   ", "not json", "{}", JSON.stringify({ format: "x", version: 1, data: {} }), JSON.stringify({ format: FORMAT, version: 2, data: {} }), JSON.stringify({ format: FORMAT, version: 1, data: [] })]) assert.equal((await restoreBackup(bad, { get: dst.get, set: dst.set })).ok, false);
assert.equal(parseBackup("x".repeat(21 * 1024 * 1024)).error, "too_big");
console.log("backup OK");
