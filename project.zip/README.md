# المكتبة الإسلامية الشاملة

تطبيق أندرويد (Capacitor) لتصفح فهرس الشاملة وقراءة الكتب دون إنترنت بعد تنزيلها.

- الحالة: انظر `PROJECT_STATUS.md`
- المعمارية: انظر `ARCHITECTURE.md`
- البناء: يتم عبر GitHub Actions (تبويب Actions)

## الخطوط

تُضمَّن الخطوط عند البناء من حزم fontsource بترخيص SIL OFL 1.1 (Amiri، Noto Naskh Arabic، Noto Kufi Arabic، Scheherazade New).
