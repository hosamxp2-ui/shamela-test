# ARCHITECTURE — المكتبة الإسلامية الشاملة

> الحالة: محدّثة بعد المرحلة 3. البنود المعلّمة **(معلّق)** تُحسم بعد نتيجة اختبار التطبيق الأصلي.

## 1. القرارات

| الموضوع | القرار |
|---|---|
| الواجهة | JavaScript بوحدات ES أصلية وبدون أداة بناء في المرحلة 3 (أبسط وأقل أعطالًا)، عربية RTL، Mobile First. يُضاف Vite عند الحاجة |
| النشر | تطبيق Android عبر Capacitor 8 (الطلبات الأصلية تتجاوز CORS) |
| قراءة الخادم | `CapacitorHttp` مباشرة مع طلبات Range لجلب كتاب واحد (**مؤكد**)، وإعادة المحاولة عند وصول `text/html` |
| قاعدة البيانات المحلية | IndexedDB للإعدادات والتقدم والفهرس |
| قراءة SQLite | sql.js (مكتبة صغيرة، حاجة حقيقية: `master.db` وغالبًا الكتب نفسها) |
| تخزين الكتب المنزّلة | IndexedDB: قطع 2MB مضغوطة كما هي على الخادم (يُفك الضغط عند الفتح). 96% من الكتب أقل من 5MB؛ الكتب الكبيرة جدًا (فوق 100MB بعد الفك) تُعالج في القارئ **(معلّق)** |
| فك الضغط | `DecompressionStream` (الكتب gzip، **مؤكد**) |
| العمل دون إنترنت | Service Worker لواجهة التطبيق + الفهرس والكتب المنزّلة محليًا |

## 2. مصدر البيانات (مؤكد من الملفات)

- `manifest.json`: روابط الملفات وأحجامها وSHA256.
- `index.json`: لكل كتاب `offset` و`length` و`size` و`sha256` و`pages` و`titles` داخل `books.pack`.
- `master.db` (SQLite): الجداول `category` و`book` و`author` و`author_book` و`book_file` و`book_norm` و`author_norm`.
- كل كتاب gzip يحوي SQLite؛ SHA256 على البايتات المخزّنة.
- أول طلب لكل رابط يعيد صفحة Synology ثم ينجح الثاني (ملف `sharing_sid`).
- كتابان بلا موضع في الحزمة (284 و23700) يُعرضان غير متاحين.
- `services.db` و`tashkeel.db`: لم تُفحص، اختياريان ولا يُنزَّلان إلا بطلب المستخدم.

## 3. الوحدات (فصل كامل بين المكونات)

| الوحدة | المسؤولية |
|---|---|
| Data Connector | الوحيدة التي تعرف روابط الخادم؛ تجلب manifest وindex والكتب بـ Range؛ يمكن استبدالها بمصدر آخر |
| Catalog Manager | تحميل `master.db` وتحويله إلى فهرس محلي (أقسام، مؤلفون، كتب)، والفرز والتصفية |
| Search Engine | بحث العناوين والمؤلفين من `book_norm`، وبحث النصوص داخل الكتب المنزّلة فقط |
| Download Manager | قائمة انتظار، إيقاف واستكمال، إلغاء، إعادة محاولة، تحقق SHA256، حذف |
| Reader Engine | عرض الصفحات والخطوط والثيمات والاتجاه وملء الشاشة |
| Footnotes Manager | اكتشاف تنسيق الهوامش لكل كتاب ثم عرضها في Popup **(بعد فحص بيانات الكتب)** |
| Cross-Reference Engine | الربط بالمعرّفات الموثوقة فقط، وتمييز غير المؤكد **(بعد فحص `services.db`)** |
| Offline Manager | حالة الاتصال، مزامنة الفهرس عند توفره |
| Reading Tracker | آخر موضع، نسبة الإنجاز، الإحصائيات، السجل |
| Settings Manager | إعدادات القارئ والثيم واللغة |

## 4. IndexedDB (مقترح)

| المخزن | المفتاح | المحتوى |
|---|---|---|
| `meta` | key | إصدار البيانات، تاريخ آخر مزامنة |
| `categories` | category_id | الاسم والترتيب |
| `authors` | author_id | الاسم، سنة الوفاة |
| `books` | book_id | العنوان، القسم، المؤلف، الصفحات، الموضع في الحزمة، الاسم المطبّع |
| `downloads` | book_id | الحالة، التقدم، مسار أو بيانات الكتاب المنزّل |
| `favorites` | book_id | تاريخ الإضافة |
| `progress` | book_id | آخر صفحة، نسبة الإنجاز، آخر قراءة |
| `history` | auto | سجل القراءة والبحث |
| `stats` | day | الصفحات المقروءة ووقت القراءة |
| `settings` | key | إعدادات القارئ والتطبيق |

## 5. بنية الملفات (المرحلة 3)

```
index.html                       الهيكل وشريط التنقل
src/main.js                      الإقلاع والتوجيه وربط الشاشات
src/config.js                    مصدر البيانات والحدود
src/strings.js                   كل نصوص الواجهة (جاهز للإنجليزية)
src/services/data-connector.js   الاتصال الأصلي + إعادة المحاولة + بوابة Range
src/services/shamela-nas-source.js  محوّل المصدر (Data Adapter)
src/services/sqlite.js           غلاف sql.js
src/database/idb.js              IndexedDB (مفتاح/قيمة)
src/modules/arabic.js            توحيد النص العربي
src/search/query.js              محلل الاستعلام ومحرك بحث الفهرس
src/modules/catalog.js           بناء الفهرس والبحث والفرز
src/modules/sync.js              تنزيل الفهرس وفحص التحديث
src/modules/book-inspector.js    فحص بنية كتاب صغير
src/modules/download-manager.js  قائمة التنزيل (قطع Range، إيقاف/استكمال، SHA256)
src/database/downloads-store.js  تخزين التنزيلات في IndexedDB
src/components/views.js          عرض HTML (دوال نقية)
src/components/reader-view.js    قوالب القارئ
src/reader/content.js            تنظيف HTML والفقرات والهوامش
src/reader/reader-engine.js      فتح الكتاب والصفحات والعناوين
src/reader/reader-controller.js  ربط القارئ بالصفحة (DOM)
src/reader/gestures.js           اتجاه التمرير والحدود
src/reader/toc.js                فهرس العناوين كشجرة
src/modules/notes.js             الإشارات والملاحظات (محلية)
src/modules/settings.js          إعدادات القارئ والثيمات
src/modules/progress.js          آخر موضع قراءة
src/modules/theme.js             ثيم التطبيق والتبديل التلقائي
src/modules/back-handler.js      قرار زر الرجوع (دالة نقية)
src/modules/fonts.js             كشف الخطوط المتاحة
src/components/settings-view.js  صفحة الإعدادات
src/styles/reader.css, fonts.css
src/styles/app.css
```

البناء: سير العمل ينسخ `index.html` و`src` وملفي sql.js إلى `www/` ثم Capacitor.

## 6. قيود وحدود معروفة

- الخادم شخصي وقد يبطؤ؛ تُحدّ الطلبات المتوازية.
- لا بحث سحابي داخل النصوص.
- احترام حقوق النشر وشروط استخدام مصدر البيانات؛ لا نعيد توزيع البيانات.
- كل مسار بناء (PWA وAPK) يُختبر منفصلًا.

## 7. ملاحظات من بنية الكتاب

- جداول FTS5 داخل الكتب بلا محتوى ولا تُقرأ بـ sql.js الحالية. خيارات البحث داخل الكتب (المرحلة 8، **معلّق**): محرك SQLite يدعم FTS5، أو فهرس نبنيه نحن، أو مسح الصفحات مباشرة (يكفي لمعظم الكتب الصغيرة).
- `body` نص يحوي وسم span للعناوين (`id=toc-N`)، و`foot` نص بترقيم (١)(٢)، وعمود `services` فارغ في الكتاب المفحوص. العناوين: `title.page` = `page.id`.

الخطوط: تُنسخ من حزم fontsource أثناء البناء إلى `www/fonts` (ترخيص OFL-1.1: Amiri وNoto Naskh/Kufi وScheherazade New). إن فشل تثبيتها يعمل التطبيق بخط النظام.
